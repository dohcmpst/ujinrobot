﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

/// <summary>
/// Inclusion of PEAK PCAN-Basic namespace
/// </summary>
using Peak.Can.Basic;
using TPCANHandle = System.UInt16;
using TPCANBitrateFD = System.String;
using TPCANTimestampFD = System.UInt64;
using System.IO;
using System.Data.SqlTypes;
using System.Net.NetworkInformation;
using static System.Resources.ResXFileRef;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Reflection;
using System.Security.Claims;
using System.Threading.Tasks;
using Watchdog.Timer;
using System.Threading;





namespace PCANBasicProject
{
    public partial class Form_Main : Form
    {
        // Test
        bool CONSOLE_OUT = false;

        #region  Glabal Variable

        /* EVENT Constants */
        const int EVENT_PERIOD = 500;     // Event Message (21 Record) Tx Period 

        const int EVENT_LENGTH = 20;
        const int RECORD_LENGTH = 21;
        const int EVENT_POSITION = 10;   // 21 = 10 + 1 + 10 ==> [0 ~ 9] = Previous, [10] = Event, [11 ~ 20] = After
        const int RECORD_SIZE = 16;      // 1 record 는 16 byte 로 구성

        byte[,,] eventData = new byte[EVENT_LENGTH, RECORD_LENGTH, EVENT_PERIOD];
        int eventNo = 0;
        int recordNo = 0;
        int rcvFirstCnt = 0;
        int rcvSecondCnt = 0;
        int rcvThirdCnt = 0;
        int prvEventNo = 0;

        bool bmsRequested = false;  // 사용자가 강제로 중지한 경우에는 타이머에서 자동으로 데이터 요구를 하지 않음
        bool bmsReceivedMessage = false;

        string detailListViewIndex, detailEventName, detailStrCode;

        #endregion

        #region System Fault Code
        const UInt32 f_OVP = 0x0001;
        const UInt32 f_UVP = 0x0002;
        const UInt32 f_OCP = 0x0004;
        const UInt32 f_DOCP = 0x0008;
        const UInt32 f_COTP = 0x0010;
        const UInt32 f_DOTP = 0x0020;
        const UInt32 f_CUTP = 0x0040;
        const UInt32 f_DUTP = 0x0080;
        const UInt32 f_CPF = 0x0100;
        const UInt32 f_DPF = 0x0200;

        const UInt32 f_RELESE = 0x8000;
        const UInt32 f_OCCUR = 0x0000;

        UInt32[] f_Code = new UInt32[] { f_OVP, f_UVP, f_OCP, f_DOCP, f_COTP, f_DOTP, f_CUTP, f_DUTP, f_CPF, f_DPF };
        string[] f_EventName = new string[] { "OVP", "UVP", "OCP", "DOCP", "COTP", "DOTP", "CUTP", "DUTP", "CPF", "DPF" };
        int faultCodeSize = 10;     // 10개 Fault Cpde

        #endregion


        #region Button Control

        private void btnEventSave_Click(object sender, EventArgs e)
        {
            // 파일 선택과정에서 중복 클릭 방진
            btnEventSave.Enabled = false;

            // File 선택 및 저장
            if (Select_SaveEventFile() == true)
            {


            }
            else
            {
                // 파일 저장이 취소된 경우 -> 버튼 복귀 (공통 처리)
            }
            btnEventSave.Enabled = true;
        }

        private bool Select_SaveEventFile()
        {
            bool NewFile = false;
            string saveFile = "";
            string savePath = "";
            // Log 폴더가 존재하는 지 확인하고 없으면 생성
            string startFolderEvent = Application.StartupPath;           // 실행파일 위치
            //string exeFolderName = Application.ExecutablePath;     // 실행파일 위치 + 이름
            string logFolerEvent = Path.Combine(startFolderEvent, "Log");
            if (Directory.Exists(logFolerEvent) == false)
            {
                Directory.CreateDirectory(logFolerEvent);
            }
            Directory.SetCurrentDirectory(logFolerEvent);   // Log Folder 로 이동

            // Log File 생성 -> Global 로 선언
            // SaveFileDialog logFileDlg = new SaveFileDialog();

            EventlogFileDlg.InitialDirectory = Environment.CurrentDirectory;
            // Directory.SetCurrentDirectory(@logFoler); 로 변경한 폴더으 값을 저장
            EventlogFileDlg.Title = "LB Project : Log 저장 파일 설정 "; // SaveDialog 의 이름 
            EventlogFileDlg.RestoreDirectory = true; // 대화상자를 닫기 전에 디렉토리를 이전에 선택한 디렉토리로 복원.
            // 파일 확장자
            EventlogFileDlg.AddExtension = true;  // 확장명을 입력하지 않을 때, 자동으로 확장자를 추가할 수 있습니다.
            EventlogFileDlg.DefaultExt = "csv";
            EventlogFileDlg.Filter = "CSV files (*.csv)|*.csv;*.log|All files (*.*)|*.*";
            EventlogFileDlg.FilterIndex = 2;
            // 파일 이름, 중복 처리  
            EventlogFileDlg.OverwritePrompt = true;  // 기본값: true 파일이 이미 존재하면 덮어쓰기 할지를 묻는 대화상자를 표시합니다.
            EventlogFileDlg.FileName = "Event_" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".csv";
            // 파일이 존재하는 지 확인 : TRUE 로 선언, 파일이 없으면 안됨, false 로 하면 신규 파일이 생성됨.
            //logFileDlg.CheckFileExists = true;

            if (EventlogFileDlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // File이름 생성
                    saveFile = EventlogFileDlg.FileName;
                    saveFile = Path.GetFileName(EventlogFileDlg.FileName);
                    savePath = Path.GetDirectoryName(EventlogFileDlg.FileName);

                    string Title = GetLogTitle_LB_Event();

                    // using 문 : { ..} 실행 후  Close( )를 자동으로 해줌\
                    using (StreamWriter swSaveEvent = new StreamWriter(EventlogFileDlg.FileName, true, Encoding.ASCII))
                    // swSaveLogFileTimer = new StreamWriter(logFileDlg.FileName, true, Encoding.ASCII);
                    {
                        /* Title 저장 */
                        swSaveEvent.WriteLine(Title);

                        /* Event Data 저장 */
                        for (int j = 0; j < EVENT_LENGTH; j++)
                        {
                            for (int k = 0; k < RECORD_LENGTH; k++)
                            {
                                string record = EventSaveFile(j, k);
                                swSaveEvent.WriteLine(record);
                            }
                        }

                    }

                }
                catch (Exception e)
                {
                    MessageBox.Show("Open -> Exception: " + e.Message);
                }
                finally
                {
                    EventlogFileDlg.Dispose(); // OpenFileDialog 리소스 해제    --> 동일 파일에 계속 쓰는 지 시험 필요
                    NewFile = true;
                }
            }
            else
            {
                NewFile = false;
            }

            return NewFile;
        }

        private string EventSaveFile(int eventNo, int recordNo)
        {
            // Data 생성
            int E = eventNo;
            int R = recordNo;  // 21 = 10 + 1 + 10 ==> [0 ~ 9] = Previous, [10] = Event, [11 ~ 20] = After
            byte[] record = new byte[RECORD_SIZE];
            for (int k = 0; k < RECORD_SIZE; k++)   // copy 1 record
                record[k] = eventData[E, R, k];

            // variable
            string str = "";
            UInt32 time = BitConverter.ToUInt32(record, 0); // 시간
            UInt32 code = BitConverter.ToUInt16(record, 4); // Event Code
            float voltPack = BitConverter.ToUInt16(record, 6) / 100.0f; // 팩전압
            UInt32 voltMax = BitConverter.ToUInt16(record, 8); // 최대 전압
            UInt32 voltMIn = BitConverter.ToUInt16(record, 10); // 최소전압
            float current = BitConverter.ToInt16(record, 12) / 100.0f; // 전류
            Int32 tempMax = (SByte)record[14];                // 최대 온도
            Int32 tempMin = (SByte)record[15];                // 최소 온도

            str += (eventNo + 1).ToString(); str += " ,";   // Event No
            str += (recordNo + 1).ToString(); str += " ,";   // Record No
            str += (time.ToString()); str += " ,";   // 시간
            str += (DisplayEventName(code)); str += " ,";   // Event Name
            str += (code.ToString("X4")); str += " ,";   // Event Code
            str += (voltPack.ToString("F2")); str += " ,";   // 팩전압
            str += (voltMax.ToString()); str += " ,";   // 최대 전압
            str += (voltMIn.ToString()); str += " ,";   // 최소전압
            str += (current.ToString("F2")); str += " ,";   // 전류
            str += (tempMax.ToString()); str += " ,";   // 최대 온도
            str += (tempMin.ToString());                    // 최소 온도

            return str;
        }

        private string GetLogTitle_LB_Event()
        {
            string Title = "EVENT No, Record No, Time(Sec), Event Name, Code, Pack Voltage(V),Cell Max(mV), Cell Min(mV), Current(A), Temp Max, Temp Min";

            return Title;
        }

        private void btnEventRequest_Click(object sender, EventArgs e)
        {
            timerRequestEvent.Stop();
            Thread.Sleep(100);
            eventNo = 0;
            recordNo = 0;
            rcvFirstCnt = 0;
            rcvSecondCnt = 0;
            rcvThirdCnt = 0;


            // Clear ListView
            lvwEventMain.Items.Clear();
            lvwEventDetail.Items.Clear();
            lblEventNameCode.Text = "( Event No, EventName , Code )";

            timerRequestEvent.Interval = EVENT_PERIOD;  // 200msec 
            timerRequestEvent.Start();

            if (TEST_OFFLINE)
            {
                byte dt = 0x00;
                for (int i = 0; i < EVENT_LENGTH; i++)
                {
                    for (int j = 0; j < RECORD_LENGTH; j++)
                    {
                        for (int k = 0; k < 16; k++)
                        {
                            eventData[i, j, k] = dt++;
                        }
                    }
                }
            }
        }

        int requestCount = 0;

        private void timerRequestEvent_Tick(object sender, EventArgs e)
        {
            if (eventNo < EVENT_LENGTH)
            {
                if (TEST_OFFLINE)
                {
                    Console.WriteLine("[Test] timerRequestEvent_Tick = {0} ", eventNo);
                    eventNo++;   //응답 3개를 모두 받으면 1증가시키도록 변경
                }
                else
                {
                    Request_Event_Item(eventNo);
                    AddEventLogMessage("\nRequest[" + requestCount.ToString() + "] " + "eventNo = " + eventNo.ToString() + "\n");
                    if (prvEventNo == eventNo)
                    {

                        if (++requestCount >= 100)
                        {
                            AddEventLogMessage("No Acknowledge from BMS ....\n");
                            AddEventLogMessage("       --> Check CAN or BMS \n");
                            AddEventLogMessage("Stop Request EVENT LOG !!! \n\n");
                            timerRequestEvent.Stop();
                        }
                    }
                    else
                    {
                        prvEventNo = eventNo;
                        requestCount = 0;
                    }
                }
            }
            else
            {
                timerRequestEvent.Stop();
                Update_EventList();
                ConsoleDebugPrintEventData();
                lvwEventMain.Items[0].Focused = true;
                lvwEventMain.Items[0].Selected = true;
                lvwEventMain_MouseClick_Process();
            }
        }

        private void ConsoleDebugPrintEventData()
        {
            if (CONSOLE_OUT)
            {
                Console.WriteLine("End Time ....................");
                for (int i = 0; i < EVENT_LENGTH; i++)
                {
                    Console.WriteLine("Event = {0} ", i.ToString());

                    for (int j = 0; j < RECORD_LENGTH; j++)
                    {
                        Console.Write("   Rocord = {0} : ", j.ToString());
                        for (int k = 0; k < 16; k++)
                            Console.Write("{0} ", eventData[i, j, k].ToString("X2"));
                        Console.WriteLine();
                    }
                    Console.WriteLine();
                }
                Console.WriteLine("End Print ....................");
            }
        }


        private void Update_EventList()
        {
            for (int k = 0; k < EVENT_LENGTH; k++)
                DisplayEvent(k);
        }

        //const UInt32 RECORD_LENGTH = 21;
        //const UInt32 EVENT_POSITION = 10;   // 21 = 10 + 1 + 10 ==> [0 ~ 9] = Previous, [10] = Event, [11 ~ 20] = After

        private void DisplayEvent(int eventNo)
        {
            ListViewItem item;

            // 리스트뷰 아이템을 업데이트 하기 시작.
            // 업데이트가 끝날 때까지 UI 갱신 중지.
            lvwEventMain.BeginUpdate();

            if (lvwEventMain.Items.Count == 0)    // 초기화 검사
            {
                for (int k = 0; k < EVENT_LENGTH; k++)
                {
                    item = new ListViewItem((k + 1).ToString());        // No
                    item.SubItems.Add("");                 // 시간
                    item.SubItems.Add("");                    // Event Name
                    item.SubItems.Add("");                 // Event Code
                    item.SubItems.Add("");             // 팩전압
                    item.SubItems.Add("");              // 최대 전압
                    item.SubItems.Add("");              // 최소전압
                    item.SubItems.Add("");              // 전류
                    item.SubItems.Add("");              // 최대 온도
                    item.SubItems.Add("");              // 최소 온도

                    lvwEventMain.Items.Insert(k, item);
                }
            }

            // Data 생성
            int E = eventNo;
            int R = EVENT_POSITION;  // 21 = 10 + 1 + 10 ==> [0 ~ 9] = Previous, [10] = Event, [11 ~ 20] = After
            byte[] record = new byte[RECORD_SIZE];
            for (int k = 0; k < RECORD_SIZE; k++)   // copy 1 record
                record[k] = eventData[E, R, k];

            UInt32 time = BitConverter.ToUInt32(record, 0); // 시간
            UInt32 code = BitConverter.ToUInt16(record, 4); // Event Code
            float voltPack = BitConverter.ToUInt16(record, 6) / 100.0f; // 팩전압
            UInt32 voltMax = BitConverter.ToUInt16(record, 8); // 최대 전압
            UInt32 voltMIn = BitConverter.ToUInt16(record, 10); // 최소전압
            float current = BitConverter.ToInt16(record, 12) / 100.0f; // 전류
            Int32 tempMax = (SByte)record[14];                // 최대 온도
            Int32 tempMin = (SByte)record[15];                // 최소 온도

            item = new ListViewItem((eventNo + 1).ToString());    // No
            item.SubItems.Add(time.ToString());                 // 시간
            item.SubItems.Add(DisplayEventName(code));          // Event Name

            item.SubItems.Add(code.ToString("X4"));             // Event Code
            item.SubItems.Add(voltPack.ToString("F2"));             // 팩전압
            item.SubItems.Add(voltMax.ToString());              // 최대 전압
            item.SubItems.Add(voltMIn.ToString());              // 최소전압
            item.SubItems.Add(current.ToString("F2"));              // 전류
            item.SubItems.Add(tempMax.ToString());              // 최대 온도
            item.SubItems.Add(tempMin.ToString());              // 최소 온도

            // Delete & Insert
            lvwEventMain.Items.RemoveAt(eventNo);
            lvwEventMain.Items.Insert(eventNo, item);

            // 리스트뷰를 Refresh하여 보여줌
            lvwEventMain.EndUpdate();
        }


        private string DisplayEventName(UInt32 faultCode)
        {
            string eventName = "";

            if ((faultCode & f_RELESE) != 0x0) eventName = "c_";
            else eventName = "";

            for (int k = 0; k < faultCodeSize; k++)
            {
                if ((faultCode & f_Code[k]) != 0x0)
                {
                    eventName += f_EventName[k];
                    eventName += " ";
                }
            }
            return eventName;
        }

        private void lvwEventMain_MouseClick(object sender, MouseEventArgs e)
        {
            //if (lvwEventMain.SelectedItems.Count == 1)
            {
                lvwEventMain_MouseClick_Process();
            }
        }
        private void lvwEventMain_MouseClick_Process()
        {
            ListView.SelectedListViewItemCollection items = lvwEventMain.SelectedItems;
            ListViewItem lvItem = items[0];
            //string no = items[0].Text;
            //string add = lvItem.SubItems[1].Text;
            //string lat = lvItem.SubItems[2].Text;
            //string lng = lvItem.SubItems[3].Text;
            //MessageBox.Show("CLICK 선택한행 : " + no + ". " + add + ", " + lat + ", " + lng);

            //int Index = Convert.ToInt32(no);
            string Index = items[0].Text;
            string Code = lvItem.SubItems[3].Text;
            detailListViewIndex = Index;
            DisplayEventDetail(Index, Code, lvItem.SubItems[2].Text);
        }
        /*
        private void lvwEventMain_MouseClick(object sender, MouseEventArgs e)
        {
            if (lvwEventMain.SelectedItems.Count == 1)
            {
                ListView.SelectedListViewItemCollection items = lvwEventMain.SelectedItems;
                ListViewItem lvItem = items[0];
                string no = items[0].Text;
                string add = lvItem.SubItems[1].Text;
                string lat = lvItem.SubItems[2].Text;
                string lng = lvItem.SubItems[3].Text;
                MessageBox.Show("CLICK 선택한행 : " + no + ". " + add + ", " + lat + ", " + lng);

                int Index = Convert.ToInt32(no);
                MessageBox.Show("Index = " + Index.ToString());
            }
        }
        */

        private void DisplayEventDetail(string strIndex, string strCode, string eventName)
        {
            ListViewItem item;
            int index = Convert.ToInt32(strIndex);

            // Label 수정
            detailEventName = eventName;
            detailStrCode = strCode;
            lblEventNameCode.Text = "( " + strIndex + " - 11 , " + eventName + ", " + strCode + " )";

            // 리스트뷰 아이템을 업데이트 하기 시작.
            // 업데이트가 끝날 때까지 UI 갱신 중지.
            lvwEventDetail.BeginUpdate();

            if (lvwEventDetail.Items.Count == 0)    // 초기화 검사
            {
                for (int k = 0; k < RECORD_LENGTH; k++)
                {
                    item = new ListViewItem((k + 1).ToString());        // No
                    item.SubItems.Add("");              // 시간
                    item.SubItems.Add("");              // 팩전압
                    item.SubItems.Add("");              // 최대 전압
                    item.SubItems.Add("");              // 최소전압
                    item.SubItems.Add("");              // 전류
                    item.SubItems.Add("");              // 최대 온도
                    item.SubItems.Add("");              // 최소 온도

                    lvwEventDetail.Items.Insert(k, item);
                }
            }

            // Data 생성 및 출력
            if (index < 1) return;  // Error ...
            int E = index - 1;
            byte[] record = new byte[RECORD_SIZE];

            for (int R = 0; R < RECORD_LENGTH; R++)
            {
                for (int k = 0; k < RECORD_SIZE; k++)   // copy 1 record
                    record[k] = eventData[E, R, k];

                UInt32 time = BitConverter.ToUInt32(record, 0); // 시간 
                UInt32 code = BitConverter.ToUInt16(record, 4); // Event Code
                float voltPack = BitConverter.ToUInt16(record, 6) / 100.0F; // 팩전압
                UInt32 voltMax = BitConverter.ToUInt16(record, 8); // 최대 전압
                UInt32 voltMIn = BitConverter.ToUInt16(record, 10); // 최소전압
                float current = BitConverter.ToInt16(record, 12) / 100.0F; // 전류
                Int32 tempMax = (SByte)record[14];                // 최대 온도
                Int32 tempMin = (SByte)record[15];                // 최소 온도

                item = new ListViewItem((R + 1).ToString());    // No
                item.SubItems.Add(time.ToString());                 // 시간
                item.SubItems.Add(code.ToString("X4"));             // Event Code
                item.SubItems.Add(voltPack.ToString("F2"));             // 팩전압
                item.SubItems.Add(voltMax.ToString());              // 최대 전압
                item.SubItems.Add(voltMIn.ToString());              // 최소전압
                item.SubItems.Add(current.ToString("F2"));              // 전류
                item.SubItems.Add(tempMax.ToString());              // 최대 온도
                item.SubItems.Add(tempMin.ToString());              // 최소 온도

                // Delete & Insert
                lvwEventDetail.Items.RemoveAt(R);
                lvwEventDetail.Items.Insert(R, item);
            }
            // 리스트뷰를 Refresh하여 보여줌
            lvwEventDetail.EndUpdate();
        }


        private void Request_Event_Item(int EventNo)
        {
            TPCANMsg CANMsg = new TPCANMsg();
            CANMsg.DATA = new byte[8];

            CANMsg.ID = CAN_REQ_EVENT_DATA;
            CANMsg.LEN = (byte)SEND_DLC_LB;
            CANMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD;

            //for (int i = 0; i < GetLengthFromDLC(CANMsg.LEN, true); i++)  DLC 길이 (0 ~ 16) 에 따라서 전체 데이터[N]의 N 값이 달라짐 
            CANMsg.DATA[0] = (Byte)EventNo;
            CANMsg.DATA[1] = CONTROL_ZERO;
            CANMsg.DATA[2] = CONTROL_ZERO;
            CANMsg.DATA[3] = CONTROL_ZERO;
            CANMsg.DATA[4] = CONTROL_ZERO;
            CANMsg.DATA[5] = CONTROL_ZERO;
            CANMsg.DATA[6] = CONTROL_ZERO;
            CANMsg.DATA[7] = CONTROL_ZERO;

            if (PCANBasic.Write(m_PcanHandle, ref CANMsg) != TPCANStatus.PCAN_ERROR_OK)
            {
                AddEventLogMessage("Request_Event_Item  Fail !!! \n");
            }
        }

        #endregion

        private void Display_RcvEvent_First(int DLC, byte[] canData)
        {
            rcvFirstCnt++;
            eventNo = canData[0];
            // canData[1]
            recordNo = canData[2];
            // canData[3]
            // canData[4]
            // canData[5]
            // canData[6]
            // canData[7]  

            /* Debugging */
            {
                //AddEventLogMessage("Event No = " + eventNo.ToString() + " , Record No = " +
                //                    recordNo.ToString() + ", " + rcvFirstCnt.ToString() + " , " +
                //                    rcvSecondCnt.ToString() + " , " + rcvThirdCnt.ToString());
                if (ckbDisplayMessageEvent.Checked == true)
                {
                    AddEventLogMessage("0x1A1 : " + eventNo.ToString() + " , " + recordNo.ToString() + "\n");
                }
                else
                {
                    AddEventLogMessage("0x1A1 : " + eventNo.ToString() + " , " + recordNo.ToString() + " : ");
                }
            }

            if (rcvFirstCnt >= RECORD_LENGTH && rcvSecondCnt >= RECORD_LENGTH && rcvThirdCnt >= RECORD_LENGTH)
            {
                eventNo++;
                recordNo = 0;
                rcvFirstCnt = 0;
                rcvSecondCnt = 0;
                rcvThirdCnt = 0;
            }
        }


        private void Display_RcvEvent_Second(int DLC, byte[] canData)
        {
            /*
            u8_can_frame[0] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].u32_SEC & 0x0000ff);       //	BMS 동작 시간 초
            u8_can_frame[1] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].u32_SEC & 0x00ff00) >> 8;  //
            u8_can_frame[2] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].u32_SEC & 0x00ff00) >> 16; //
            u8_can_frame[3] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].u32_SEC & 0xff0000) >> 24; //
            u8_can_frame[4] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].u16_CODE & 0x00ff);            //	이벤트 코드
            u8_can_frame[5] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].u16_CODE & 0xff00) >> 8;       //
            u8_can_frame[6] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].u16_MAX_V & 0x00ff);           //	최대 셀 전압
            u8_can_frame[7] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].u16_MAX_V & 0xff00) >> 8;      //
            */
            rcvSecondCnt++;

            for (int k = 0; k < DLC; k++)
            {
                eventData[eventNo, recordNo, 0 + k] = canData[k];
            }

            /* Debugging */
            {
                //AddEventLogMessage("Event No = " + eventNo.ToString() + " , Record No = " +
                //                    recordNo.ToString() + ", " + rcvFirstCnt.ToString() + " , " +
                //                    rcvSecondCnt.ToString() + " , " + rcvThirdCnt.ToString());
                //AddEventLogMessage("   0x1A2 : " + eventNo.ToString() + " , " + recordNo.ToString());
                string str = "0x1A2 : ";
                if (ckbDisplayMessageEvent.Checked == true)
                {
                    for (int k = 0; k < 8; k++)
                    {
                        str += (" " + eventData[eventNo, recordNo, k + 0].ToString("X2"));
                    }
                    AddEventLogMessage(str + "\n");
                }
                else
                {
                    AddEventLogMessage(str);
                }
            }

            if (rcvFirstCnt >= RECORD_LENGTH && rcvSecondCnt >= RECORD_LENGTH && rcvThirdCnt >= RECORD_LENGTH)
            {
                eventNo++;
                recordNo = 0;
                rcvFirstCnt = 0;
                rcvSecondCnt = 0;
                rcvThirdCnt = 0;
            }
        }


        private void Display_RcvEvent_Third(int DLC, byte[] canData)
        {
            /*
            u8_can_frame[0] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].u16_MIN_V & 0x0000ff);     //	최소 셀 전압
            u8_can_frame[1] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].u16_MIN_V & 0x00ff00) >> 8;    //
            u8_can_frame[2] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].u16_PAC_V & 0x00ff00) >> 16;   //	Pack 전압
            u8_can_frame[3] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].u16_PAC_V & 0xff0000) >> 24;   //
            u8_can_frame[4] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].s16_PAC_I & 0x00ff);           //	Pack 전류
            u8_can_frame[5] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].s16_PAC_I & 0xff00) >> 8;      //
            u8_can_frame[6] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].s8_MAX_T & 0x00ff);            //	최대 온도
            u8_can_frame[7] = (EVENT_LOAD_DATA[_ERD.u16_AFTER_COUNT].s8_MIN_T & 0xff00) >> 8;		//	최소 온도
            */
            rcvThirdCnt++;

            for (int k = 0; k < DLC; k++)
            {
                eventData[eventNo, recordNo, 8 + k] = canData[k];
            }

            // txtCPFV.Text = (BitConverter.ToUInt16(canData, 0)).ToString();
            // txtCPFdV.Text = (BitConverter.ToUInt16(canData, 2)).ToString();
            // txtDPFV.Text = (BitConverter.ToUInt16(canData, 4)).ToString();
            // txtDPFdV.Text = (BitConverter.ToUInt16(canData, 6)).ToString();

            /* Debugging */
            {
                //AddEventLogMessage("Event No = " + eventNo.ToString() + " , Record No = " +
                //                    recordNo.ToString() + ", " + rcvFirstCnt.ToString() + " , " +
                //                    rcvSecondCnt.ToString() + " , " + rcvThirdCnt.ToString());
                //AddEventLogMessage("   0x1A3 : " + eventNo.ToString() + " , " + recordNo.ToString());
                string str = "0x1A3 : ";
                if (ckbDisplayMessageEvent.Checked == true)
                {
                    for (int k = 0; k < 8; k++)
                    {
                        str += (" " + eventData[eventNo, recordNo, k + 8].ToString("X2"));
                    }
                }
                AddEventLogMessage(str + "\n");

                #if false
                for (int j = 0; j < RECORD_LENGTH; j++)
                {
                    Console.Write("\n {0},{1} : ", eventNo.ToString(), j.ToString());
                    for (int k = 0; k < 16; k++)
                    {
                        Console.Write("{0}, ", eventData[eventNo, j, k].ToString("X2"));
                    }
                }
                Console.WriteLine();
                #endif  
            }

            if (rcvFirstCnt >= RECORD_LENGTH && rcvSecondCnt >= RECORD_LENGTH && rcvThirdCnt >= RECORD_LENGTH)
            {
                eventNo++;
                recordNo = 0;
                rcvFirstCnt = 0;
                rcvSecondCnt = 0;
                rcvThirdCnt = 0;
            }
        }

        private void AddEventLogMessage(string strMsg)
        {
            rtbEventLog.AppendText(strMsg);
            rtbEventLog.ScrollToCaret();
        }


        #region Key UP/Down
        private void lvwEventMain_KeyUp(object sender, KeyEventArgs e)
        {
            lvwEventMain_MouseClick_Process();  // EventArgs
        }

        private void lvwEventMain_KeyDown(object sender, KeyEventArgs e)
        {
            lvwEventMain_MouseClick_Process();
        }

        private void lvwEventDetail_KeyDown(object sender, KeyEventArgs e)
        {
            lvwEventDetail_MouseClick_Process();
        }

        private void lvwEventDetail_KeyUp(object sender, KeyEventArgs e)
        {
            lvwEventDetail_MouseClick_Process();
        }

        #endregion

        private void btnClearEventLog_Click(object sender, EventArgs e)
        {
            rtbEventLog.Clear();
        }


        private void btnEventReqStop_Click(object sender, EventArgs e)
        {
            timerRequestEvent.Stop();
            Update_EventList();
        }



        private void lvwEventDetail_MouseClick(object sender, MouseEventArgs e)
        {
            lvwEventDetail_MouseClick_Process();
        }

        private void lvwEventDetail_MouseClick_Process()
        {
            ListView.SelectedListViewItemCollection items = lvwEventDetail.SelectedItems;
            ListViewItem lvItem = items[0];
            string str = "";
            str += items[0].Text;  str += " ";              // No
            str += lvItem.SubItems[1].Text; ; str += " ";   // Time
            str += lvItem.SubItems[2].Text; ; str += " ";   // Code
            str += lvItem.SubItems[3].Text; ; str += " ";   // Volt
            str += lvItem.SubItems[4].Text; ; str += " ";   // Cell Max
            str += lvItem.SubItems[5].Text; ; str += " ";   // Cell Min
            str += lvItem.SubItems[6].Text; ; str += " ";   // Current
            str += lvItem.SubItems[7].Text; ; str += " ";   // Temp Max
            str += lvItem.SubItems[8].Text; ; str += " ";   // Temp Min
            //MessageBox.Show(str);
            //Console.WriteLine(str);

            UInt32 code = Convert.ToUInt32(lvItem.SubItems[2].Text, 16);
            //MessageBox.Show(code.ToString("X4"));
            string eventName = DisplayEventName(code);
            // Label 수정
            lblEventNameCode.Text = "( " + detailListViewIndex + " - " + items[0].Text + " , " + eventName + ", " + lvItem.SubItems[2].Text + " )";
        }
    }

}
