﻿namespace PCANBasicProject
{
    partial class Form_PCANRcvLog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.rtbCanMsg = new System.Windows.Forms.RichTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.btRtbInit = new System.Windows.Forms.Button();
            this.btRtbSave = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.timerLogDisplay = new System.Windows.Forms.Timer(this.components);
            this.btRtbPause = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // rtbCanMsg
            // 
            this.rtbCanMsg.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbCanMsg.HideSelection = false;
            this.rtbCanMsg.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.rtbCanMsg.Location = new System.Drawing.Point(3, 24);
            this.rtbCanMsg.MaxLength = 50000;
            this.rtbCanMsg.Name = "rtbCanMsg";
            this.rtbCanMsg.Size = new System.Drawing.Size(678, 522);
            this.rtbCanMsg.TabIndex = 169;
            this.rtbCanMsg.Text = "";
            this.rtbCanMsg.WordWrap = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(599, 12);
            this.label1.TabIndex = 168;
            this.label1.Text = "        Date Time           Type    ID             Data [0..7]                   " +
    "  Size     Interval      RcvTime[msec ]";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btRtbPause);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btRtbInit);
            this.panel1.Controls.Add(this.btRtbSave);
            this.panel1.Controls.Add(this.rtbCanMsg);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(695, 622);
            this.panel1.TabIndex = 170;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(12, 574);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(205, 21);
            this.label2.TabIndex = 172;
            this.label2.Text = "로그는 최대 50,000개 저장\r\n";
            // 
            // btRtbInit
            // 
            this.btRtbInit.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btRtbInit.Location = new System.Drawing.Point(564, 562);
            this.btRtbInit.Name = "btRtbInit";
            this.btRtbInit.Size = new System.Drawing.Size(105, 48);
            this.btRtbInit.TabIndex = 171;
            this.btRtbInit.Text = "로그 내용 삭제";
            this.btRtbInit.UseVisualStyleBackColor = true;
            this.btRtbInit.Click += new System.EventHandler(this.btRtbInit_Click);
            // 
            // btRtbSave
            // 
            this.btRtbSave.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btRtbSave.Location = new System.Drawing.Point(424, 562);
            this.btRtbSave.Name = "btRtbSave";
            this.btRtbSave.Size = new System.Drawing.Size(113, 48);
            this.btRtbSave.TabIndex = 170;
            this.btRtbSave.Text = "로그 내용 저장";
            this.btRtbSave.UseVisualStyleBackColor = true;
            this.btRtbSave.Click += new System.EventHandler(this.btRtbSave_Click);
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(695, 5);
            this.panel2.TabIndex = 171;
            // 
            // timerLogDisplay
            // 
            this.timerLogDisplay.Interval = 500;
            this.timerLogDisplay.Tick += new System.EventHandler(this.timerLogDisplay_Tick);
            // 
            // btRtbPause
            // 
            this.btRtbPause.Location = new System.Drawing.Point(242, 562);
            this.btRtbPause.Name = "btRtbPause";
            this.btRtbPause.Size = new System.Drawing.Size(75, 48);
            this.btRtbPause.TabIndex = 173;
            this.btRtbPause.Text = "일시 정지";
            this.btRtbPause.UseVisualStyleBackColor = true;
            this.btRtbPause.Click += new System.EventHandler(this.btRtbPause_Click);
            // 
            // Form_PCANRcvLog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(695, 622);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form_PCANRcvLog";
            this.Text = "PCAN 수신 메세지 - 수신 시간 기준";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rtbCanMsg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btRtbInit;
        private System.Windows.Forms.Button btRtbSave;
        private System.Windows.Forms.Timer timerLogDisplay;
        private System.Windows.Forms.Button btRtbPause;
    }
}