﻿using Peak.Can.Basic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

#if false
public enum TPCANMessageType : byte
{
    PCAN_MESSAGE_STANDARD = 0x00,   /// The PCAN message is a CAN Standard Frame (11-bit identifier)
    PCAN_MESSAGE_RTR = 0x01,        /// The PCAN message is a CAN Remote-Transfer-Request Frame
    PCAN_MESSAGE_EXTENDED = 0x02,   /// The PCAN message is a CAN Extended Frame (29-bit identifier)
    PCAN_MESSAGE_FD = 0x04,         /// The PCAN message represents a FD frame in terms of CiA Specs
    PCAN_MESSAGE_BRS = 0x08,        /// The PCAN message represents a FD bit rate switch (CAN data at a higher bit rate)
    PCAN_MESSAGE_ESI = 0x10,        /// The PCAN message represents a FD error state indicator(CAN FD transmitter was error active)
    PCAN_MESSAGE_ECHO = 0x20,       /// The PCAN message represents an echo CAN Frame
    PCAN_MESSAGE_ERRFRAME = 0x40,    /// The PCAN message represents an error frame
    PCAN_MESSAGE_STATUS = 0x80,     /// The PCAN message represents a PCAN status message
}
#endif

namespace PCANBasicProject
{
    public partial class Form_LB : Form
    {
        public Form_LB()
        {
            InitializeComponent();
        }


        public void DisplayMessages_Wacco_Form(byte msgType, uint ID, int DLC, byte[] canData)
        {

        }

        public void DisplayMessages_Wacco_Form(string strType, uint ID, int DLC, byte[] canData)
        {
            /*
            string Msg = "";
            Msg += (strType + " ");
            Msg += (ID.ToString("X3") + " ");
            for (int i = 0; i < DLC; i++) Msg += (canData[i].ToString("X2") + " ");
            Msg += (DLC.ToString() + " ");
            Msg += "\n";
            Console.Write(Msg);
            */

        }

        private void Form_Wacco_Load(object sender, EventArgs e)
        {

        }
    }
}

