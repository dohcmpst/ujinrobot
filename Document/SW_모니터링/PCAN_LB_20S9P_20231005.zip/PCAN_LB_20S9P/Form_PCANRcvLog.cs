﻿using Peak.Can.Basic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;


namespace PCANBasicProject
{
    public partial class Form_PCANRcvLog : Form
    {
        // global
        private class clsRcvData
        {
            enum SIZE :int
            {
                size = 50000    // 일시 정지 목적용
            }

            int m_push;
            int m_pop;
            string[] msg = new string[(int)SIZE.size];

            public void Push(string msgIn)
            {
                msg[m_push] = msgIn;
                if (++m_push >= (int)SIZE.size) m_push = 0;
            }

            public string Pop()
            {
                string rtnMsg = msg[m_pop];
                if (++m_pop >= (int)SIZE.size) m_pop = 0;
                return rtnMsg;
            }

            public bool remainMsg()
            {
                return (m_push != m_pop);
            }

        }
        clsRcvData rcvMsg;

        bool displayEnable = true;

        public Form_PCANRcvLog()
        {
            InitializeComponent();

            // log 창인 richTextBox 가 다른 창이 선택 되어도 내용 변경되도록 설정
            rtbCanMsg.HideSelection = false;

            // 데이터가 많으면 제어가 잘 안됨
            rtbCanMsg.WordWrap = false;     // 자동 개행 해제하고, Text에 "\n" 추가 -> 출력 속도는 개선이 되나 빠른 속도에 의해 모든 프로그램이 늦어짐
                                            // 콘솔 창으로만 출력하면 문제 없음 .
                                            // 재검토 : 델리게이트 사용 등, 우선 Timer 로 출력 속도를 지연 처리

            timerLogDisplay.Enabled = true;     // 창이 Open 되면 Enable
            rcvMsg = new clsRcvData();
        }

        public void DisplayMessages_Log(string Msg)
        {
            rtbCanMsg.AppendText(Msg);
            rtbCanMsg.SelectionStart = rtbCanMsg.Text.Length;
            //rtbCanMsg.ScrollToCaret();
        }

        public void DisplayMessages_Log(ListViewItem listMsg)
        {
            string msg = DateTime.Now.ToString("MM-dd HH:mm:ss.fff  ");     // ("yyyy-MM-dd HH:mm:ss.fff ");
            msg += (listMsg.SubItems[0].Text + "  ");
            msg += (listMsg.SubItems[1].Text + "  ");
            msg += (listMsg.SubItems[2].Text + "  ");
            msg += (listMsg.SubItems[3].Text + "   ");
            msg += (listMsg.SubItems[4].Text + "    ");
            msg += (listMsg.SubItems[5].Text + "    ");
            msg += (listMsg.SubItems[6].Text);
            msg += "\n";

            rtbCanMsg.AppendText(msg);
            rtbCanMsg.SelectionStart = rtbCanMsg.Text.Length;
         //   rtbCanMsg.ScrollToCaret();
        }

        int Count = 0;
        string prvRcvTime = "0";
        public void DisplayMessages_Log(string[] msgCan)
        {

            // richTextBox 인 rtbCanMsg.HideSelection = true; 로 하면 해당 창을 선택한 경우에 내용이 변경되고
            //                rtbCanMsg.HideSelection = false 로 하면 다른 창이 선택 되어도 내용 변경됨.
            string msg = Count++.ToString() + " : ";
            msg += DateTime.Now.ToString("MM-dd HH:mm:ss.fff  ");     // ("yyyy-MM-dd HH:mm:ss.fff ");
            msg += (msgCan[0] + "  ");      // Type
            msg += (msgCan[1] + "  ");      // ID
            msg += (msgCan[2] + "  ");      // Data
            msg += (msgCan[3] + "   ");     // DLC
            //msg += (msgCan[4] + "    ");    // Count -> 삭제
            //msg += (msgCan[5] + "    ");    // Period -> 이전 메세지와의 수신 시간 차이로 변경

            double newTime = Convert.ToDouble(msgCan[6]);
            double oldTime = Convert.ToDouble(prvRcvTime);
            if (newTime > oldTime)
                msg += (String.Format("{0,5:0.0}", (newTime - oldTime)) + "    ");
            else
                msg += (msgCan[5] + "    ");

            msg += (msgCan[6]);             // RcvTime
            msg += "\n";
            prvRcvTime = msgCan[6];         // 시간 계산을 위해 이전 값 저장

#if true
            rcvMsg.Push(msg);
            
#else       // 데이터를 event 로 처리하므로 빠른 시간내에 richTextBox 를 처리함으로써 양이 조금 많아지면 다른 프로그램 처리가 매우 느림.
            rtbCanMsg.AppendText(msg);
            rtbCanMsg.SelectionStart = rtbCanMsg.Text.Length;
            //  rtbCanMsg.ScrollToCaret();
#endif
        }

        private void btRtbSave_Click(object sender, EventArgs e)
        {
            // https://www.c-sharpcorner.com/UploadFile/mahesh/savefiledialog-in-C-Sharp/
            //
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            // Save Dialog 의 이름 
            saveFileDialog1.Title = "PCAN Log 저장 파일 설정 ";

            // 저장할 위치의 초기 디렉토리를 설정합니다.
            saveFileDialog1.InitialDirectory = @".\\Log";       // @ \"C:\";   저장 경로                        
            //saveFileDialog_CanLog.InitialDirectory = Environment.CurrentDirectory;  // Environment.CurrentDirectory: 현재 디렉토리를 나타냅니다.

            // 대화상자를 닫기 전에 디렉토리를 이전에 선택한 디렉토리로 복원한지의 여부를 나타납니다.
            saveFileDialog1.RestoreDirectory = true;

            // 폴더가 존재하는 지 확인 :
            saveFileDialog1.CheckPathExists = true;

            // 파일 확장자, 
            saveFileDialog1.AddExtension = true;  // 확장명을 입력하지 않을 때, 자동으로 확장자를 추가할 수 있습니다.
            saveFileDialog1.DefaultExt = "txt";
            saveFileDialog1.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 2;

            //초기 파일명을 지정할 때 사용한다.
            saveFileDialog1.FileName = "canLog_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".txt";
            // 파일이 존재하는 지 확인 : TRUE 로 선언, 파일이 없으면 안됨, false 로 하면 신규 파일이 생성됨.
            //saveFileDialog_CanLog.CheckFileExists = true;

            // 파일이 이미 존재하면 덮어쓰기 할지를 묻는 대화상자를 표시합니다.
            // 기본값: true
            saveFileDialog1.OverwritePrompt = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = new StreamWriter(saveFileDialog1.FileName))
                {
                    this.Text = "Date                Type  ID          Data             Size Count Period  RcvTime[msec]" + "\n\r";
                    sw.Write(Text);
                    sw.Write(rtbCanMsg.Text);
                }
            }
        }

        private void btRtbInit_Click(object sender, EventArgs e)
        {
            rtbCanMsg.Clear();
        }

        private void timerLogDisplay_Tick(object sender, EventArgs e)
        {
            if (displayEnable)
            {
                for (int loop = 0; loop < 100 && rcvMsg.remainMsg(); loop++)
                {
                    string msg = rcvMsg.Pop();

                    rtbCanMsg.AppendText(msg);
                    //rtbCanMsg.SelectionStart = rtbCanMsg.Text.Length;
                    // rtbCanMsg.ScrollToCaret();
                }
            }
        }

        private void btRtbPause_Click(object sender, EventArgs e)
        {
            if ( displayEnable == true )
            {
                displayEnable = false;
                btRtbPause.Text = "로그 표시";
            }
            else
            {
                displayEnable = true;
                btRtbPause.Text = "일시 정지";
            }
        }
    }
}
