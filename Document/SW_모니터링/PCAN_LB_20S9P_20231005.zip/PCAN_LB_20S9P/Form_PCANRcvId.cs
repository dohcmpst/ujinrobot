﻿using Peak.Can.Basic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PCANBasicProject;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement;
//using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;
using System.Diagnostics;
using System.Reflection;
using System.Globalization;
//using PCANBasicProject;

namespace PCANBasicProject
{
    public partial class Form_PCANRcvId : Form
    {
        public Form_PCANRcvId()
        {
            InitializeComponent();
        }

        #region ListView_Extension
        class ListViewNF : System.Windows.Forms.ListView
        {
            public ListViewNF()
            {
                //Activate double buffering
                this.SetStyle(ControlStyles.OptimizedDoubleBuffer | ControlStyles.AllPaintingInWmPaint, true);

                //Enable the OnNotifyMessage event so we get a chance to filter out 
                // Windows messages before they get to the form's WndProc
                this.SetStyle(ControlStyles.EnableNotifyMessage, true);
            }

            protected override void OnNotifyMessage(Message m)
            {
                //Filter out the WM_ERASEBKGND message
                if (m.Msg != 0x14)
                {
                    base.OnNotifyMessage(m);
                }
            }
        }
        #endregion

        #region Sorter
        class Sorter : System.Collections.IComparer
        {
            public int Column = 0;
            public System.Windows.Forms.SortOrder Order = SortOrder.Ascending;
            public int Compare(object x, object y) // IComparer Member
            {
                if (!(x is ListViewItem))
                    return (0);
                if (!(y is ListViewItem))
                    return (0);

                ListViewItem l1 = (ListViewItem)x;
                ListViewItem l2 = (ListViewItem)y;

                if (l1.ListView.Columns[Column].Tag == null) // 리스트뷰 Tag 속성이 Null 이면 기본적으로 Text 정렬을 사용하겠다는 의미
                {
                    l1.ListView.Columns[Column].Tag = "Text";
                }

                if (l1.ListView.Columns[Column].Tag.ToString() == "Numeric") // 리스트뷰 Tag 속성이 Numeric 이면 숫자 정렬을 사용하겠다는 의미
                {

                    string str1 = l1.SubItems[Column].Text;
                    string str2 = l2.SubItems[Column].Text;

                    if (str1 == "")
                    {
                        str1 = "99999";
                    }
                    if (str2 == "")
                    {
                        str2 = "99999";
                    }

                    float fl1 = float.Parse(str1);    //숫자형식으로 변환해서 비교해야 숫자정렬이 되겠죠?
                    float fl2 = float.Parse(str2);    //숫자형식으로 변환해서 비교해야 숫자정렬이 되겠죠?

                    if (Order == SortOrder.Ascending)
                    {
                        return fl1.CompareTo(fl2);
                    }
                    else
                    {
                        return fl2.CompareTo(fl1);
                    }
                }
                else
                {                                             // 이하는 텍스트 정렬 방식
                    string str1 = l1.SubItems[Column].Text;
                    string str2 = l2.SubItems[Column].Text;

                    if (Order == SortOrder.Ascending)
                    {
                        return str1.CompareTo(str2);
                    }
                    else
                    {
                        return str2.CompareTo(str1);
                    }
                }
            }
        }
        #endregion

        public void DisplayMessages_ID(ListViewItem listMsg, int positiion)
        {
            // 처리 못함.
        }
        public void DisplayMessages_ID(string[] Msg, int positiion)
        {
            ListViewItem item;
            bool alreadyItem = false;

            // Debugging
            //string debug = "";
            //debug += "[" + lstMessages.Items.Count.ToString() + "] ";
            //debug += positiion.ToString();
            //debug += " " + Msg[0] + " " + Msg[1] + " " + Msg[2] + " " + Msg[3] + " " + Msg[4] + " " + Msg[5] + " " + Msg[6];
            //Console.WriteLine(debug);

            // ListView 설정은 속성 창에서 지정했음.

            // 리스트뷰 아이템을 업데이트 하기 시작.
            // 업데이트가 끝날 때까지 UI 갱신 중지.
            lstMessages.BeginUpdate();

            // Data 생성
            item = new ListViewItem(Msg[0]);     // Type
            item.SubItems.Add(Msg[1]);           // ID
            item.SubItems.Add(Msg[2]);           // Data
            item.SubItems.Add(Msg[3]);           // Length
            item.SubItems.Add(Msg[4]);           // Count 
            item.SubItems.Add(Msg[5]);           // Period
            item.SubItems.Add(Msg[6]);           // Rcv Time

            // ID 비교
            for (int i = 0; i < lstMessages.Items.Count; i++)   //  Listview의 갯수 확인은 Listview이름.Items.Count
            {                                                   // ListView의 Item의 값을 확인하려면 Listviw이름.Items[index].SubItems[index].Tex
                if (lstMessages.Items[i].SubItems[1].Text.Equals(Msg[1].Trim()))    // Msg[1] -> ID, Items의 index는 행, SubItems의 index는 옆으로 몇번째 컬럼
                {                                                                   // index는 당연하게 0부터 시작이다.
                    alreadyItem = true;
                    if (false)       // Column 변경이 많아서 전체를 수정하는 것으로 함
                    {
                        // Delete & Insert
                        //lstMessages.Items.RemoveAt(i);
                        //lstMessages.Items.Insert(i, item);
                    }
                    else
                    {
                        //  Column 값 변경
                        // 별도의 ListVew 를 관리 안하므로, Count 와 Period 는 계산해야 됨,
                        lstMessages.Items[i].SubItems[2].Text = Msg[2];
                        lstMessages.Items[i].SubItems[3].Text = Msg[3];
                        
                        if (false)
                        {
                            //lstMessages.Items[i].SubItems[4].Text = Msg[4]; // Count   
                        }
                        else
                        {
                            UInt32 Count = Convert.ToUInt32(lstMessages.Items[i].SubItems[4].Text);
                            lstMessages.Items[i].SubItems[4].Text = (Count + 1).ToString();
                        }
                        if (false)
                        {
                            //lstMessages.Items[i].SubItems[5].Text = Msg[5]; // Period
                        }
                        else
                        {
                            double newTime = Convert.ToDouble(Msg[6]);
                            double oldTime = Convert.ToDouble(lstMessages.Items[i].SubItems[6].Text);

                            if (newTime > oldTime)
                                lstMessages.Items[i].SubItems[5].Text = (newTime - oldTime).ToString("#.#");
                            else
                                lstMessages.Items[i].SubItems[5].Text = Msg[5];

                        }
                        lstMessages.Items[i].SubItems[6].Text = Msg[6]; // Rcv Time
                    }
                }
            }
            if (alreadyItem == false)
            {
                // 새로운 메세지를 추가
                lstMessages.Items.Add(item);    // ListViewItem객체를 Items 속성에 추가

                // Perform the sort with these new sort options.
                lstMessages.ListViewItemSorter = new Sorter();      // * 1
                Sorter s = (Sorter)lstMessages.ListViewItemSorter;
                lstMessages.Sorting = SortOrder.Ascending;  //lstMessages.Sorting = SortOrder.Descending;
                s.Order = lstMessages.Sorting;
                s.Column = 1;   // Msg[1] = ID,      // e.Column; -> 이벤트 인수로 받을 때
                lstMessages.Sort();

            }

            // 리스뷰를 Refresh하여 보여줌
            lstMessages.EndUpdate();
            
        }
    }
}

