﻿namespace PCANBasicProject
{
    partial class Form_LB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_LB));
            this.label2 = new System.Windows.Forms.Label();
            this.tbVer = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbSN = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tbMan = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.tbCycleCount = new System.Windows.Forms.TextBox();
            this.gb100h = new System.Windows.Forms.GroupBox();
            this.gb101h = new System.Windows.Forms.GroupBox();
            this.tbSOC = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbSOH = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.gb102h = new System.Windows.Forms.GroupBox();
            this.tbCurrent = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ttbVoltIn = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.tbVoltOut = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tbSOP = new System.Windows.Forms.TextBox();
            this.gb103h = new System.Windows.Forms.GroupBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.gb104h = new System.Windows.Forms.GroupBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.gb105h = new System.Windows.Forms.GroupBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.gb106h = new System.Windows.Forms.GroupBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.gb107h = new System.Windows.Forms.GroupBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.gb108h = new System.Windows.Forms.GroupBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.gb109h = new System.Windows.Forms.GroupBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.gb10Dh = new System.Windows.Forms.GroupBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.gb10Eh = new System.Windows.Forms.GroupBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.gb10Fh = new System.Windows.Forms.GroupBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.gb110h = new System.Windows.Forms.GroupBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.gb118h = new System.Windows.Forms.GroupBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.gb2C0h = new System.Windows.Forms.GroupBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.gb120h = new System.Windows.Forms.GroupBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox70 = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox71 = new System.Windows.Forms.TextBox();
            this.textBox72 = new System.Windows.Forms.TextBox();
            this.textBox73 = new System.Windows.Forms.TextBox();
            this.textBox74 = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.richTextBox3 = new System.Windows.Forms.RichTextBox();
            this.label71 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.gb100h.SuspendLayout();
            this.gb101h.SuspendLayout();
            this.gb102h.SuspendLayout();
            this.gb103h.SuspendLayout();
            this.gb104h.SuspendLayout();
            this.gb105h.SuspendLayout();
            this.gb106h.SuspendLayout();
            this.gb107h.SuspendLayout();
            this.gb108h.SuspendLayout();
            this.gb109h.SuspendLayout();
            this.gb10Dh.SuspendLayout();
            this.gb10Eh.SuspendLayout();
            this.gb10Fh.SuspendLayout();
            this.gb110h.SuspendLayout();
            this.gb118h.SuspendLayout();
            this.gb2C0h.SuspendLayout();
            this.gb120h.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Version";
            // 
            // tbVer
            // 
            this.tbVer.Location = new System.Drawing.Point(92, 20);
            this.tbVer.Name = "tbVer";
            this.tbVer.Size = new System.Drawing.Size(100, 23);
            this.tbVer.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Serial No";
            // 
            // tbSN
            // 
            this.tbSN.Location = new System.Drawing.Point(92, 47);
            this.tbSN.Name = "tbSN";
            this.tbSN.Size = new System.Drawing.Size(100, 23);
            this.tbSN.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(75, 15);
            this.label3.TabIndex = 0;
            this.label3.Text = "Manufacture";
            // 
            // tbMan
            // 
            this.tbMan.Location = new System.Drawing.Point(92, 74);
            this.tbMan.Name = "tbMan";
            this.tbMan.Size = new System.Drawing.Size(100, 23);
            this.tbMan.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 104);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "Cycle Count";
            // 
            // tbCycleCount
            // 
            this.tbCycleCount.Location = new System.Drawing.Point(92, 101);
            this.tbCycleCount.Name = "tbCycleCount";
            this.tbCycleCount.Size = new System.Drawing.Size(100, 23);
            this.tbCycleCount.TabIndex = 1;
            // 
            // gb100h
            // 
            this.gb100h.Controls.Add(this.label69);
            this.gb100h.Controls.Add(this.tbVer);
            this.gb100h.Controls.Add(this.tbCycleCount);
            this.gb100h.Controls.Add(this.label2);
            this.gb100h.Controls.Add(this.tbSN);
            this.gb100h.Controls.Add(this.label3);
            this.gb100h.Controls.Add(this.label4);
            this.gb100h.Controls.Add(this.tbMan);
            this.gb100h.Controls.Add(this.label1);
            this.gb100h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb100h.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.gb100h.Location = new System.Drawing.Point(17, 12);
            this.gb100h.Name = "gb100h";
            this.gb100h.Size = new System.Drawing.Size(226, 137);
            this.gb100h.TabIndex = 2;
            this.gb100h.TabStop = false;
            this.gb100h.Text = "0x100";
            // 
            // gb101h
            // 
            this.gb101h.Controls.Add(this.label70);
            this.gb101h.Controls.Add(this.tbSOC);
            this.gb101h.Controls.Add(this.label5);
            this.gb101h.Controls.Add(this.tbSOP);
            this.gb101h.Controls.Add(this.label11);
            this.gb101h.Controls.Add(this.tbSOH);
            this.gb101h.Controls.Add(this.label8);
            this.gb101h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb101h.ForeColor = System.Drawing.SystemColors.Highlight;
            this.gb101h.Location = new System.Drawing.Point(249, 12);
            this.gb101h.Name = "gb101h";
            this.gb101h.Size = new System.Drawing.Size(286, 137);
            this.gb101h.TabIndex = 2;
            this.gb101h.TabStop = false;
            this.gb101h.Text = "0x101";
            // 
            // tbSOC
            // 
            this.tbSOC.Location = new System.Drawing.Point(92, 20);
            this.tbSOC.Name = "tbSOC";
            this.tbSOC.Size = new System.Drawing.Size(100, 23);
            this.tbSOC.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(70, 15);
            this.label5.TabIndex = 0;
            this.label5.Text = "SOC (0.1%)";
            // 
            // tbSOH
            // 
            this.tbSOH.Location = new System.Drawing.Point(92, 47);
            this.tbSOH.Name = "tbSOH";
            this.tbSOH.Size = new System.Drawing.Size(100, 23);
            this.tbSOH.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 50);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 15);
            this.label8.TabIndex = 0;
            this.label8.Text = "SOH (%)";
            // 
            // gb102h
            // 
            this.gb102h.Controls.Add(this.tbCurrent);
            this.gb102h.Controls.Add(this.label6);
            this.gb102h.Controls.Add(this.ttbVoltIn);
            this.gb102h.Controls.Add(this.label7);
            this.gb102h.Controls.Add(this.tbVoltOut);
            this.gb102h.Controls.Add(this.label10);
            this.gb102h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb102h.ForeColor = System.Drawing.SystemColors.Highlight;
            this.gb102h.Location = new System.Drawing.Point(541, 12);
            this.gb102h.Name = "gb102h";
            this.gb102h.Size = new System.Drawing.Size(226, 137);
            this.gb102h.TabIndex = 2;
            this.gb102h.TabStop = false;
            this.gb102h.Text = "0x102";
            // 
            // tbCurrent
            // 
            this.tbCurrent.Location = new System.Drawing.Point(120, 16);
            this.tbCurrent.Name = "tbCurrent";
            this.tbCurrent.Size = new System.Drawing.Size(100, 23);
            this.tbCurrent.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 15);
            this.label6.TabIndex = 0;
            this.label6.Text = "Current (0.01A)";
            // 
            // ttbVoltIn
            // 
            this.ttbVoltIn.Location = new System.Drawing.Point(120, 59);
            this.ttbVoltIn.Name = "ttbVoltIn";
            this.ttbVoltIn.Size = new System.Drawing.Size(100, 23);
            this.ttbVoltIn.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 85);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(144, 15);
            this.label7.TabIndex = 0;
            this.label7.Text = "Voltage(Pack Out, 0.01V)";
            // 
            // tbVoltOut
            // 
            this.tbVoltOut.Location = new System.Drawing.Point(120, 104);
            this.tbVoltOut.Name = "tbVoltOut";
            this.tbVoltOut.Size = new System.Drawing.Size(100, 23);
            this.tbVoltOut.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(13, 42);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(131, 15);
            this.label10.TabIndex = 0;
            this.label10.Text = "Voltage(Pack In, ).01V)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(13, 80);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(67, 15);
            this.label11.TabIndex = 0;
            this.label11.Text = "SOP (0.1A)";
            // 
            // tbSOP
            // 
            this.tbSOP.Location = new System.Drawing.Point(92, 77);
            this.tbSOP.Name = "tbSOP";
            this.tbSOP.Size = new System.Drawing.Size(100, 23);
            this.tbSOP.TabIndex = 1;
            // 
            // gb103h
            // 
            this.gb103h.Controls.Add(this.textBox8);
            this.gb103h.Controls.Add(this.textBox12);
            this.gb103h.Controls.Add(this.label9);
            this.gb103h.Controls.Add(this.textBox13);
            this.gb103h.Controls.Add(this.label12);
            this.gb103h.Controls.Add(this.label13);
            this.gb103h.Controls.Add(this.textBox14);
            this.gb103h.Controls.Add(this.label14);
            this.gb103h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb103h.Location = new System.Drawing.Point(793, 12);
            this.gb103h.Name = "gb103h";
            this.gb103h.Size = new System.Drawing.Size(226, 137);
            this.gb103h.TabIndex = 2;
            this.gb103h.TabStop = false;
            this.gb103h.Text = "0x103";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(92, 20);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 23);
            this.textBox8.TabIndex = 1;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(92, 101);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 23);
            this.textBox12.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 23);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 15);
            this.label9.TabIndex = 0;
            this.label9.Text = "BMS Fault";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(92, 47);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 23);
            this.textBox13.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 77);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 15);
            this.label12.TabIndex = 0;
            this.label12.Text = "BMS Status";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(13, 104);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(81, 15);
            this.label13.TabIndex = 0;
            this.label13.Text = "BMS Status-2";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(92, 74);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 23);
            this.textBox14.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(13, 50);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(68, 15);
            this.label14.TabIndex = 0;
            this.label14.Text = "BMS Alarm";
            // 
            // gb104h
            // 
            this.gb104h.Controls.Add(this.textBox15);
            this.gb104h.Controls.Add(this.label15);
            this.gb104h.Controls.Add(this.textBox17);
            this.gb104h.Controls.Add(this.label16);
            this.gb104h.Controls.Add(this.textBox18);
            this.gb104h.Controls.Add(this.label18);
            this.gb104h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb104h.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.gb104h.Location = new System.Drawing.Point(1041, 12);
            this.gb104h.Name = "gb104h";
            this.gb104h.Size = new System.Drawing.Size(226, 137);
            this.gb104h.TabIndex = 2;
            this.gb104h.TabStop = false;
            this.gb104h.Text = "0x104";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(92, 20);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 23);
            this.textBox15.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(13, 23);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(88, 15);
            this.label15.TabIndex = 0;
            this.label15.Text = "BMS Balancing";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(92, 47);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(100, 23);
            this.textBox17.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(13, 77);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(86, 15);
            this.label16.TabIndex = 0;
            this.label16.Text = "RC (잔존 용량)";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(92, 74);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 23);
            this.textBox18.TabIndex = 1;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(13, 50);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 15);
            this.label18.TabIndex = 0;
            this.label18.Text = "FCC";
            // 
            // gb105h
            // 
            this.gb105h.Controls.Add(this.textBox16);
            this.gb105h.Controls.Add(this.label21);
            this.gb105h.Controls.Add(this.label20);
            this.gb105h.Controls.Add(this.label19);
            this.gb105h.Controls.Add(this.label17);
            this.gb105h.Controls.Add(this.textBox19);
            this.gb105h.Controls.Add(this.textBox21);
            this.gb105h.Controls.Add(this.textBox20);
            this.gb105h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb105h.ForeColor = System.Drawing.SystemColors.Highlight;
            this.gb105h.Location = new System.Drawing.Point(17, 155);
            this.gb105h.Name = "gb105h";
            this.gb105h.Size = new System.Drawing.Size(226, 142);
            this.gb105h.TabIndex = 2;
            this.gb105h.TabStop = false;
            this.gb105h.Text = "0x105";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(92, 20);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 23);
            this.textBox16.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(13, 23);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 15);
            this.label17.TabIndex = 0;
            this.label17.Text = "Cell-01 (mV)";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(92, 47);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(100, 23);
            this.textBox19.TabIndex = 1;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(92, 77);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 23);
            this.textBox20.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(13, 50);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(77, 15);
            this.label19.TabIndex = 0;
            this.label19.Text = "Cell-02 (mV)";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(13, 77);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(77, 15);
            this.label20.TabIndex = 0;
            this.label20.Text = "Cell-03 (mV)";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(13, 109);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(66, 15);
            this.label21.TabIndex = 0;
            this.label21.Text = "Cell-04 (V)";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(92, 106);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(100, 23);
            this.textBox21.TabIndex = 1;
            // 
            // gb106h
            // 
            this.gb106h.Controls.Add(this.textBox22);
            this.gb106h.Controls.Add(this.label22);
            this.gb106h.Controls.Add(this.label23);
            this.gb106h.Controls.Add(this.label24);
            this.gb106h.Controls.Add(this.label25);
            this.gb106h.Controls.Add(this.textBox23);
            this.gb106h.Controls.Add(this.textBox24);
            this.gb106h.Controls.Add(this.textBox25);
            this.gb106h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb106h.ForeColor = System.Drawing.SystemColors.Highlight;
            this.gb106h.Location = new System.Drawing.Point(288, 155);
            this.gb106h.Name = "gb106h";
            this.gb106h.Size = new System.Drawing.Size(226, 142);
            this.gb106h.TabIndex = 2;
            this.gb106h.TabStop = false;
            this.gb106h.Text = "0x106";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(92, 20);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 23);
            this.textBox22.TabIndex = 1;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(13, 109);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(66, 15);
            this.label22.TabIndex = 0;
            this.label22.Text = "Cell-08 (V)";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(13, 77);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(66, 15);
            this.label23.TabIndex = 0;
            this.label23.Text = "Cell-07 (V)";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(13, 50);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(66, 15);
            this.label24.TabIndex = 0;
            this.label24.Text = "Cell-06 (V)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(13, 23);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(66, 15);
            this.label25.TabIndex = 0;
            this.label25.Text = "Cell-05 (V)";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(92, 47);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(100, 23);
            this.textBox23.TabIndex = 1;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(92, 106);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 23);
            this.textBox24.TabIndex = 1;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(92, 77);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(100, 23);
            this.textBox25.TabIndex = 1;
            // 
            // gb107h
            // 
            this.gb107h.Controls.Add(this.textBox26);
            this.gb107h.Controls.Add(this.label26);
            this.gb107h.Controls.Add(this.label27);
            this.gb107h.Controls.Add(this.label28);
            this.gb107h.Controls.Add(this.label29);
            this.gb107h.Controls.Add(this.textBox27);
            this.gb107h.Controls.Add(this.textBox28);
            this.gb107h.Controls.Add(this.textBox29);
            this.gb107h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb107h.ForeColor = System.Drawing.SystemColors.Highlight;
            this.gb107h.Location = new System.Drawing.Point(541, 155);
            this.gb107h.Name = "gb107h";
            this.gb107h.Size = new System.Drawing.Size(226, 142);
            this.gb107h.TabIndex = 2;
            this.gb107h.TabStop = false;
            this.gb107h.Text = "0x107";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(92, 20);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(100, 23);
            this.textBox26.TabIndex = 1;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(13, 109);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(66, 15);
            this.label26.TabIndex = 0;
            this.label26.Text = "Cell-12 (V)";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(13, 77);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(66, 15);
            this.label27.TabIndex = 0;
            this.label27.Text = "Cell-11 (V)";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(13, 50);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(66, 15);
            this.label28.TabIndex = 0;
            this.label28.Text = "Cell-10 (V)";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(13, 23);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(66, 15);
            this.label29.TabIndex = 0;
            this.label29.Text = "Cell-09 (V)";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(92, 47);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(100, 23);
            this.textBox27.TabIndex = 1;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(92, 106);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(100, 23);
            this.textBox28.TabIndex = 1;
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(92, 77);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(100, 23);
            this.textBox29.TabIndex = 1;
            // 
            // gb108h
            // 
            this.gb108h.Controls.Add(this.textBox30);
            this.gb108h.Controls.Add(this.label30);
            this.gb108h.Controls.Add(this.label31);
            this.gb108h.Controls.Add(this.label32);
            this.gb108h.Controls.Add(this.label33);
            this.gb108h.Controls.Add(this.textBox31);
            this.gb108h.Controls.Add(this.textBox32);
            this.gb108h.Controls.Add(this.textBox33);
            this.gb108h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb108h.ForeColor = System.Drawing.SystemColors.Highlight;
            this.gb108h.Location = new System.Drawing.Point(793, 155);
            this.gb108h.Name = "gb108h";
            this.gb108h.Size = new System.Drawing.Size(226, 142);
            this.gb108h.TabIndex = 2;
            this.gb108h.TabStop = false;
            this.gb108h.Text = "0x108";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(92, 20);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(100, 23);
            this.textBox30.TabIndex = 1;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(13, 109);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(66, 15);
            this.label30.TabIndex = 0;
            this.label30.Text = "Cell-16 (V)";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(13, 77);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(66, 15);
            this.label31.TabIndex = 0;
            this.label31.Text = "Cell-15 (V)";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(13, 50);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(66, 15);
            this.label32.TabIndex = 0;
            this.label32.Text = "Cell-14 (V)";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(13, 23);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(66, 15);
            this.label33.TabIndex = 0;
            this.label33.Text = "Cell-13 (V)";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(92, 47);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(100, 23);
            this.textBox31.TabIndex = 1;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(92, 106);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(100, 23);
            this.textBox32.TabIndex = 1;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(92, 77);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(100, 23);
            this.textBox33.TabIndex = 1;
            // 
            // gb109h
            // 
            this.gb109h.Controls.Add(this.textBox34);
            this.gb109h.Controls.Add(this.label34);
            this.gb109h.Controls.Add(this.label35);
            this.gb109h.Controls.Add(this.label36);
            this.gb109h.Controls.Add(this.label37);
            this.gb109h.Controls.Add(this.textBox35);
            this.gb109h.Controls.Add(this.textBox36);
            this.gb109h.Controls.Add(this.textBox37);
            this.gb109h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb109h.ForeColor = System.Drawing.SystemColors.Highlight;
            this.gb109h.Location = new System.Drawing.Point(1041, 155);
            this.gb109h.Name = "gb109h";
            this.gb109h.Size = new System.Drawing.Size(226, 142);
            this.gb109h.TabIndex = 2;
            this.gb109h.TabStop = false;
            this.gb109h.Text = "0x109";
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(92, 20);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(100, 23);
            this.textBox34.TabIndex = 1;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(13, 109);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(77, 15);
            this.label34.TabIndex = 0;
            this.label34.Text = "Cell-20 (mV)";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(13, 77);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(66, 15);
            this.label35.TabIndex = 0;
            this.label35.Text = "Cell-19 (V)";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(13, 50);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(66, 15);
            this.label36.TabIndex = 0;
            this.label36.Text = "Cell-18 (V)";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(13, 23);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(66, 15);
            this.label37.TabIndex = 0;
            this.label37.Text = "Cell-17 (V)";
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(92, 47);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(100, 23);
            this.textBox35.TabIndex = 1;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(92, 106);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(100, 23);
            this.textBox36.TabIndex = 1;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(92, 77);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(100, 23);
            this.textBox37.TabIndex = 1;
            // 
            // gb10Dh
            // 
            this.gb10Dh.Controls.Add(this.textBox38);
            this.gb10Dh.Controls.Add(this.label38);
            this.gb10Dh.Controls.Add(this.label39);
            this.gb10Dh.Controls.Add(this.label40);
            this.gb10Dh.Controls.Add(this.label41);
            this.gb10Dh.Controls.Add(this.textBox39);
            this.gb10Dh.Controls.Add(this.textBox40);
            this.gb10Dh.Controls.Add(this.textBox41);
            this.gb10Dh.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb10Dh.ForeColor = System.Drawing.SystemColors.Highlight;
            this.gb10Dh.Location = new System.Drawing.Point(17, 303);
            this.gb10Dh.Name = "gb10Dh";
            this.gb10Dh.Size = new System.Drawing.Size(226, 140);
            this.gb10Dh.TabIndex = 2;
            this.gb10Dh.TabStop = false;
            this.gb10Dh.Text = "0x10D";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(92, 20);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(100, 23);
            this.textBox38.TabIndex = 1;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(13, 109);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(74, 15);
            this.label38.TabIndex = 0;
            this.label38.Text = "Max Cell No";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(13, 77);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(61, 15);
            this.label39.TabIndex = 0;
            this.label39.Text = "Max (mV)";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(13, 50);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(72, 15);
            this.label40.TabIndex = 0;
            this.label40.Text = "MIn Cell No";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(13, 23);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(59, 15);
            this.label41.TabIndex = 0;
            this.label41.Text = "Min (mV)";
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(92, 47);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(100, 23);
            this.textBox39.TabIndex = 1;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(92, 106);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(100, 23);
            this.textBox40.TabIndex = 1;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(92, 77);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(100, 23);
            this.textBox41.TabIndex = 1;
            // 
            // gb10Eh
            // 
            this.gb10Eh.Controls.Add(this.textBox42);
            this.gb10Eh.Controls.Add(this.label42);
            this.gb10Eh.Controls.Add(this.label43);
            this.gb10Eh.Controls.Add(this.label44);
            this.gb10Eh.Controls.Add(this.label45);
            this.gb10Eh.Controls.Add(this.textBox43);
            this.gb10Eh.Controls.Add(this.textBox44);
            this.gb10Eh.Controls.Add(this.textBox45);
            this.gb10Eh.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb10Eh.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.gb10Eh.Location = new System.Drawing.Point(288, 303);
            this.gb10Eh.Name = "gb10Eh";
            this.gb10Eh.Size = new System.Drawing.Size(226, 140);
            this.gb10Eh.TabIndex = 2;
            this.gb10Eh.TabStop = false;
            this.gb10Eh.Text = "0x10E";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(92, 20);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(100, 23);
            this.textBox42.TabIndex = 1;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(13, 109);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(62, 15);
            this.label42.TabIndex = 0;
            this.label42.Text = "Temp-Diff";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(13, 77);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(66, 15);
            this.label43.TabIndex = 0;
            this.label43.Text = "Temp-AVG";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(13, 50);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(58, 15);
            this.label44.TabIndex = 0;
            this.label44.Text = "Diff (mV)";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(13, 23);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(62, 15);
            this.label45.TabIndex = 0;
            this.label45.Text = "AVG (mV)";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(92, 47);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(100, 23);
            this.textBox43.TabIndex = 1;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(92, 106);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(100, 23);
            this.textBox44.TabIndex = 1;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(92, 77);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(100, 23);
            this.textBox45.TabIndex = 1;
            // 
            // gb10Fh
            // 
            this.gb10Fh.Controls.Add(this.textBox46);
            this.gb10Fh.Controls.Add(this.label46);
            this.gb10Fh.Controls.Add(this.label47);
            this.gb10Fh.Controls.Add(this.label48);
            this.gb10Fh.Controls.Add(this.label49);
            this.gb10Fh.Controls.Add(this.textBox47);
            this.gb10Fh.Controls.Add(this.textBox48);
            this.gb10Fh.Controls.Add(this.textBox49);
            this.gb10Fh.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb10Fh.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.gb10Fh.Location = new System.Drawing.Point(541, 303);
            this.gb10Fh.Name = "gb10Fh";
            this.gb10Fh.Size = new System.Drawing.Size(226, 140);
            this.gb10Fh.TabIndex = 2;
            this.gb10Fh.TabStop = false;
            this.gb10Fh.Text = "0x10F";
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(92, 20);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(100, 23);
            this.textBox46.TabIndex = 1;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(13, 109);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(96, 15);
            this.label46.TabIndex = 0;
            this.label46.Text = "Temp-04 (0.1℃)";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(13, 77);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(96, 15);
            this.label47.TabIndex = 0;
            this.label47.Text = "Temp-03 (0.1℃)";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(13, 50);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(96, 15);
            this.label48.TabIndex = 0;
            this.label48.Text = "Temp-02 (0.1℃)";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(13, 23);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(96, 15);
            this.label49.TabIndex = 0;
            this.label49.Text = "Temp-01 (0.1℃)";
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(92, 47);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(100, 23);
            this.textBox47.TabIndex = 1;
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(92, 106);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(100, 23);
            this.textBox48.TabIndex = 1;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(92, 77);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(100, 23);
            this.textBox49.TabIndex = 1;
            // 
            // gb110h
            // 
            this.gb110h.Controls.Add(this.textBox50);
            this.gb110h.Controls.Add(this.label50);
            this.gb110h.Controls.Add(this.label51);
            this.gb110h.Controls.Add(this.label52);
            this.gb110h.Controls.Add(this.label53);
            this.gb110h.Controls.Add(this.textBox51);
            this.gb110h.Controls.Add(this.textBox52);
            this.gb110h.Controls.Add(this.textBox53);
            this.gb110h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb110h.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.gb110h.Location = new System.Drawing.Point(793, 303);
            this.gb110h.Name = "gb110h";
            this.gb110h.Size = new System.Drawing.Size(226, 140);
            this.gb110h.TabIndex = 2;
            this.gb110h.TabStop = false;
            this.gb110h.Text = "0x110";
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(92, 20);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(100, 23);
            this.textBox50.TabIndex = 1;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(13, 109);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(100, 15);
            this.label50.TabIndex = 0;
            this.label50.Text = "Temp-FET (0.1℃)";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(13, 77);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(96, 15);
            this.label51.TabIndex = 0;
            this.label51.Text = "Temp-07 (0.1℃)";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(13, 50);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(96, 15);
            this.label52.TabIndex = 0;
            this.label52.Text = "Temp-06 (0.1℃)";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(13, 23);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(96, 15);
            this.label53.TabIndex = 0;
            this.label53.Text = "Temp-05 (0.1℃)";
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(92, 47);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(100, 23);
            this.textBox51.TabIndex = 1;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(92, 106);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(100, 23);
            this.textBox52.TabIndex = 1;
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(92, 77);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(100, 23);
            this.textBox53.TabIndex = 1;
            // 
            // gb118h
            // 
            this.gb118h.Controls.Add(this.textBox54);
            this.gb118h.Controls.Add(this.label54);
            this.gb118h.Controls.Add(this.label55);
            this.gb118h.Controls.Add(this.label56);
            this.gb118h.Controls.Add(this.label57);
            this.gb118h.Controls.Add(this.textBox55);
            this.gb118h.Controls.Add(this.textBox56);
            this.gb118h.Controls.Add(this.textBox57);
            this.gb118h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb118h.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.gb118h.Location = new System.Drawing.Point(1041, 303);
            this.gb118h.Name = "gb118h";
            this.gb118h.Size = new System.Drawing.Size(226, 140);
            this.gb118h.TabIndex = 2;
            this.gb118h.TabStop = false;
            this.gb118h.Text = "0x118";
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(92, 20);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(100, 23);
            this.textBox54.TabIndex = 1;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(13, 109);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(85, 15);
            this.label54.TabIndex = 0;
            this.label54.Text = "Temp-Max No";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(13, 77);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(105, 15);
            this.label55.TabIndex = 0;
            this.label55.Text = "Temp-Max (0.1℃)";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(13, 50);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(84, 15);
            this.label56.TabIndex = 0;
            this.label56.Text = "Temp-Min-No";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(13, 23);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(111, 15);
            this.label57.TabIndex = 0;
            this.label57.Text = "Temp-Min ( (0.1℃)";
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(92, 47);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(100, 23);
            this.textBox55.TabIndex = 1;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(92, 106);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(100, 23);
            this.textBox56.TabIndex = 1;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(92, 77);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(100, 23);
            this.textBox57.TabIndex = 1;
            // 
            // gb2C0h
            // 
            this.gb2C0h.Controls.Add(this.textBox58);
            this.gb2C0h.Controls.Add(this.label59);
            this.gb2C0h.Controls.Add(this.label62);
            this.gb2C0h.Controls.Add(this.label63);
            this.gb2C0h.Controls.Add(this.label60);
            this.gb2C0h.Controls.Add(this.label61);
            this.gb2C0h.Controls.Add(this.textBox59);
            this.gb2C0h.Controls.Add(this.textBox62);
            this.gb2C0h.Controls.Add(this.textBox60);
            this.gb2C0h.Controls.Add(this.textBox61);
            this.gb2C0h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb2C0h.Location = new System.Drawing.Point(17, 449);
            this.gb2C0h.Name = "gb2C0h";
            this.gb2C0h.Size = new System.Drawing.Size(254, 176);
            this.gb2C0h.TabIndex = 2;
            this.gb2C0h.TabStop = false;
            this.gb2C0h.Text = "0x2C0";
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(124, 22);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(100, 23);
            this.textBox58.TabIndex = 1;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(12, 147);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(121, 15);
            this.label59.TabIndex = 0;
            this.label59.Text = "CutOff Current ().1A)";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(11, 85);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(120, 15);
            this.label60.TabIndex = 0;
            this.label60.Text = "충전 요청 전류(0.1A)";
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(13, 23);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(86, 15);
            this.label61.TabIndex = 0;
            this.label61.Text = "Bat CHG STate";
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(124, 53);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(100, 23);
            this.textBox59.TabIndex = 1;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(124, 115);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(100, 23);
            this.textBox60.TabIndex = 1;
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(124, 84);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(100, 23);
            this.textBox61.TabIndex = 1;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(11, 54);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(120, 15);
            this.label62.TabIndex = 0;
            this.label62.Text = "충전 요청 전압(0.1V)";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(13, 116);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(74, 15);
            this.label63.TabIndex = 0;
            this.label63.Text = "Bat SOC (%)";
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(124, 146);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(100, 23);
            this.textBox62.TabIndex = 1;
            // 
            // gb120h
            // 
            this.gb120h.Controls.Add(this.textBox63);
            this.gb120h.Controls.Add(this.label68);
            this.gb120h.Controls.Add(this.label58);
            this.gb120h.Controls.Add(this.label64);
            this.gb120h.Controls.Add(this.label65);
            this.gb120h.Controls.Add(this.label66);
            this.gb120h.Controls.Add(this.label67);
            this.gb120h.Controls.Add(this.textBox64);
            this.gb120h.Controls.Add(this.textBox68);
            this.gb120h.Controls.Add(this.textBox65);
            this.gb120h.Controls.Add(this.textBox66);
            this.gb120h.Controls.Add(this.textBox67);
            this.gb120h.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gb120h.Location = new System.Drawing.Point(288, 449);
            this.gb120h.Name = "gb120h";
            this.gb120h.Size = new System.Drawing.Size(381, 176);
            this.gb120h.TabIndex = 2;
            this.gb120h.TabStop = false;
            this.gb120h.Text = "0x120";
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(124, 22);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(100, 23);
            this.textBox63.TabIndex = 1;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(12, 147);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(96, 15);
            this.label58.TabIndex = 0;
            this.label58.Text = "Status-2(미사용)";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(11, 54);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(104, 15);
            this.label64.TabIndex = 0;
            this.label64.Text = "RC (잔존용량, Ah)";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(13, 116);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(52, 15);
            this.label65.TabIndex = 0;
            this.label65.Text = "Status-1";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(11, 85);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(53, 15);
            this.label66.TabIndex = 0;
            this.label66.Text = "SOC (%)";
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(13, 23);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(100, 15);
            this.label67.TabIndex = 0;
            this.label67.Text = "충전 전류 ().01A)";
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(124, 53);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(100, 23);
            this.textBox64.TabIndex = 1;
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(124, 146);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(100, 23);
            this.textBox65.TabIndex = 1;
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(124, 115);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(100, 23);
            this.textBox66.TabIndex = 1;
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(124, 84);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(100, 23);
            this.textBox67.TabIndex = 1;
            // 
            // textBox68
            // 
            this.textBox68.Location = new System.Drawing.Point(253, 133);
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(100, 23);
            this.textBox68.TabIndex = 1;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(230, 115);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(96, 15);
            this.label68.TabIndex = 0;
            this.label68.Text = "Status-3(미사용)";
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(124, 0);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(169, 15);
            this.label69.TabIndex = 3;
            this.label69.Text = "수신 데이터를 출력 할 것 HEX";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label71);
            this.groupBox1.Controls.Add(this.textBox10);
            this.groupBox1.Controls.Add(this.textBox11);
            this.groupBox1.Controls.Add(this.textBox69);
            this.groupBox1.Controls.Add(this.textBox70);
            this.groupBox1.Controls.Add(this.textBox7);
            this.groupBox1.Controls.Add(this.textBox9);
            this.groupBox1.Controls.Add(this.textBox6);
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(17, 631);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(549, 59);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "0x180 (VCU Tx)";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(675, 458);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(310, 167);
            this.richTextBox1.TabIndex = 3;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(572, 645);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(511, 105);
            this.richTextBox2.TabIndex = 3;
            this.richTextBox2.Text = "180, 181 vcu에서 보내는 캔\n  0x180 : ?\n  0x181 :  두번째 바이트 \n               2단 - 00 ,  3단" +
    " - 02 ,  H - 42 \n               부팅중 - 11 , 부팅완료(P) - 10 \n               충전중 - 04" +
    "";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(23, 23);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(45, 23);
            this.textBox1.TabIndex = 1;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(74, 23);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(45, 23);
            this.textBox6.TabIndex = 1;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(176, 23);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(45, 23);
            this.textBox7.TabIndex = 2;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(125, 23);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(45, 23);
            this.textBox9.TabIndex = 3;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(407, 23);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(45, 23);
            this.textBox10.TabIndex = 6;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(356, 23);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(45, 23);
            this.textBox11.TabIndex = 7;
            // 
            // textBox69
            // 
            this.textBox69.Location = new System.Drawing.Point(305, 23);
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(45, 23);
            this.textBox69.TabIndex = 4;
            // 
            // textBox70
            // 
            this.textBox70.Location = new System.Drawing.Point(254, 23);
            this.textBox70.Name = "textBox70";
            this.textBox70.Size = new System.Drawing.Size(45, 23);
            this.textBox70.TabIndex = 5;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label72);
            this.groupBox2.Controls.Add(this.textBox2);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.textBox4);
            this.groupBox2.Controls.Add(this.textBox5);
            this.groupBox2.Controls.Add(this.textBox71);
            this.groupBox2.Controls.Add(this.textBox72);
            this.groupBox2.Controls.Add(this.textBox73);
            this.groupBox2.Controls.Add(this.textBox74);
            this.groupBox2.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox2.Location = new System.Drawing.Point(17, 696);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(549, 54);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "0x181 (VCU Tx)";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(407, 23);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(45, 23);
            this.textBox2.TabIndex = 6;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(356, 23);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(45, 23);
            this.textBox3.TabIndex = 7;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(305, 23);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(45, 23);
            this.textBox4.TabIndex = 4;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(254, 23);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(45, 23);
            this.textBox5.TabIndex = 5;
            // 
            // textBox71
            // 
            this.textBox71.Location = new System.Drawing.Point(176, 23);
            this.textBox71.Name = "textBox71";
            this.textBox71.Size = new System.Drawing.Size(45, 23);
            this.textBox71.TabIndex = 2;
            // 
            // textBox72
            // 
            this.textBox72.Location = new System.Drawing.Point(125, 23);
            this.textBox72.Name = "textBox72";
            this.textBox72.Size = new System.Drawing.Size(45, 23);
            this.textBox72.TabIndex = 3;
            // 
            // textBox73
            // 
            this.textBox73.Location = new System.Drawing.Point(74, 23);
            this.textBox73.Name = "textBox73";
            this.textBox73.Size = new System.Drawing.Size(45, 23);
            this.textBox73.TabIndex = 1;
            // 
            // textBox74
            // 
            this.textBox74.Location = new System.Drawing.Point(23, 23);
            this.textBox74.Name = "textBox74";
            this.textBox74.Size = new System.Drawing.Size(45, 23);
            this.textBox74.TabIndex = 1;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(6, 107);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(272, 15);
            this.label70.TabIndex = 4;
            this.label70.Text = "0x101 :  1,2번째 바이트 SOC가 VCU LCD에 표시";
            // 
            // richTextBox3
            // 
            this.richTextBox3.Location = new System.Drawing.Point(995, 458);
            this.richTextBox3.Name = "richTextBox3";
            this.richTextBox3.Size = new System.Drawing.Size(279, 167);
            this.richTextBox3.TabIndex = 3;
            this.richTextBox3.Text = "0x120\n- 6번째 바이트 vpu lcd에 충전기 연결 UI 띄움\n- 5번째 바이트 SOC VCU에 표시";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(478, 27);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(34, 15);
            this.label71.TabIndex = 8;
            this.label71.Text = "0x00";
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(478, 23);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(34, 15);
            this.label72.TabIndex = 8;
            this.label72.Text = "0x00";
            // 
            // Form_Wacco
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1302, 801);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.richTextBox3);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.gb101h);
            this.Controls.Add(this.gb102h);
            this.Controls.Add(this.gb118h);
            this.Controls.Add(this.gb110h);
            this.Controls.Add(this.gb10Fh);
            this.Controls.Add(this.gb10Eh);
            this.Controls.Add(this.gb120h);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gb2C0h);
            this.Controls.Add(this.gb10Dh);
            this.Controls.Add(this.gb109h);
            this.Controls.Add(this.gb108h);
            this.Controls.Add(this.gb107h);
            this.Controls.Add(this.gb106h);
            this.Controls.Add(this.gb105h);
            this.Controls.Add(this.gb104h);
            this.Controls.Add(this.gb103h);
            this.Controls.Add(this.gb100h);
            this.Name = "Form_Wacco";
            this.Text = "Wacco Message";
            this.Load += new System.EventHandler(this.Form_Wacco_Load);
            this.gb100h.ResumeLayout(false);
            this.gb100h.PerformLayout();
            this.gb101h.ResumeLayout(false);
            this.gb101h.PerformLayout();
            this.gb102h.ResumeLayout(false);
            this.gb102h.PerformLayout();
            this.gb103h.ResumeLayout(false);
            this.gb103h.PerformLayout();
            this.gb104h.ResumeLayout(false);
            this.gb104h.PerformLayout();
            this.gb105h.ResumeLayout(false);
            this.gb105h.PerformLayout();
            this.gb106h.ResumeLayout(false);
            this.gb106h.PerformLayout();
            this.gb107h.ResumeLayout(false);
            this.gb107h.PerformLayout();
            this.gb108h.ResumeLayout(false);
            this.gb108h.PerformLayout();
            this.gb109h.ResumeLayout(false);
            this.gb109h.PerformLayout();
            this.gb10Dh.ResumeLayout(false);
            this.gb10Dh.PerformLayout();
            this.gb10Eh.ResumeLayout(false);
            this.gb10Eh.PerformLayout();
            this.gb10Fh.ResumeLayout(false);
            this.gb10Fh.PerformLayout();
            this.gb110h.ResumeLayout(false);
            this.gb110h.PerformLayout();
            this.gb118h.ResumeLayout(false);
            this.gb118h.PerformLayout();
            this.gb2C0h.ResumeLayout(false);
            this.gb2C0h.PerformLayout();
            this.gb120h.ResumeLayout(false);
            this.gb120h.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbVer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbSN;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbMan;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbCycleCount;
        private System.Windows.Forms.GroupBox gb100h;
        private System.Windows.Forms.GroupBox gb101h;
        private System.Windows.Forms.TextBox tbSOC;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbSOP;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox tbSOH;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox gb102h;
        private System.Windows.Forms.TextBox tbCurrent;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox ttbVoltIn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tbVoltOut;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox gb103h;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox gb104h;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox gb105h;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.GroupBox gb106h;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.GroupBox gb107h;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.GroupBox gb108h;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.GroupBox gb109h;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.GroupBox gb10Dh;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.GroupBox gb10Eh;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.GroupBox gb10Fh;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.GroupBox gb110h;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.GroupBox gb118h;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.GroupBox gb2C0h;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.GroupBox gb120h;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox70;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox71;
        private System.Windows.Forms.TextBox textBox72;
        private System.Windows.Forms.TextBox textBox73;
        private System.Windows.Forms.TextBox textBox74;
        private System.Windows.Forms.RichTextBox richTextBox3;
    }
}