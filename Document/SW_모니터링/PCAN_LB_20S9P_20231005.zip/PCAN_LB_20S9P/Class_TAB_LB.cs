﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

/// <summary>
/// Inclusion of PEAK PCAN-Basic namespace
/// </summary>
using Peak.Can.Basic;
using TPCANHandle = System.UInt16;
using TPCANBitrateFD = System.String;
using TPCANTimestampFD = System.UInt64;
using System.IO;
using System.Data.SqlTypes;
using System.Net.NetworkInformation;
using static System.Resources.ResXFileRef;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Reflection;
using System.Security.Claims;
using System.Threading.Tasks;
using Watchdog.Timer;

namespace PCANBasicProject
{
    public partial class Form_Main : Form
    {
        #region Constant Value
        const int TempSensor_Max = 4;   // LB = 4, Wacco = 7, FET 는 별도

        #endregion

        #region  Glabal Variable

        UInt16[] CellVolt = new UInt16[48];     // mV 단위, mV로 표시, 최대 4개 LTC6803 사용 기준
        bool[] cellBalancing = new bool[48];    // Cell Balancing, true / false
        Int16[] PackTemp = new Int16[16];     // 0.1도 단위, 소수전 1자리로 표시, 최대 16개 사용 기준

        Byte[] BMS_Fault_Flag = new byte[2];
        Byte[] BMS_Alarm_Flag = new byte[2];
        Byte[] BMS_Status_Flag = new byte[4];
        Byte[] BMS_Balancing_Flag = new byte[4];
        byte BMS_Status;
        sbyte BatteryChgState = 0;

        #endregion

        // Static 으로 선언해야 됨 
        Stopwatch sw = new Stopwatch();
        Watchdog.Timer.MultimediaTimer stopWatchTimer;  


        private void classWacco_Initial()
        {
            if (TEST_OFFLINE)
            {
                tbH0.Visible = true;
                tbH1.Visible = true;
                tbH2.Visible = true;
                tbH3.Visible = true;
                tbH4.Visible = true;
                tbH5.Visible = true;
                tbH6.Visible = true;
                tbH7.Visible = true;
                tbIdH.Visible = true;
                btnSendTestMsg.Visible = true;
                lvlTestIdHex.Visible = true;
            }
            else
            {
                tbH0.Visible = false;
                tbH1.Visible = false;
                tbH2.Visible = false;
                tbH3.Visible = false;
                tbH4.Visible = false;
                tbH5.Visible = false;
                tbH6.Visible = false;
                tbH7.Visible = false;
                tbIdH.Visible = false;
                btnSendTestMsg.Visible = false;
                lvlTestIdHex.Visible = false;
            }

            btnLogStop.Enabled = false;
        }

        private void DisplayMessages_Tab_LB(string strType, uint ID, int DLC, byte[] canData)
        {
            bool temp = true;
            bool tempDebugMsg = true;

            switch (ID)
            {
                case 0x100: Display_IDx100(DLC, canData); break;
                case 0x101: Display_IDx101(DLC, canData); break;
                case 0x102: Display_IDx102(DLC, canData); break;
                case 0x103: Display_IDx103(DLC, canData); break;
                case 0x104: Display_IDx104(DLC, canData); break;
                case 0x105: Display_IDx105(DLC, canData); break;
                case 0x106: Display_IDx106(DLC, canData); break;
                case 0x107: Display_IDx107(DLC, canData); break;
                case 0x108: Display_IDx108(DLC, canData); break;
                case 0x109: Display_IDx109(DLC, canData); break;
                case 0x10D: Display_IDx10D(DLC, canData); break;
                case 0x10E: Display_IDx10E(DLC, canData); break;
                case 0x10F: Display_IDx10F(DLC, canData); break;
                case 0x110: Display_IDx110(DLC, canData); break;
                case 0x118: Display_IDx118(DLC, canData); break;
                case 0x119: Display_IDx119(DLC, canData); break;
                // LB
                case 0x11A: Display_IDx11A(DLC, canData); break;

                // 충전기
                case 0x120: Display_IDx120(DLC, canData); break;
                case 0x2C0: Display_IDx2C0(DLC, canData); break;
                // VCU Control
                case 0x180: Display_IDx180(DLC, canData); break;
                case 0x181: Display_IDx181(DLC, canData); break;
                // LB 추가 : 제어 기능
                case CAN_RPT_PROTECT_CAP_TEMP : Display_RcvProtect_CapTemp(DLC, canData); break;    // 0x131
                case CAN_RPT_PROTECT_VOLTCUR  : Display_RcvProtect_VoltCur(DLC, canData); break;    // 0x132
                case CAN_RPT_PROTECT_PF       : Display_RcvProtect_PF(DLC, canData);      break;    // 0x133
                // EVENT LOG
                case CAN_RPT_EVENT_DATA1      : Display_RcvEvent_First(DLC, canData); break;
                case CAN_RPT_EVENT_DATA2      : Display_RcvEvent_Second(DLC, canData); break;
                case CAN_RPT_EVENT_DATA3      : Display_RcvEvent_Third(DLC, canData); break;

                // LB - Externded ID (미사용)
                case 0x10261051: 
                            tempDebugMsg = false;
                            break;
                default: IncludeTextMessage(" Received New ID = 0x" + ID.ToString("X3"));
                          temp = false;
                          tempDebugMsg = false;
                          break;
            }
            bmsReceivedMessage = tempDebugMsg;
        }

        #region CAM_ID별 메세지 처리
        private void Display_IDx100(int DLC, byte[] canData)
        {
            tbVersion.Text = canData[0].ToString();
            tbSerialNo.Text = canData[1].ToString();
            tbManufacture.Text = BitConverter.ToUInt16(canData, 2).ToString() + "-" + canData[4].ToString() + "-" + canData[5].ToString();
            //tbManufacture.Text = canData[2].ToString() + canData[3].ToString() + "-" + canData[4].ToString() + "-" + canData[5].ToString();
            tbCycleCount.Text = (canData[7] * 256 + canData[6]).ToString();
        }
        private void Display_IDx101(int DLC, byte[] canData)
        {
            // SOC		0	0	Unsigned	16	0.1	0	0.0	100.0	%
            // SOH      2   16  Unsigned    16  1   0   0   100     %
            // SOP      4   32  Unsigned    16  0.1 0   0.0 100.0   A       (VCU 전류값 제어 수치) 
            // Reserved 6   48  Unsigned    16  0.1 0   0   560     Ah

            tbSOC.Text = (BitConverter.ToUInt16(canData, 0) /10.0f).ToString("F1"); //((canData[1] * 256 + canData[0]) / 10.0f).ToString("F1");      // #.# -> 소수 1자리
            tbSOH.Text = (BitConverter.ToUInt16(canData, 2) ).ToString();
            tbSOP.Text = (BitConverter.ToUInt16(canData, 4) / 10.0f).ToString("F1");   // #.# 은 75.0 이 아니고 75 로 출력
            //tbXXX.Text = (BitConverter.ToUInt16(canData, 6) / 10.0f).ToString("F1");
        }

        private void Display_IDx102(int DLC, byte[] canData)
        {
            // Current              0   0   Signed      16  0.01    0 - 327.68 327.67       %
            // Pack_In_Voltage      2   16  Unsigned    16  0.01    0   0.00    134.40      %
            // Pack_Out_Voltage     4   32  Unsigned    16  0.01    0   0.00    134.40      A
            // Reserved             6   48  Unsigned    16  0       0   0       100         V

            lvlCurrent.Text = (BitConverter.ToInt16(canData, 0) / 100.0f).ToString("F2");      // #.# -> 소수 1자리
            tbPackVoltIn.Text = (BitConverter.ToUInt16(canData, 2) / 100.0f).ToString("F2");
            tbPackVoltOut.Text = (BitConverter.ToUInt16(canData, 4) / 100.0f).ToString("F2");   // #.# 은 75.0 이 아니고 75 로 출력
            //tbXXX.Text = (BitConverter.ToUInt16(canData, 8).ToString();
        }

        private void Display_IDx103(int DLC, byte[] canData)
        {
            /*
            BMS_Fault_Flag      0   0   Binary  16  1   0   0   0xFFFF  
                                            0000 0000 0000 0001 : COVP (Cell Over Voltage Protection)
                                            0000 0000 0000 0010 : CUVP(Cell Under Voltage Protection)
                                            0000 0000 0000 0100 : COCP(Charge Over Current Protection)
                                            0000 0000 0000 1000 : DOCP(Discharge Over Current Protection)
                                            0000 0000 0001 0000 : COTP(Charge Over Temperature Protection)
                                            0000 0000 0010 0000 : DOTP(Discharge Over Temperature Protection)
                                            0000 0000 0100 0000 : CUTP(Charge Under Temperature Protection)
                                            0000 0000 1000 0000 : DUTP(Discharge Under Temperature Protection)
                                            0000 0001 0000 0000 : SHTP(Short Protection)
                                            0000 0010 0000 0000 : PWDN(Power Down)
                                            0000 0100 0000 0000 : IMBP(Imbalance Protection)
                                            0000 1000 0000 0000 : PUVP(Permanent Under Voltage Protection)
                                            0001 0000 0000 0000 : FOTP(FET Over Temp Protection)
 
            BMS_Alarm_Flag      2   16  Binary  16  1   0   0   0xFFFF  
                                            0000 0000 0000 0001 : COVA (Cell Over Voltage Alarm)
                                            0000 0000 0000 0010 : CUVA(Cell Under Voltage Alarm)
                                            0000 0000 0000 0100 : COCA(Charge Over Current Alarm)
                                            0000 0000 0000 1000 : DOCA(Discharge Over Current Alarm)
                                            0000 0000 0001 0000 : COTA(Charge Over Temperature Alarm)
                                            0000 0000 0010 0000 : DOTA(Discharge Over Temperature Alarm)
                                            0000 0000 0100 0000 : CUTA(Charge Under Temperature Alarm)
                                            0000 0000 1000 0000 : DUTA(Discharge Under Temperature Alarm)

            BMS_Status_Flag     4   32  Binary  16  1   0   0   0xFFFF  
                                            0000 0001 0000 0000 : SW (Ignite Key)
                                            0000 0010 0000 0000 : CKEY(Charging KEY)
                                            0000 0100 0000 0000 : DSOC(SOC Display)
                                            0000 1000 0000 0000 : IDCH(Discharging)
                                            0001 0000 0000 0000 : ICHG(Charging)
                                            0010 0000 0000 0000 : DFET(Discharge FET)
                                            0100 0000 0000 0000 : CFET(Charge FET)
                                            1000 0000 0000 0000 : PFET(Predischarge FET)
                                            ex) 0110 0001 0000 0000 : SW, DFET, CFET"
            BMS_Status_Flag + 6   48  Binary  16  1   0   0   0xFFFF  
                                            0000 0000 0000 0001 : CHGDischarge_FET
                                            0000 0000 0000 0010 : CHGCharge_FET
            */

            TextBox[] FalutVCT   = new TextBox[8] { tbFaultCovp, tbFaultDuvp, tbFaultCocp, tbFaultDocp, tbFaultCotp, tbFaultDotp, tbFaultCutp, tbFaultDutp };
            TextBox[] FalutSPF   = new TextBox[2] { tbFaultShtp, tbFaultPwdn, /* tbFaultImbp, tbFaultPuvp, tbFaultFotp */};
            TextBox[] Alarm      = new TextBox[8] { tbAlarmCova, tbAlarmCuva, tbAlarmCoca, tbAlarmDoca, tbAlarmCota, tbAlarmDota, tbAlarmCuta, tbAlarmDuta };
            TextBox[] BmsStatus1 = new TextBox[8] { tbBmsStSwon, tbBmsStChgKeyOn, tbBmsStSocDisplay, tbBmsStIdch, tbBmsIchg, tbBmsDFET, tbBmsStCfet, tbBmsStPfet };
            TextBox[] BmsStatus2 = new TextBox[2] { tbBmsStChgDisFet, tbBmsStChgChgFet };

            BMS_Fault_Flag[0] = canData[0];
            BMS_Fault_Flag[1] = canData[1];
            BMS_Alarm_Flag[0] = canData[2];
            BMS_Alarm_Flag[1] = canData[3];
            BMS_Status_Flag[0] = canData[4];
            BMS_Status_Flag[1] = canData[5];
            BMS_Status_Flag[2] = canData[6];
            BMS_Status_Flag[3] = canData[7];

            // Fault / 정상 표시
            if (BMS_Fault_Flag[0] == 0x00 && BMS_Fault_Flag[1] == 0x00)     
            {
                tbStateGood.BackColor = System.Drawing.Color.Lime;
                tbStateGood.ForeColor = System.Drawing.Color.Blue;

                tbStateFault.BackColor = System.Drawing.SystemColors.ButtonHighlight;
                tbStateFault.ForeColor = System.Drawing.SystemColors.AppWorkspace;

                BMS_Status = 0; // 정상
            }
            else
            {
                tbStateGood.BackColor = System.Drawing.SystemColors.ButtonHighlight;
                tbStateGood.ForeColor = System.Drawing.SystemColors.AppWorkspace;

                tbStateFault.BackColor = System.Drawing.Color.Red;
                tbStateFault.ForeColor = System.Drawing.Color.Yellow;

                BMS_Status = 1; // 정상
            }

            int k;
            byte mask = 0x01;
            for (k = 0; k < 8; k++)
            {
                if ((canData[0] & mask) != 0) 
                { 
                    FalutVCT[k].BackColor = Color.Red;
                    FalutVCT[k].ForeColor = Color.Yellow;
                    FalutVCT[k].Font = new Font(FalutVCT[k].Font, FontStyle.Bold); 
                }
                else
                {
                    FalutVCT[k].BackColor = Color.White;
                    FalutVCT[k].ForeColor = SystemColors.WindowText; 
                    FalutVCT[k].Font = new Font(FalutVCT[k].Font, FontStyle.Regular);
                }
                mask <<= 1;
            }

            mask = 0x01;
            for (k = 0; k < 2; k++)
            {
                if ((canData[1] & mask) != 0)
                {
                    FalutSPF[k].BackColor = Color.Red;
                    FalutSPF[k].ForeColor = Color.Yellow;
                    FalutSPF[k].Font = new Font(FalutSPF[k].Font, FontStyle.Bold);
                }
                else
                {
                    FalutSPF[k].BackColor = Color.White;
                    FalutSPF[k].ForeColor = SystemColors.WindowText;
                    FalutSPF[k].Font = new Font(FalutSPF[k].Font, FontStyle.Regular);
                }
                mask <<= 1;
            }

            mask = 0x01;
            for (k = 0; k < 8; k++)
            {
                if ((canData[2] & mask) != 0)
                {
                    Alarm[k].BackColor = Color.Red;
                    Alarm[k].ForeColor = Color.Yellow;
                    Alarm[k].Font = new Font(Alarm[k].Font, FontStyle.Bold);
                }
                else
                {
                    Alarm[k].BackColor = Color.White;
                    Alarm[k].ForeColor = SystemColors.WindowText;
                    Alarm[k].Font = new Font(Alarm[k].Font, FontStyle.Regular);
                }
                mask <<= 1;
            }

            // canData[3] 
            // canData[4]

            mask = 0x01;
            for (k = 0; k < 8; k++)
            {
                if ((canData[5] & mask) != 0)
                {
                    BmsStatus1[k].BackColor = Color.Red;
                    BmsStatus1[k].ForeColor = Color.Yellow;
                    BmsStatus1[k].Font = new Font(BmsStatus1[k].Font, FontStyle.Bold);
                }
                else
                {
                    BmsStatus1[k].BackColor = Color.White;
                    BmsStatus1[k].ForeColor = SystemColors.WindowText;
                    BmsStatus1[k].Font = new Font(BmsStatus1[k].Font, FontStyle.Regular);
                }
                mask <<= 1;
            }

            mask = 0x01;
            for (k = 0; k < 2; k++)
            {
                if ((canData[6] & mask) != 0)
                {
                    BmsStatus2[k].BackColor = Color.Red;
                    BmsStatus2[k].ForeColor = Color.Yellow;
                    BmsStatus2[k].Font = new Font(BmsStatus2[k].Font, FontStyle.Bold);
                }
                else
                {
                    BmsStatus2[k].BackColor = Color.White;
                    BmsStatus2[k].ForeColor = SystemColors.WindowText;
                    BmsStatus2[k].Font = new Font(BmsStatus2[k].Font, FontStyle.Regular);
                }
                mask <<= 1;
            }

            // canData[7]
        }


        private void Display_IDx104(int DLC, byte[] canData)
        {
            // BMS_Balance_Flag                          0   0   Binary     32  1   0   0   0xFFFFFFFF
            //                              0000 0000 0000 0000 0000 0000 0000 0001 : 01 Cell Balancing
            //                              0000 0000 0000 0000 0000 0000 0000 0010 : 02 Cell Balancing
            //                              0000 0000 0000 0000 0000 0000 0000 0100 : 03 Cell Balancing
            // FCC      (완전 충전 용량 / SOH계산된값)   4   32  Unsigned    16  0.01    0   0   43.2
            // RC       (Remained Cap) 중복              6   48  Unsigned    16  0.01    0   0   43.2

            BMS_Balancing_Flag[0] = canData[0];
            BMS_Balancing_Flag[1] = canData[1];
            BMS_Balancing_Flag[2] = canData[2];
            BMS_Balancing_Flag[3] = canData[3];

            int index = 0;
            for(int cell = 0; cell < 3; cell++)
            {
                byte mask = 0x01;
                for (int k = 0; k < 8; k++)
                {
                    cellBalancing[index] = ((canData[cell] & mask) != 0);
                    mask <<= 1;
                    index++;
                }
            }

            tbFCC.Text = (BitConverter.ToUInt16(canData, 4)/100.0f).ToString("F2");
            tbRC.Text  = (BitConverter.ToUInt16(canData, 6)/100.0f).ToString("F2");
        }

        private void DisplayCellVoltage(int start, int size)
        {
            // lvlCellVoltage
            ListViewItem item;
            int k;

            // 리스트뷰 아이템을 업데이트 하기 시작.
            // 업데이트가 끝날 때까지 UI 갱신 중지.
            lvｗCellVoltage.BeginUpdate();

            if (lvｗCellVoltage.Items.Count == 0)    // 초기화 검사
            {
                for(k = 0; k < 20; k++)
                {
                    item = new ListViewItem((k + 1).ToString());    // Cell No
                    item.SubItems.Add("0");     // Volt
                    item.SubItems.Add("");      // Cell Balancing

                    lvｗCellVoltage.Items.Insert(k, item);
                }
            }

            for ( k = 0; k < size; k++)
            {
                // Data 생성
                item = new ListViewItem((start + k + 1).ToString());    // Cell No
                item.SubItems.Add(CellVolt[start + k].ToString());      // Volt
                if (cellBalancing[start + k])                           // Cell Balancing
                    item.SubItems.Add("1");    
                else
                    item.SubItems.Add("");

                // Delete & Insert
                lvｗCellVoltage.Items.RemoveAt(start + k);
                lvｗCellVoltage.Items.Insert(start + k, item);
            }

            // 리스뷰를 Refresh하여 보여줌
            lvｗCellVoltage.EndUpdate();

            // Cell 전압을 더해서 화면에 표시
            uint sumCellVolt = 0;
            for (k = 0; k < 20; k++)
            {
                sumCellVolt += CellVolt[k];
            }
            lvlVoltage.Text = (sumCellVolt/1000.0f).ToString("F2");
        }


        private void Display_IDx105(int DLC, byte[] canData)
        {
            // 01_Cell_Voltage     0   0   Unsigned    16  0.001   0   0.000   5.000
            // 02_Cell_Voltage     2   16  Unsigned    16  0.001   0   0.000   5.000
            // 03_Cell_Voltage     4   32  Unsigned    16  0.001   0   0.000   5.000
            // 04_Cell_Voltage     6   48  Unsigned    16  0.001   0   0.000   5.000

            CellVolt[0] = BitConverter.ToUInt16(canData, 0); // canData[1] * 256 + canData[0];
            CellVolt[1] = BitConverter.ToUInt16(canData, 2);
            CellVolt[2] = BitConverter.ToUInt16(canData, 4);
            CellVolt[3] = BitConverter.ToUInt16(canData, 6);
            DisplayCellVoltage(0, 4);
        }
        private void Display_IDx106(int DLC, byte[] canData)
        {
            CellVolt[4] = BitConverter.ToUInt16(canData, 0);
            CellVolt[5] = BitConverter.ToUInt16(canData, 2);
            CellVolt[6] = BitConverter.ToUInt16(canData, 4);
            CellVolt[7] = BitConverter.ToUInt16(canData, 6);
            DisplayCellVoltage(4, 4);
        }
        private void Display_IDx107(int DLC, byte[] canData)
        {
            CellVolt[8] = BitConverter.ToUInt16(canData, 0); 
            CellVolt[9] = BitConverter.ToUInt16(canData, 2);
            CellVolt[10] = BitConverter.ToUInt16(canData, 4);
            CellVolt[11] = BitConverter.ToUInt16(canData, 6);
            DisplayCellVoltage(8, 4);
        }
        private void Display_IDx108(int DLC, byte[] canData)
        {
            CellVolt[12] = BitConverter.ToUInt16(canData, 0);
            CellVolt[13] = BitConverter.ToUInt16(canData, 2);
            CellVolt[14] = BitConverter.ToUInt16(canData, 4);
            CellVolt[15] = BitConverter.ToUInt16(canData, 6);
            DisplayCellVoltage(12, 4);
        }
        private void Display_IDx109(int DLC, byte[] canData)
        {
            CellVolt[16] = BitConverter.ToUInt16(canData, 0);
            CellVolt[17] = BitConverter.ToUInt16(canData, 2);
            CellVolt[18] = BitConverter.ToUInt16(canData, 4);
            CellVolt[19] = BitConverter.ToUInt16(canData, 6);
            DisplayCellVoltage(16, 4);
        }

       
        private void Display_IDx10D(int DLC, byte[] canData)
        {
            // Min_Cell_Voltage		    0	0	Unsigned	16	0.001	0	0.000	5.000
            // Min_Cell_Voltage_Num		2	16	Unsigned	16	1	    0	1	    32
            // Max_Cell_Voltage		    4	32	Unsigned	16	0.001	0	0.000	5.000
            // Max_Cell_Voltage_Num		6	48	Unsigned	16	1	    0	1	    32

            tbCellVoltMin.Text = BitConverter.ToUInt16(canData, 0).ToString(); // mV 표시, (canData[1] * 256 + canData[0]).ToString();
            tbCellNoMin.Text   = BitConverter.ToUInt16(canData, 2).ToString();
            tbCellVoltMax.Text = BitConverter.ToUInt16(canData, 4).ToString();
            tbCellNoMax.Text   = BitConverter.ToUInt16(canData, 6).ToString();
        }

        private void Display_IDx10E(int DLC, byte[] canData)
        {
            // Signal Name	          Start Start Bit	Signal     Bit  	Resolution	Offset	Min.    Max
            //                        Byte  Bit         Type       Length
            // Avg_Cell_Voltage		    0	0	        Unsigned	16	    0.001	    0	    0.000	5.000
            // Diff_Cell_Voltage        2   16          Unsigned    16      0.001       0       0.000   5.000
            // Avg_Cell_Temperature     4   32          Signed      16      0.1         0       - 40.0  100.0
            // Diff_Cell_Temperature    6   48          Unsigned    16      0.1         0        0.0    140.0
            tbCellVoltAvg.Text  = BitConverter.ToUInt16(canData, 0).ToString();             // Uint16, mV 표시
            tbCellVoltDiff.Text = BitConverter.ToUInt16(canData, 2).ToString();             // Uint16, mV 표시
            tbTempAvg.Text      = (BitConverter.ToInt16(canData, 4)/10f).ToString("F1");    // int16, #.# 표시
            tbTempDiff.Text     = (BitConverter.ToInt16(canData, 6)/10f).ToString("F1");    // int16, #.# 표시
        }


        private void DisplayCellTemperature(int start, int size)
        {
            // lvlCellVoltage
            ListViewItem item;
            int k;

            // 리스트뷰 아이템을 업데이트 하기 시작.
            // 업데이트가 끝날 때까지 UI 갱신 중지.
            lvlPackTemp.BeginUpdate();

            if (lvlPackTemp.Items.Count == 0)    // 초기화 검사
            {
                for (k = 0; k < TempSensor_Max; k++)    
                {
                    item = new ListViewItem((k + 1).ToString());    // 위치 1 ` 7
                    item.SubItems.Add("0.0");     // 온도
                    lvlPackTemp.Items.Insert(k, item);
                }
                item = new ListViewItem("FET");    // 위치 : FET
                item.SubItems.Add("0.0");     // 온도
                lvlPackTemp.Items.Insert(k, item);
            }

            for (k = 0; k < size; k++)
            {
                // Data 생성
                if ( (start+k) == 7 ) item = new ListViewItem("FET");
                else item = new ListViewItem((start + k + 1).ToString());            // Cell No
                item.SubItems.Add((PackTemp[start + k]/10f).ToString("F1"));    // Temp, 0.1도

                // Delete & Insert
                lvlPackTemp.Items.RemoveAt(start + k);
                lvlPackTemp.Items.Insert(start + k, item);
            }

            // 리스뷰를 Refresh하여 보여줌
            lvlPackTemp.EndUpdate();
        }

        private void Display_IDx10F(int DLC, byte[] canData)
        {
            // 01_Cell_Temperature		0	0	Signed	16	0.1	0	-40.0	100.0
            // 02_Cell_Temperature		2	16	Signed	16	0.1	0	-40.0	100.0
            // 03_Cell_Temperature		4	32	Signed	16	0.1	0	-40.0	100.0
            // 04_Cell_Temperature		6	48	Signed	16	0.1	0	-40.0	100.0

            PackTemp[0] = BitConverter.ToInt16(canData, 0);
            PackTemp[1] = BitConverter.ToInt16(canData, 2);
            PackTemp[2] = BitConverter.ToInt16(canData, 4);
            PackTemp[3] = BitConverter.ToInt16(canData, 6);
            DisplayCellTemperature(0, 4);
        }

        private void Display_IDx110(int DLC, byte[] canData)
        {
            // 05_Cell_Temperature		0	0	Signed	16	0.1	0	-40.0	100.0
            // 06_Cell_Temperature		2	16	Signed	16	0.1	0	-40.0	100.0
            // 07_Cell_Temperature		4	32	Signed	16	0.1	0	-40.0	100.0
            // FET_Temperature		    6	48	Signed	16	0.1	0	-40.0	100.0

            PackTemp[4] = BitConverter.ToInt16(canData, 0);
            PackTemp[5] = BitConverter.ToInt16(canData, 2);
            PackTemp[6] = BitConverter.ToInt16(canData, 4);
            PackTemp[7] = BitConverter.ToInt16(canData, 6);
            DisplayCellTemperature(4, 4);
        }

        private void Display_IDx118(int DLC, byte[] canData)
        {
            // Min_Cell_Temperature		    0	0	Signed	16	0.1	0	-40.0	100.0
            // Min_Cell_Temperature_Num		2	16	Unsigned	16	1	0	1	32
            // Max_Cell_Temperature		    4	32	Signed	16	0.1	0	-40.0	100.0
            // Max_Cell_Temperature_Num		6	48	Unsigned	16	1	0	1	32
            tbTempMin.Text = (BitConverter.ToInt16(canData, 0)/10f).ToString("F1");
            tbTempMinNo.Text = BitConverter.ToUInt16(canData, 2).ToString();
            tbTempMax.Text = (BitConverter.ToInt16(canData, 4)/10f).ToString("F1");
            tbTempMaxNo.Text = BitConverter.ToUInt16(canData, 6).ToString();
        }

        private void Display_IDx119_Wacco(int DLC, byte[] canData)
        {
            /*
            // Min_Cell_Temperature		    0	0	Signed	16	0.1	0	-40.0	100.0
            // Min_Cell_Temperature_Num		2	16	Unsigned	16	1	0	1	32
            // Max_Cell_Temperature		    4	32	Signed	16	0.1	0	-40.0	100.0
            // Max_Cell_Temperature_Num		6	48	Unsigned	16	1	0	1	32
            tbTempMin.Text = (BitConverter.ToInt16(canData, 0) / 10f).ToString("F1");
            tbTempMinNo.Text = BitConverter.ToUInt16(canData, 2).ToString();
            tbTempMax.Text = (BitConverter.ToInt16(canData, 4) / 10f).ToString("F1");
            tbTempMaxNo.Text = BitConverter.ToUInt16(canData, 6).ToString();

            */
        }
        private void Display_IDx119(int DLC, byte[] canData)
        {
            //u8_can_frame[0] = (System_Info.Status.Charge_Status & 0x00ff);
            //u8_can_frame[1] = (System_Info.Status.Charge_Status & 0xff00) >> 8;
            //          System_Info.Status.Charge_Status
            //                    #define IDLE		    0
            //                    #define CHARGE		1
            //                    #define DISCHARGE	    2
            //u8_can_frame[2] = (System_Info.Fault.u16_Fault & 0x00ff);
            //u8_can_frame[3] = (System_Info.Fault.u16_Fault & 0xff00) >> 8;
            //
            //    #define f_OVP				0x0001
            //    #define f_UVP				0x0002
            //    #define f_OCP				0x0004
           //     #define f_DOCP				0x0008
            //    #define f_COTP				0x0010
             //   #define f_DOTP				0x0020
             //   #define f_CUTP				0x0040
             //   #define f_DUTP				0x0080
              //  #define f_CPF				0x0100
              //  #define f_DPF				0x0200

             //   #define f_RELESE			0x8000  
             //   #define f_OCCUR				0x0000 

            int chargeStatus;

            chargeStatus = BitConverter.ToInt32(canData, 0);
            if (chargeStatus == 0)  // IDLE
            {
                tbStateIdle.BackColor = System.Drawing.Color.GreenYellow;
                tbStateIdle.ForeColor = System.Drawing.Color.Red;

                tbStateChg.BackColor = System.Drawing.SystemColors.ButtonHighlight;
                tbStateChg.ForeColor = System.Drawing.SystemColors.AppWorkspace;

                tbStateDisChg.BackColor = System.Drawing.SystemColors.ButtonHighlight;
                tbStateDisChg.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            }
            else if (chargeStatus == 1)  // 충전
            {
                tbStateIdle.BackColor = System.Drawing.SystemColors.ButtonHighlight;
                tbStateIdle.ForeColor = System.Drawing.SystemColors.AppWorkspace;

                tbStateChg.BackColor = System.Drawing.Color.GreenYellow;
                tbStateChg.ForeColor = System.Drawing.Color.Red;

                tbStateDisChg.BackColor = System.Drawing.SystemColors.ButtonHighlight;
                tbStateDisChg.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            }
            else if (chargeStatus == 2)  // 방전
            {
                tbStateIdle.BackColor = System.Drawing.SystemColors.ButtonHighlight;
                tbStateIdle.ForeColor = System.Drawing.SystemColors.AppWorkspace;

                tbStateChg.BackColor = System.Drawing.SystemColors.ButtonHighlight;
                tbStateChg.ForeColor = System.Drawing.SystemColors.AppWorkspace;

                tbStateDisChg.BackColor = System.Drawing.Color.GreenYellow;
                tbStateDisChg.ForeColor = System.Drawing.Color.Red;
            }
            else
            {
                tbStateIdle.BackColor = System.Drawing.SystemColors.ButtonHighlight;
                tbStateIdle.ForeColor = System.Drawing.SystemColors.AppWorkspace;

                tbStateChg.BackColor = System.Drawing.SystemColors.ButtonHighlight;
                tbStateChg.ForeColor = System.Drawing.SystemColors.AppWorkspace;

                tbStateDisChg.BackColor = System.Drawing.SystemColors.ButtonHighlight;
                tbStateDisChg.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            }
        }

        private void Display_IDx11A(int DLC, byte[] canData)
        {
            /*
             * 	u8_can_frame[0] = (Parameter.s32_EVENT_SEC				& 0x0000ff);		//
	            u8_can_frame[1] = (Parameter.s32_EVENT_SEC				& 0x00ff00) >> 8;	//
	            u8_can_frame[2] = (Parameter.s32_EVENT_SEC				& 0x00ff00) >> 16;	//
	            u8_can_frame[3] = (Parameter.s32_EVENT_SEC				& 0xff0000) >> 24;	//
	            u8_can_frame[4] = (Parameter.s16_EVENT_INDEX			& 0x00ff);			//
	            u8_can_frame[5] = (Parameter.s16_EVENT_INDEX			& 0xff00) >> 8;		//
	            u8_can_frame[6] = 0;												//
	            u8_can_frame[7] = 0;	
                // Min_Cell_Temperature		    0	0	Signed	16	0.1	0	-40.0	100.0
                // Min_Cell_Temperature_Num		2	16	Unsigned	16	1	0	1	32
                // Max_Cell_Temperature		    4	32	Signed	16	0.1	0	-40.0	100.0
                // Max_Cell_Temperature_Num		6	48	Unsigned	16	1	0	1	32
                tbTempMin.Text = (BitConverter.ToInt16(canData, 0) / 10f).ToString("F1");
                tbTempMinNo.Text = BitConverter.ToUInt16(canData, 2).ToString();
                tbTempMax.Text = (BitConverter.ToInt16(canData, 4) / 10f).ToString("F1");
                tbTempMaxNo.Text = BitConverter.ToUInt16(canData, 6).ToString();
            */
            txtBmsRunTime.Text = BitConverter.ToUInt32(canData, 0).ToString();
            txtLastEventIndex.Text = BitConverter.ToUInt16(canData, 4).ToString();
            txtLastEvent.Text = txtLastEventIndex.Text;
            txtRunTimeInEvent.Text = txtBmsRunTime.Text;
        }


        private void Display_IDx180(int DLC, byte[] canData)
        {
            string str = "";

            for(int k = 0; k < DLC; k++)  str += str += (canData[k].ToString("X2") + " ");
            ////tbVcu0x180.Text = str;
        }

        private void Display_IDx181(int DLC, byte[] canData)
        {
            string str = "";

            for (int k = 0; k < DLC; k++) str += (canData[k].ToString("X2")+" ");
            ////tbVcu0x181.Text = str;
        }


        private void Display_IDx120(int DLC, byte[] canData)
        {
            // Current          충전 전류     0   0   Signed    16  0.01    0 - 327.68 327.67   A
            // RC(Remained Cap) 남은 용량     2   16  Unsigned  16  0.1     0   0       560     Ah
            // SOC              남은 용량     4   32  Unsigned   8   1      0   0       100     %
            // Statues1         상태          5   40  bit        8   1      0   0       0x0FF
            //                                          0000 0001：충전 중
            //                                          0000 0010：배터리 이상
            // Statues2         미사용         6   48  bit 8   1   0   0   0x0FF   备用
            // Statues3         미사용         6   56  bit 8   1   0   0   0x0FF   备用
            ////tbGauageCurrent.Text = (BitConverter.ToInt16(canData, 0) / 100f).ToString("F2");
            ////tbGauageCap.Text     = (BitConverter.ToUInt16(canData, 2) / 10f).ToString("F1");
            ////tbGauageSOC.Text     = canData[4].ToString();
            ////tbGauageState.Text   = (canData[5] == 0x01) ? "Charging" : ( (canData[5] == 0x02) ? "Battery Fault" : "Good");

        }
        private void Display_IDx2C0(int DLC, byte[] canData)
        {
            // BatChgState          0   0   Signed      8   1   0 - 4  2
            //              -4 = CUTP (Charge Under Temperature Protection) : 저온 충전 차단.
            //              -3 = COTP(Charge Over Temperature Protection) : 고온 충전 차단.
            //              -2 = COVP(Cell Over Voltage Protection) : 셀 고전압 차단
            //              -1 = COCP(Charge Over Current Protecion) : 과전류 충전 차단
            //              1  = Charge FET OFF
            //              2  = Charge FET ON
            //
            // Reserved             1   8   Signed      8   1   0   0   2       N / A
            // BatState1            2   16  Unsigned    16  0.1 0   1   900     충전요청전압 V
            // ReqChgCurrent        4   32  Unsigned    8   0.1 0   1   255     충전요청전류 A
            // BatSOC               5   40  Unsigned    8   1   0   1   100     SOC %
            // BatCVOffCurrent      6   48  Unsigned    8   0.1 0   1   255     CV컷오프전류 A
            // Reserved             7   56  Unsigned    8   0.1 0   1   255

            //sbyte BatChgState = Convert.ToSByte(canData[0]);    // byte date가 127보다 크면 오류 발생
            sbyte BatChgState = unchecked((sbyte)canData[0]);
            BatteryChgState = BatChgState;
            #if false
            switch (BatChgState)
            {
                case -4: tbChgRunStatus.Text = "CUTP (Chg Under Temp Protection)"; break;
                case -3: tbChgRunStatus.Text = "COTP (Chg Over Temp Protection)"; break;
                case -2: tbChgRunStatus.Text = "COVP (Cell Over Volt Protection)"; break;
                case -1: tbChgRunStatus.Text = "COCP (Chg Over Current Protection)"; break;
                case 1:  tbChgRunStatus.Text = "Charge FET OFF"; break;
                case 2:  tbChgRunStatus.Text = "Charge FET ON"; break;
                default: tbChgRunStatus.Text = "Idle"; break;
            }


            tbChgRunVolt.Text    = (BitConverter.ToUInt16(canData, 2) / 10f).ToString("F1");
            tbChgRunCurrent.Text = (canData[4] / 10f).ToString("F1");
            tbChgRunSOC.Text     = canData[5].ToString();
            tbChgRunCutOff.Text  = (canData[6] / 10f).ToString("F1");
            #endif
        }

        #endregion



        #region TEST

        private void btnSendTestMsg_Click(object sender, EventArgs e)
        {
            uint id = Convert.ToUInt32(tbIdH.Text, 16); //uint.Parse(tbIdH.Text);
            int dlc = 8;
            byte[] canData = new byte[dlc];
            canData[0] = byte.Parse(tbH0.Text);     //
            canData[1] = byte.Parse(tbH1.Text);
            canData[2] = byte.Parse(tbH2.Text);
            canData[3] = byte.Parse(tbH3.Text);
            canData[4] = byte.Parse(tbH4.Text);
            canData[5] = byte.Parse(tbH5.Text);
            canData[6] = byte.Parse(tbH6.Text);
            canData[7] = byte.Parse(tbH7.Text);
            DisplayMessages_Tab_LB("TST", id, dlc, canData);
        }

        #endregion


        #region Save Log Function

        private string GetLogTitle_LB()
        {
            string Title = "DateTime(yyyy-mm-dd hh:mm:ss.000),Volt,Current,State,Vin,Vout,Vdiff,Tdiff,SOC,SOH,SOP,FCC,RC,Cycle";    // state = 0 (정상) 1(Fault) 2(Alarm)
            Title += ",Vmax,VmaxNo,Vmin,VminNo,Vavg,Tmax,TmaxNo,Tmin,TminNo,Tavg";
            Title += ",Cell1,Cell2,Cell3,Cell4,Cell5,Cell6,Cell7,Cell8,Cell9,Cell10";
            Title += ",Cell11,Cell12,Cell13,Cell14,Cell15,Cell16,Cell17,Cell18,Cell19,Cell20";
            Title += ",Temp1,Temp2,Temp3,Temp4,TempFET";
            Title += ",CB0,CB1,CB2,CB3,Fault0,Fault1,BmsSt0,BmsSt1,BmsSt2,BmsSt3";
            Title += ",Ver,SerialNo,Manufacture";

            return Title;
        }

        private string GetLogMessage_LB()
        {
            string Msg = "";
            // yyyy-mm-dd  hh:mm:ss.000
            Msg += DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
            Msg += ("," + lvlVoltage.Text);
            Msg += ("," + lvlCurrent.Text);
            Msg += ("," + BMS_Status.ToString()); 
            Msg += ("," + tbPackVoltIn.Text);
            Msg += ("," + tbPackVoltOut.Text);
            Msg += ("," + tbCellVoltDiff.Text);
            Msg += ("," + tbTempDiff.Text);
            Msg += ("," + tbSOC.Text);
            Msg += ("," + tbSOH.Text);
            Msg += ("," + tbSOP.Text);
            Msg += ("," + tbFCC.Text);
            Msg += ("," + tbRC.Text);
            Msg += ("," + tbCycleCount.Text);

            Msg += ("," + tbCellVoltMax.Text);
            Msg += ("," + tbCellNoMax.Text);
            Msg += ("," + tbCellVoltMin.Text);
            Msg += ("," + tbCellNoMin.Text);
            Msg += ("," + tbCellVoltAvg.Text);

            Msg += ("," + tbTempMax.Text);
            Msg += ("," + tbTempMaxNo.Text);
            Msg += ("," + tbTempMin.Text);
            Msg += ("," + tbTempMinNo.Text);
            Msg += ("," + tbTempAvg.Text);

            Msg += ("," + CellVolt[0].ToString());
            Msg += ("," + CellVolt[1].ToString());
            Msg += ("," + CellVolt[2].ToString());
            Msg += ("," + CellVolt[3].ToString());
            Msg += ("," + CellVolt[4].ToString());
            Msg += ("," + CellVolt[5].ToString());
            Msg += ("," + CellVolt[6].ToString());
            Msg += ("," + CellVolt[7].ToString());
            Msg += ("," + CellVolt[8].ToString());
            Msg += ("," + CellVolt[9].ToString());
            Msg += ("," + CellVolt[10].ToString());
            Msg += ("," + CellVolt[11].ToString());
            Msg += ("," + CellVolt[12].ToString());
            Msg += ("," + CellVolt[13].ToString());
            Msg += ("," + CellVolt[14].ToString());
            Msg += ("," + CellVolt[15].ToString());
            Msg += ("," + CellVolt[16].ToString());
            Msg += ("," + CellVolt[17].ToString());
            Msg += ("," + CellVolt[18].ToString());
            Msg += ("," + CellVolt[19].ToString());

            Msg += ("," + PackTemp[0].ToString());
            Msg += ("," + PackTemp[1].ToString());
            Msg += ("," + PackTemp[2].ToString());
            Msg += ("," + PackTemp[3].ToString());
            Msg += ("," + PackTemp[4].ToString());  // FET Temp

            Msg += ("," + BMS_Balancing_Flag[0].ToString("X2"));
            Msg += ("," + BMS_Balancing_Flag[1].ToString("X2"));
            Msg += ("," + BMS_Balancing_Flag[2].ToString("X2"));
            Msg += ("," + BMS_Balancing_Flag[3].ToString("X2"));

            Msg += ("," + BMS_Fault_Flag[0].ToString("X2"));
            Msg += ("," + BMS_Fault_Flag[1].ToString("X2"));

            Msg += ("," + BMS_Status_Flag[0].ToString("X2"));
            Msg += ("," + BMS_Status_Flag[1].ToString("X2"));
            Msg += ("," + BMS_Status_Flag[2].ToString("X2"));
            Msg += ("," + BMS_Status_Flag[3].ToString("X2"));

            Msg += ("," + tbVersion.Text);
            Msg += ("," + tbSerialNo.Text);
            Msg += ("," + tbManufacture.Text);


            return Msg;
        }


        private void btnLogStart_Click(object sender, EventArgs e)
        {
            // 파일 선택과정에서 중복 클릭 방진
            btnLogStop.Enabled = true;
            btnLogStart.Enabled = false;

            // File 선택
            if (SelectSaveLogFile() == true)
            {
                // 저장 주기 선택
                if (tbLogSavePeriod.Text == "") tbLogSavePeriod.Text = 500.ToString();
                UInt32 period = Convert.ToUInt32(tbLogSavePeriod.Text);
                if (period <= 100) period = 100;
                else if (period >= 3000) period = 3000;
                // Timer 설정
                stopWatchTimer = new MultimediaTimer() { Interval = period, Resolution = 1 };        // 100msec, { Interval = 1, Resolution = 0};
                stopWatchTimer.Elapsed += stopWatchTimerHandler;
                stopWatchTimer.Start();
                sw.Start();
            }
            else
            {
                // 파일 저장이 취소된 경우 -> 버튼 복귀
                btnLogStop.Enabled = false;
                btnLogStart.Enabled = true;     
            }
        }

        public void stopWatchTimerHandler(object sender, EventArgs e)     // 실제 동작
        {
            //Console.WriteLine(DateTime.Now.ToString("o"));
            timerSaveLog_Tick(sender, e);
        }


        /*  
         *  FIle 저장 방법
         *  [방법1]
         *   using (StreamWriter swSaveLogFileTimer = new StreamWriter(saveFileDialog1.FileName, true, Encoding.ASCII)) 과 
         *   swSaveLogFileTimer = new StreamWriter(saveFileDialog1.FileName, true, Encoding.ASCII); 차이는 ?
         *     1) using() 로 streamWriter 를 열면 데이터를 쓴 후 자동으로 파일을 Close 시킴.
         *                따라서 다음 번에 동일 파일을 다시 OPEN 한 후 데이터를 써야 되고, 별다른 옵션이 없으면 마지막에 저장 됨.
         *     2) using 을 사용하지 않으면 
         *               File 이 Open 상태가 유지되고, close 를 해야 파일이 닫힌다.
         *   
         *  [방법2]
         *     -> 아래 형태로 반복 실행
         *      FileStream fs = new FileStream(@".\\Hello.txt", FileMode.Append, FileAccess.Write, FileShare.ReadWrite);
         *       StreamWriter sw = new StreamWriter(fs);
         *      sw.WriteLine(DateTime.Now);
         *      sw.Close();
         *      fs.Close();
         *   
         *   비교 의견 :
         *      파일 Open / CLose 가 빈법히 일어나면 안전하게 저장이 될 수 있는 장점이 있을 수 있을 것으로 생각되나 
         *                                           시간이 걸릴 수가 있을 것으로 보임, ???
         *      폴더 / 파일명이 공유되어야 됨.
         *             --> saveFileDialog 로 선언함으로써 saveFileDialog 를 사용하면 동일 위치의 파일을 제어할 수 있음
         *             
         *  string pathDestination = System.IO.Path.Combine(path, System.IO.Path.GetFileName(mySaveFileDialog.FileName));
         *  string savePath = Path.GetDirectoryName(sf.FileName);  // SaveFileDialog sf = new SaveFileDialog();
         *  현재 디렉터리의 경로를 구한다
         *      var workdir = Directory.GetCurrentDirectory();
         *  현재 디렉터리를 수정한다
         *      Directory.SetCurrentDirectory(@”C:\Example”);
         *  Creating the directory
         *      string dir = @"C:\test"; // If directory does not exist, create it.
         *      if (! Directory. Exists(dir)) { Directory. CreateDirectory(dir); }
         *      
         */
        private bool  SelectSaveLogFile()
        {
            bool NewFile = false;
            // Log 폴더가 존재하는 지 확인하고 없으면 생성
            string startFolder = Application.StartupPath;           // 실행파일 위치
            //string exeFolderName = Application.ExecutablePath;     // 실행파일 위치 + 이름
            string logFoler = Path.Combine(startFolder, "Log");
            if (Directory.Exists(logFoler) == false)
            {
                Directory.CreateDirectory(logFoler);
            }
            Directory.SetCurrentDirectory(@logFoler);   // Log Folder 로 이동

            // Log File 생성 -> Global 로 선언
            // SaveFileDialog logFileDlg = new SaveFileDialog();

            logFileDlg.InitialDirectory = Environment.CurrentDirectory; 
                             // Directory.SetCurrentDirectory(@logFoler); 로 변경한 폴더으 값을 저장
            logFileDlg.Title = "LB Project : Log 저장 파일 설정 "; // SaveDialog 의 이름 
            logFileDlg.RestoreDirectory = true; // 대화상자를 닫기 전에 디렉토리를 이전에 선택한 디렉토리로 복원.
            // 파일 확장자
            logFileDlg.AddExtension = true;  // 확장명을 입력하지 않을 때, 자동으로 확장자를 추가할 수 있습니다.
            logFileDlg.DefaultExt   = "csv";
            logFileDlg.Filter       = "CSV files (*.csv)|*.csv;*.log|All files (*.*)|*.*";
            logFileDlg.FilterIndex  = 2;
            // 파일 이름, 중복 처리  
            logFileDlg.OverwritePrompt = true;  // 기본값: true 파일이 이미 존재하면 덮어쓰기 할지를 묻는 대화상자를 표시합니다.
            logFileDlg.FileName = "Log_" + DateTime.Now.ToString("yyyyMMdd-HHmmss") + ".csv";
            // 파일이 존재하는 지 확인 : TRUE 로 선언, 파일이 없으면 안됨, false 로 하면 신규 파일이 생성됨.
            //logFileDlg.CheckFileExists = true;

            if (logFileDlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    // File이름 생성
                    rtbSaveLogFilename.Text = logFileDlg.FileName;
                    rtbSaveLogFilename.Text = Path.GetFileName(logFileDlg.FileName);
                    rtbPathSave.Text =  Path.GetDirectoryName(logFileDlg.FileName);

                    string Title = GetLogTitle_LB();

                    // using 문 : { ..} 실행 후  Close( )를 자동으로 해줌\
                    using (StreamWriter swSaveLog = new StreamWriter(logFileDlg.FileName, true, Encoding.ASCII))
                    // swSaveLogFileTimer = new StreamWriter(logFileDlg.FileName, true, Encoding.ASCII);
                    {
                        swSaveLog.WriteLine(Title);
                        // *.csv 생성용만 추가하고, 데이터는 Timer 에서 추가.
                    }
                    
                }
                catch (Exception e)
                {
                    MessageBox.Show("Open -> Exception: " + e.Message);
                }
                finally
                {
                    logFileDlg.Dispose(); // OpenFileDialog 리소스 해제    --> 동일 파일에 계속 쓰는 지 시험 필요
                    NewFile = true;
                }
            }
            else
            {
                NewFile = false;
            }

            return NewFile;
        }

        private void btnLogStop_Click(object sender, EventArgs e)
        {
            // Stop Timer
            stopWatchTimer.Stop();
            sw.Stop();

            // button control
            btnLogStart.Enabled = true;
            btnLogStop.Enabled = false;
            
            btnLogStart.BackColor = System.Drawing.Color.White;
            btnLogStart.ForeColor = System.Drawing.Color.Black;

            // Close File
            try
            {
                //close the file
                // swSaveLogFileTimer.Close();
                // 1 Line 단위로 CLose 시켜서 처리할 일이 없음
            }
            catch (Exception ex)
            {
                MessageBox.Show("Close -> Exception: " + ex.Message);
            }
            finally
            {
            }
        }


        private void timerSaveLog_Tick(object sender, EventArgs e)
        {
            UInt32 period = stopWatchTimer.Interval;
            UInt32 count = stopWatchTimer.TimerCount;
            Color[] colors = new Color[6] { Color.SeaShell, Color.Linen, Color.Moccasin, Color.PaleGreen, Color.Cyan, Color.LavenderBlush };
            try
            {
                // File에 저장 , 저장후 using(..) 에 의하여 자동으로 close() 됨 
                using (StreamWriter swSaveLog = new StreamWriter(logFileDlg.FileName, true, Encoding.ASCII))
                {
                    string Msg = GetLogMessage_LB();     // 1 Line Data
                    swSaveLog.WriteLine(Msg);
                }

                // 저장 버튼을 깝밖임
                if (stopWatchTimer.Interval < 1000)
                    count /= (UInt32)(1000 / period);
                if ((count % 2) == 0)
                {
                    btnLogStart.BackColor = System.Drawing.Color.PaleGreen;
                    //btnLogStart.ForeColor = System.Drawing.Color.Yellow;
                }
                else
                {
                    btnLogStart.BackColor = System.Drawing.Color.Yellow;
                    //btnLogStart.ForeColor = System.Drawing.Color.Red;
                }
                stopWatchTimer.TimerCount++;
            }
            catch (Exception ex)
            {
                Console.WriteLine("write -> Exception: " + ex.Message);
            }
            finally
            {
                //Console.WriteLine("write -> Executing finally block.");
            }

        }




#endregion
    }
}