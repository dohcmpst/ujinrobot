﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

/// <summary>
/// Inclusion of PEAK PCAN-Basic namespace
/// </summary>
using Peak.Can.Basic;
using TPCANHandle = System.UInt16;
using TPCANBitrateFD = System.String;
using TPCANTimestampFD = System.UInt64;
using System.IO;
using System.Data.SqlTypes;
using System.Net.NetworkInformation;
using static System.Resources.ResXFileRef;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Reflection;
using System.Security.Claims;
using System.Threading.Tasks;
using Watchdog.Timer;
using System.Threading;

namespace PCANBasicProject
{
    public partial class Form_Main : Form
    {
        #region  Glabal Variable

        /* Default Value */
        const Int32 DEFAULT_CAPACITY = 380;      // 30Ah
        const Int32 DEFAULT_OVP = 4200;         // mV
        const Int32 DEFAULT_UVP = 3000;         // mV
        const Int32 DEFAULT_COCP = 30;          // A
        const Int32 DEFAULT_DOCP = -90;         // A
        const Int32 DEFAULT_COTP = 55;          // C
        const Int32 DEFAULT_CUTP = -5;          // C
        const Int32 DEFAULT_DOTP = 65;          // C
        const Int32 DEFAULT_DUTP = -20;         // C
        const Int32 DEFAULT_CPFV = 3600;        // mV
        const Int32 DEFAULT_CPFdV = 200;        // mV
        const Int32 DEFAULT_DPFV = 3200;        // mV
        const Int32 DEFAULT_DPFdV = 250;        // mV

        /* CAN ID */
        const byte CONTROL_FIRST = 0xFF;
        const byte CONTROL_SECOND = 0x00;
        const byte CONTROL_ZERO = 0x00;
        const UInt32 SEND_DLC_LB = 8;           // 항상 8로 고정 시킴, RTR 목적으로 사용시는 D[0] = 0xFF, D[1] = 0x00 이고, 나머지는 무시
        const UInt32 SEND_DLC_LB_RTR = 1;           // RTR 사용

        // Monitoring 제어
        const UInt32 CAN_REQ_DATA_ON = 0x1FF;       // 주기적인 데이터 송신 시잗
        const UInt32 CAN_REQ_DATA_OFF = 0x1FE;

        // 보호 기능
        const UInt32 CAN_REQ_PROTECT_LEVEL = 0x120;
        const UInt32 CAN_REQ_CLEAR_PF = 0x121;

        const UInt32 CAN_RPT_PROTECT_CAP_TEMP = 0x131;		// CAP, COTP,CUTP, DOTP, DUTP
        const UInt32 CAN_RPT_PROTECT_VOLTCUR = 0x132;		// OVP, UVP, COCP, DOCP
        const UInt32 CAN_RPT_PROTECT_PF = 0x133;		// CPF, DPF

        const UInt32 CAN_SET_PROTECT_CAP_TEMP = 0x141;		// CAP, COTP,CUTP, DOTP, DUTP
        const UInt32 CAN_SET_PROTECT_VOLTCUR = 0x142;		// OVP, UVP, COCP, DOCP
        const UInt32 CAN_SET_PROTECT_PF = 0x143;      // CPF, DPF

        // EVENT 
        const UInt32 CAN_REQ_EVENT_DATA = 0x1A0;	    // 이벤트 요구
        const UInt32 CAN_RPT_EVENT_DATA1 = 0x1A1;      // 응답1
        const UInt32 CAN_RPT_EVENT_DATA2 = 0x1A2;	    // 응답2
        const UInt32 CAN_RPT_EVENT_DATA3 = 0x1A3;      // 응답3


        // 730 ~  ... : 정보
        const UInt32 CAN_RPT_DATA_SYS = 0x730;

        /* Event, Drive Log */
        const UInt32 CAN_ID_EVENT_REQ = 0x780;
        const UInt32 CAN_ID_EVENT_RPT = 0x781;

        const UInt32 CAN_ID_LOG_REQ = 0x790;
        const UInt32 CAN_ID_LOG_RPT = 0x791;

        #endregion


        #region Button Control
        private void btnReadFromBMS_Click(object sender, EventArgs e)
        {
            TPCANMsg CANMsg = new TPCANMsg();
            CANMsg.DATA = new byte[8];

            CANMsg.ID = CAN_REQ_PROTECT_LEVEL;
            CANMsg.LEN = (byte)SEND_DLC_LB;
            CANMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD;

            //for (int i = 0; i < GetLengthFromDLC(CANMsg.LEN, true); i++)  DLC 길이 (0 ~ 16) 에 따라서 전체 데이터[N]의 N 값이 달라짐 
            CANMsg.DATA[0] = CONTROL_FIRST;
            CANMsg.DATA[1] = CONTROL_SECOND;
            CANMsg.DATA[2] = CONTROL_ZERO;
            CANMsg.DATA[3] = CONTROL_ZERO;
            CANMsg.DATA[4] = CONTROL_ZERO;
            CANMsg.DATA[5] = CONTROL_ZERO;
            CANMsg.DATA[6] = CONTROL_ZERO;
            CANMsg.DATA[7] = CONTROL_ZERO;

            if (PCANBasic.Write(m_PcanHandle, ref CANMsg) != TPCANStatus.PCAN_ERROR_OK)
            {
                MessageBox.Show("CAN_REQ_PROTECT_LEVEL() Fail !!! ");
            }
        }

        private void btnSaveToBMS_Click(object sender, EventArgs e)
        {
            SetProtect_Capacity_Temp();
            Thread.Sleep(10);
            SetProtect_VoltCurrent();
            Thread.Sleep(10);
            SetProtect_PF();
            Thread.Sleep(10);
            btnReadFromBMS_Click(sender, e);
        }

        private void btnSaveDefaultToBMS_Click(object sender, EventArgs e)
        {
            nudCapacity.Value = DEFAULT_CAPACITY;
            nudOVP.Value = DEFAULT_OVP;
            nudUVP.Value = DEFAULT_UVP;
            nudCOCP.Value = DEFAULT_COCP;
            nudDOCP.Value = DEFAULT_DOCP;
            nudCOTP.Value = DEFAULT_COTP;
            nudCUTP.Value = DEFAULT_CUTP;
            nudDOTP.Value = DEFAULT_DOTP;
            nudDUTP.Value = DEFAULT_DUTP;
            nudCPFV.Value = DEFAULT_CPFV;
            nudCPFdV.Value = DEFAULT_CPFdV;
            nudDPFV.Value = DEFAULT_DPFV;
            nudDPFdV.Value = DEFAULT_DPFdV;

            btnSaveToBMS_Click(sender, e);
        }

        private void btnClearPF_Click(object sender, EventArgs e)
        {
            TPCANMsg CANMsg = new TPCANMsg();
            CANMsg.DATA = new byte[8];

            CANMsg.ID = CAN_REQ_CLEAR_PF;
            CANMsg.LEN = (byte)SEND_DLC_LB;
            CANMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD;

            //for (int i = 0; i < GetLengthFromDLC(CANMsg.LEN, true); i++)  DLC 길이 (0 ~ 16) 에 따라서 전체 데이터[N]의 N 값이 달라짐 
            CANMsg.DATA[0] = CONTROL_FIRST;
            CANMsg.DATA[1] = CONTROL_SECOND;
            CANMsg.DATA[2] = CONTROL_ZERO;
            CANMsg.DATA[3] = CONTROL_ZERO;
            CANMsg.DATA[4] = CONTROL_ZERO;
            CANMsg.DATA[5] = CONTROL_ZERO;
            CANMsg.DATA[6] = CONTROL_ZERO;
            CANMsg.DATA[7] = CONTROL_ZERO;

            if (PCANBasic.Write(m_PcanHandle, ref CANMsg) != TPCANStatus.PCAN_ERROR_OK)
            {
                MessageBox.Show("CAN_REQ_CLEAR_PF() Fail !!! ");
            }
        }

        // Start Monitoring
        private void btnMonitorON_Click(object sender, EventArgs e)
        {
            if (m_IsConnected)
            {
                lblInfoMonitor.Text = "데이터 송수신 가능";
                lblBmsRcvStateEvent.Visible = false;
                lblBmsRcvStateProject.Visible = false;

                btnReadFromBMS.Enabled = true;
                btnSaveToBMS.Enabled = true;
                btnSaveDefaultToBMS.Enabled = true;
                btnClearPF.Enabled = true;
                btnMonitorON.Enabled = false;
                btnMonitorON.BackColor = Color.WhiteSmoke; //Color.Azure;
                btnMonitorON.ForeColor = Color.Transparent;
                btnMonitorOFF.Enabled = true;
                btnMonitorOFF.BackColor = Color.Transparent;
                btnMonitorOFF.ForeColor = Color.Black;
                RequestLbStatus();
            }
        }

        // Stop Monitoring
        private void btnMonitorOFF_Click(object sender, EventArgs e)
        {
            if (m_IsConnected)
            {
                lblInfoMonitor.Text = "데이터 송수신 중지";
                lblBmsRcvStateEvent.Visible = true;
                lblBmsRcvStateProject.Visible = true;

                btnReadFromBMS.Enabled = false;
                btnSaveToBMS.Enabled = false;
                btnSaveDefaultToBMS.Enabled = false;
                btnClearPF.Enabled = false;

                btnMonitorON.Enabled = true;
                btnMonitorON.BackColor = Color.Transparent;
                btnMonitorON.ForeColor = Color.Black;
                btnMonitorOFF.Enabled = false;
                btnMonitorOFF.BackColor = Color.WhiteSmoke;
                btnMonitorOFF.ForeColor = Color.Transparent;
                StopLbStatus();
            }
        }
        #endregion

        #region CAM 송신 함수
#if false
        1. 정수형
            C# 형	.NET 형	Byte	값	제곱
            sbyte	SByte	1	-128 ~ 127 (부호있음)	2^8 -1
            byte	Byte 	1	0 ~ 255 (부호없음)
            short	Int16	2	-32,768 ~ 32,767 (부호있음) / 2^16 - 1	2^16 - 1
            ushort	UInt16	2	0 ~ 65,535 (부호없음)
            int	Int32	4	-2,147,483,648 ~ 2,147,483,647 (부호있음) / 2^32 - 1	2^32 - 1
            uint	Uint32	4	0 ~ 4,294,967,295 (부호없음)
            long	Int64	8	-9,223,372,036,854,775,808 - 9,223,372,036,854,775,807 (부호있음) / 2^64-1	2^64 - 1
            ulong	UInt64	8	0 ~ 18,446,744,073,709,551,615 (부호없음)

        2. 실수형
            C# 형	.NET 형	Byte	값
            float	Single	4	약 +/-1.5*10^-45 ~ 약 +/-3.4*10^38 / 유효 숫자 7개 / 32Bit의 부동 소숫점 숫자
            double	Double	8	약 +/-5.0*10^-324 ~ 약 +/-1.7*10^308 / 유요 숫자 15 ~ 16개 / 64Bit의 부동 소숫점 숫자
            decimal	Decimal	12	약 +/-1.0*10^28 ~ 약 +/- 7.9*10^28 / 유효 숫자 28개 / 96Bit의 부호있는 숫자

             float과 double형은 IEEE 754 표준을 따릅니다. 
             반면 decimal은 가장 적음 범위의 숫자를 지원하지만 반올림 오류가 발생하지 않기 때문에  28자리까지 저장이 가능합니다.

            float t1Float = 1.2;
            float t2Float = 1.2f;
            float t3Float = 1.2F;
 
            double t1Double = 1.234;
            double t2Double = 1.234d;
            double t3Double = 1.234D;
 
            decimal t1Decimal = 1.23456789m;
            decimal t2Decimal = 1.23456789M;
            float은 f나 F, double은 d나 D를 붙이거나 생략해도 되지만 decimal은 m, M을 붙여야 합니다.
#endif


        public byte[] ConvertByte(byte Value)
        {
            byte[] intBytes = BitConverter.GetBytes(Value);
            //--if (BitConverter.IsLittleEndian) Array.Reverse(intBytes);   BigEndian 으로 변경 됨
            //Console.WriteLine("Byte : {0} -> {1} {2} ", Value, Convert.ToString(intBytes[0], 16), Convert.ToString(intBytes[1], 16));
            return intBytes;
        }

        public byte[] ConvertByte(SByte Value)
        {
            byte[] intBytes = BitConverter.GetBytes(Value);
            //--if (BitConverter.IsLittleEndian) Array.Reverse(intBytes);   BigEndian 으로 변경 됨
            //Console.WriteLine("SByte : {0} -> {1} {2} ", Value, Convert.ToString(intBytes[0], 16), Convert.ToString(intBytes[1], 16));
            return intBytes;
        }
        
        public byte[] ConvertByte(Int16 Value)
        {
            byte[] intBytes = BitConverter.GetBytes(Value);
            //--if (BitConverter.IsLittleEndian) Array.Reverse(intBytes);   BigEndian 으로 변경 됨
            Console.WriteLine("{0} {1}", Convert.ToString(intBytes[0], 16), Convert.ToString(intBytes[1], 16));
            return intBytes;
        }

        public byte[] ConvertByte(UInt16 Value)
        {
            byte[] intBytes = BitConverter.GetBytes(Value);
            //--if (BitConverter.IsLittleEndian)  Array.Reverse(intBytes);  BigEndian 으로 변경 됨
            //Console.WriteLine("{0} {1}",
            //    Convert.ToString(intBytes[0], 16), Convert.ToString(intBytes[1], 16));
            return intBytes;
        }

        public byte[] ConvertByte(Int32 Value)
        {
            byte[] intBytes = BitConverter.GetBytes(Value);
            //--if (BitConverter.IsLittleEndian)  Array.Reverse(intBytes);
            //Console.WriteLine("{0} {1} {2} {3}",
            //    Convert.ToString(intBytes[0], 16), Convert.ToString(intBytes[1], 16), Convert.ToString(intBytes[2], 16), Convert.ToString(intBytes[3], 16));
            return intBytes;
            //byte[] result = intBytes;
        }
        public byte[] ConvertByte(UInt32 Value)
        {
            byte[] intBytes = BitConverter.GetBytes(Value);
            //-- if (BitConverter.IsLittleEndian) Array.Reverse(intBytes);
            //Console.WriteLine("{0} {1} {2} {3}",
            //    Convert.ToString(intBytes[0], 16), Convert.ToString(intBytes[1], 16), Convert.ToString(intBytes[2], 16), Convert.ToString(intBytes[3], 16));
            return intBytes;
            //byte[] result = intBytes;
        }


        private TPCANStatus SetProtect_Capacity_Temp()
        {
            /* DLC = 8 로 고정,
             * Type = STD 고정
             * RTR  = 미사용
             */
            byte[] result;
            TPCANMsg CANMsg = new TPCANMsg();
            CANMsg.DATA = new byte[8];

            CANMsg.ID = CAN_SET_PROTECT_CAP_TEMP;
            CANMsg.LEN = (byte)SEND_DLC_LB;
            CANMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD;

            //for (int i = 0; i < GetLengthFromDLC(CANMsg.LEN, true); i++)  DLC 길이 (0 ~ 16) 에 따라서 전체 데이터[N]의 N 값이 달라짐 
            byte[] Cap = BitConverter.GetBytes((UInt16)nudCapacity.Value);
            byte[] COTP = BitConverter.GetBytes((SByte)nudCOTP.Value);
            byte[] CUTP = BitConverter.GetBytes((SByte)nudCUTP.Value);
            byte[] DOTP = BitConverter.GetBytes((SByte)nudDOTP.Value);
            byte[] DUTP = BitConverter.GetBytes((SByte)nudDUTP.Value);

            CANMsg.DATA[0] = Cap[0]; // ConvertByte((byte)nudCapaciry.Value);  양수는 무관하나 음수는 오류 발생
            CANMsg.DATA[1] = Cap[1];
            CANMsg.DATA[2] = CONTROL_ZERO;
            CANMsg.DATA[3] = CONTROL_ZERO;
            CANMsg.DATA[4] = COTP[0];
            CANMsg.DATA[5] = CUTP[0];
            CANMsg.DATA[6] = DOTP[0];
            CANMsg.DATA[7] = DUTP[0];

            #if false
            Console.Write("Ah = {0}, COTP = {1}, CUTP = {2} , DOTP = {3}, DUTP = {4} - ",
                            nudCapacity.Value, nudCOTP.Value, nudCUTP.Value, nudDOTP.Value, nudDUTP.Value);
            for (int i = 0; i < 8; i++)
               System.Console.Write("{0} ", CANMsg.DATA[i].ToString("X2"));
            System.Console.WriteLine("\n");
            #endif

            return PCANBasic.Write(m_PcanHandle, ref CANMsg);
        }

        private TPCANStatus SetProtect_VoltCurrent()
        {
            /* DLC = 8 로 고정,
             * Type = STD 고정
             * RTR  = 미사용
             */
            TPCANMsg CANMsg = new TPCANMsg();
            CANMsg.DATA = new byte[8];
            
            CANMsg.ID = CAN_SET_PROTECT_VOLTCUR; //result = ConvertByte(KKK);
            CANMsg.LEN = (byte)SEND_DLC_LB;
            CANMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD;

            byte[] OVP = BitConverter.GetBytes((UInt16)nudOVP.Value);
            byte[] UVP = BitConverter.GetBytes((UInt16)nudUVP.Value);
            byte[] COCP = BitConverter.GetBytes((SByte)nudCOCP.Value);
            byte[] DOCP = BitConverter.GetBytes((SByte)nudDOCP.Value);

            CANMsg.DATA[0] = OVP[0];
            CANMsg.DATA[1] = OVP[1];
            CANMsg.DATA[2] = UVP[0];
            CANMsg.DATA[3] = UVP[1];
            CANMsg.DATA[4] = CONTROL_ZERO;
            CANMsg.DATA[5] = CONTROL_ZERO;
            CANMsg.DATA[6] = COCP[0]; 
            CANMsg.DATA[7] = DOCP[0];

            #if false
            System.Console.WriteLine("Volt : {0}, {1}, Current : {2}, {3}  - ", nudOVP.Value, nudUVP.Value, nudCOCP.Value, nudDOCP.Value);
            for (int i = 0; i < 8; i++)
                System.Console.Write("{0} ", CANMsg.DATA[i].ToString("X2"));
            System.Console.WriteLine("\n");
            #endif
            return PCANBasic.Write(m_PcanHandle, ref CANMsg);
        }


        private TPCANStatus SetProtect_PF()
        {
            /* DLC = 8 로 고정,
             * Type = STD 고정
             * RTR  = 미사용
             */
            TPCANMsg CANMsg = new TPCANMsg();
            CANMsg.DATA = new byte[8];

            CANMsg.ID = CAN_SET_PROTECT_PF;
            CANMsg.LEN = (byte)SEND_DLC_LB;
            CANMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_STANDARD;

            byte[] CPFV = BitConverter.GetBytes((UInt16)nudCPFV.Value);
            byte[] CPFdV = BitConverter.GetBytes((UInt16)nudCPFdV.Value);
            byte[] DPFV = BitConverter.GetBytes((UInt16)nudDPFV.Value);
            byte[] DPFdV = BitConverter.GetBytes((UInt16)nudDPFdV.Value);

            CANMsg.DATA[0] = CPFV[0];
            CANMsg.DATA[1] = CPFV[1];
            CANMsg.DATA[2] = CPFdV[0];
            CANMsg.DATA[3] = CPFdV[1];
            CANMsg.DATA[4] = DPFV[0];
            CANMsg.DATA[5] = DPFV[1];
            CANMsg.DATA[6] = DPFdV[0];
            CANMsg.DATA[7] = DPFdV[1];

            #if false
            System.Console.WriteLine("Chg : FV = {0}, dV = {1} , DisChg : FV = {2}, dV = {3}  - ", nudCPFV.Value, nudCPFdV.Value, nudDPFV.Value, nudDPFdV.Value);
            for (int i = 0; i < 8; i++)
                System.Console.Write("{0} ", CANMsg.DATA[i].ToString("X2"));
            System.Console.WriteLine("\n");
            #endif
            return PCANBasic.Write(m_PcanHandle, ref CANMsg);
        }

        private TPCANStatus RequestLbStatus()
        {
            /* DLC = 8 로 고정,
             * Type = STD 고정
             * RTR  = 사용
             */
            TPCANMsg CANMsg = new TPCANMsg();
            CANMsg.DATA = new byte[8];

            CANMsg.ID = CAN_REQ_DATA_ON;
            CANMsg.LEN = (byte)SEND_DLC_LB_RTR;
            CANMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_RTR;  //  TPCANMessageType.PCAN_MESSAGE_STANDARD;

            //for (int i = 0; i < GetLengthFromDLC(CANMsg.LEN, true); i++)  DLC 길이 (0 ~ 16) 에 따라서 전체 데이터[N]의 N 값이 달라짐 
            CANMsg.DATA[0] = CONTROL_FIRST;
            CANMsg.DATA[1] = CONTROL_SECOND;
            CANMsg.DATA[2] = CONTROL_ZERO;
            CANMsg.DATA[3] = CONTROL_ZERO;
            CANMsg.DATA[4] = CONTROL_ZERO;
            CANMsg.DATA[5] = CONTROL_ZERO;
            CANMsg.DATA[6] = CONTROL_ZERO;
            CANMsg.DATA[7] = CONTROL_ZERO;

            return PCANBasic.Write(m_PcanHandle, ref CANMsg);
        }

        private TPCANStatus StopLbStatus()
        {
            /* DLC = 8 로 고정,
             * Type = STD 고정
             * RTR  = 사용
             */
            TPCANMsg CANMsg = new TPCANMsg();
            CANMsg.DATA = new byte[8];

            CANMsg.ID = CAN_REQ_DATA_OFF;
            CANMsg.LEN = (byte)SEND_DLC_LB_RTR;
            CANMsg.MSGTYPE = TPCANMessageType.PCAN_MESSAGE_RTR;  //  TPCANMessageType.PCAN_MESSAGE_STANDARD;

            //for (int i = 0; i < GetLengthFromDLC(CANMsg.LEN, true); i++)  DLC 길이 (0 ~ 16) 에 따라서 전체 데이터[N]의 N 값이 달라짐 
            CANMsg.DATA[0] = CONTROL_FIRST;
            CANMsg.DATA[1] = CONTROL_SECOND;
            CANMsg.DATA[2] = CONTROL_ZERO;
            CANMsg.DATA[3] = CONTROL_ZERO;
            CANMsg.DATA[4] = CONTROL_ZERO;
            CANMsg.DATA[5] = CONTROL_ZERO;
            CANMsg.DATA[6] = CONTROL_ZERO;
            CANMsg.DATA[7] = CONTROL_ZERO;

            return PCANBasic.Write(m_PcanHandle, ref CANMsg);
        }


        private void Display_RcvProtect_CapTemp(int DLC, byte[] canData) 
        {
            txtCapacity.Text = (BitConverter.ToUInt16(canData, 0)).ToString();
            // canData[1]
            // canData[2]
            // canData[3]
            txtCOTP.Text = ((SByte)canData[4]).ToString();
            txtCUTP.Text = ((SByte)canData[5]).ToString();
            txtDOTP.Text = ((SByte)canData[6]).ToString();
            txtDUTP.Text = ((SByte)canData[7]).ToString();
        }


        private void Display_RcvProtect_VoltCur(int DLC, byte[] canData)
        {
            txtOVP.Text = (BitConverter.ToUInt16(canData, 0)).ToString();     
            txtUVP.Text = (BitConverter.ToUInt16(canData, 2)).ToString();
            // canData[4,5]
            txtCOCP.Text = ((SByte)canData[6]).ToString();
            txtDOCP.Text = ((SByte)canData[7]).ToString();
        }


        private void Display_RcvProtect_PF(int DLC, byte[] canData)
        {
            txtCPFV.Text = (BitConverter.ToUInt16(canData, 0)).ToString();
            txtCPFdV.Text = (BitConverter.ToUInt16(canData, 2)).ToString();
            txtDPFV.Text = (BitConverter.ToUInt16(canData, 4)).ToString();
            txtDPFdV.Text = (BitConverter.ToUInt16(canData, 6)).ToString();
        }



#if false
        private TPCANStatus WriteFrameOne(TPCANMsg CANMsg)
        {
            TPCANMsg CANMsg;
            TextBox txtbCurrentTextBox;

            // We create a TPCANMsg message structure 
            //
            CANMsg = new TPCANMsg();
            CANMsg.DATA = new byte[8];

            // We configurate the Message.  The ID,
            // Length of the Data, Message Type
            // and the data
            //
            CANMsg.ID = Convert.ToUInt32(txtID.Text, 16);
            CANMsg.LEN = Convert.ToByte(nudLength.Value);
            CANMsg.MSGTYPE = (chbExtended.Checked) ? TPCANMessageType.PCAN_MESSAGE_EXTENDED : TPCANMessageType.PCAN_MESSAGE_STANDARD;
            // If a remote frame will be sent, the data bytes are not important.
            //
            if (chbRemote.Checked)
                CANMsg.MSGTYPE |= TPCANMessageType.PCAN_MESSAGE_RTR;
            else
            {
                // We get so much data as the Len of the message
                //
                for (int i = 0; i < GetLengthFromDLC(CANMsg.LEN, true); i++)
                {
                    txtbCurrentTextBox = (TextBox)this.Controls.Find("txtData" + i.ToString(), true)[0];
                    CANMsg.DATA[i] = Convert.ToByte(txtbCurrentTextBox.Text, 16);
                }
            }

            // The message is sent to the configured hardware
            //
            return PCANBasic.Write(m_PcanHandle, ref CANMsg);
        }
#endif

        #endregion



    }
}