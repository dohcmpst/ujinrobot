﻿namespace PCANBasicProject
{
    partial class Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.chbCanFD = new System.Windows.Forms.CheckBox();
            this.cbbHwType = new System.Windows.Forms.ComboBox();
            this.cbbInterrupt = new System.Windows.Forms.ComboBox();
            this.laInterrupt = new System.Windows.Forms.Label();
            this.cbbIO = new System.Windows.Forms.ComboBox();
            this.laIOPort = new System.Windows.Forms.Label();
            this.laHwType = new System.Windows.Forms.Label();
            this.cbbBaudrates = new System.Windows.Forms.ComboBox();
            this.laBaudrate = new System.Windows.Forms.Label();
            this.btnHwRefresh = new System.Windows.Forms.Button();
            this.cbbChannel = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtBitrate = new System.Windows.Forms.TextBox();
            this.btnInit = new System.Windows.Forms.Button();
            this.btnRelease = new System.Windows.Forms.Button();
            this.laBitrate = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnFilterQuery = new System.Windows.Forms.Button();
            this.chbFilterExt = new System.Windows.Forms.CheckBox();
            this.nudIdTo = new System.Windows.Forms.NumericUpDown();
            this.nudIdFrom = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.rdbFilterOpen = new System.Windows.Forms.RadioButton();
            this.rdbFilterCustom = new System.Windows.Forms.RadioButton();
            this.rdbFilterClose = new System.Windows.Forms.RadioButton();
            this.btnFilterApply = new System.Windows.Forms.Button();
            this.btnParameterSet = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.nudDelay = new System.Windows.Forms.NumericUpDown();
            this.btnParameterGet = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.nudDeviceId = new System.Windows.Forms.NumericUpDown();
            this.laDeviceOrDelay = new System.Windows.Forms.Label();
            this.cbbParameter = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.rdbParamActive = new System.Windows.Forms.RadioButton();
            this.rdbParamInactive = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnStatus = new System.Windows.Forms.Button();
            this.btnGetVersions = new System.Windows.Forms.Button();
            this.lbxInfo = new System.Windows.Forms.ListBox();
            this.btnInfoClear = new System.Windows.Forms.Button();
            this.lblInfoMonitor = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lstMessages = new PCANBasicProject.Form_Main.ListViewNF();
            this.clhType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clhID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clhData = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clhLength = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clhCount = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cihPeriod = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clhRcvTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tmrRead = new System.Windows.Forms.Timer(this.components);
            this.tmrDisplay = new System.Windows.Forms.Timer(this.components);
            this.rtbCanMsg = new System.Windows.Forms.RichTextBox();
            this.on_sec = new System.Windows.Forms.Button();
            this.off_1sec = new System.Windows.Forms.Button();
            this.btRtbSave = new System.Windows.Forms.Button();
            this.btRtbInit = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.logFileDlg = new System.Windows.Forms.SaveFileDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.파일ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pCAN설정ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.저장ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.종료ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.receiveIDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.receiveLogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transmitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.waccoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.도움말ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabCntProject = new System.Windows.Forms.TabControl();
            this.tabPcanConfig = new System.Windows.Forms.TabPage();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.chbShowPeriod = new System.Windows.Forms.CheckBox();
            this.btnMsgClear = new System.Windows.Forms.Button();
            this.rdbManual = new System.Windows.Forms.RadioButton();
            this.btnRead = new System.Windows.Forms.Button();
            this.rdbEvent = new System.Windows.Forms.RadioButton();
            this.rdbTimer = new System.Windows.Forms.RadioButton();
            this.tabProject = new System.Windows.Forms.TabPage();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.txtLastEventIndex = new System.Windows.Forms.TextBox();
            this.txtBmsRunTime = new System.Windows.Forms.TextBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.tbBmsStChgChgFet = new System.Windows.Forms.TextBox();
            this.tbBmsStChgDisFet = new System.Windows.Forms.TextBox();
            this.tbBmsStPfet = new System.Windows.Forms.TextBox();
            this.tbBmsStCfet = new System.Windows.Forms.TextBox();
            this.tbBmsIchg = new System.Windows.Forms.TextBox();
            this.tbBmsDFET = new System.Windows.Forms.TextBox();
            this.tbBmsStIdch = new System.Windows.Forms.TextBox();
            this.tbBmsStSocDisplay = new System.Windows.Forms.TextBox();
            this.tbBmsStChgKeyOn = new System.Windows.Forms.TextBox();
            this.tbBmsStSwon = new System.Windows.Forms.TextBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.tbAlarmDuta = new System.Windows.Forms.TextBox();
            this.tbAlarmCuta = new System.Windows.Forms.TextBox();
            this.tbAlarmDota = new System.Windows.Forms.TextBox();
            this.tbAlarmCota = new System.Windows.Forms.TextBox();
            this.tbAlarmDoca = new System.Windows.Forms.TextBox();
            this.tbAlarmCoca = new System.Windows.Forms.TextBox();
            this.tbAlarmCuva = new System.Windows.Forms.TextBox();
            this.tbAlarmCova = new System.Windows.Forms.TextBox();
            this.lvlTestIdHex = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.tbFaultPwdn = new System.Windows.Forms.TextBox();
            this.tbFaultShtp = new System.Windows.Forms.TextBox();
            this.tbFaultDutp = new System.Windows.Forms.TextBox();
            this.tbFaultCutp = new System.Windows.Forms.TextBox();
            this.tbFaultCotp = new System.Windows.Forms.TextBox();
            this.tbFaultDotp = new System.Windows.Forms.TextBox();
            this.tbFaultDocp = new System.Windows.Forms.TextBox();
            this.tbFaultCocp = new System.Windows.Forms.TextBox();
            this.tbFaultDuvp = new System.Windows.Forms.TextBox();
            this.tbFaultCovp = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.tbTempDiff = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.lvlPackTemp = new PCANBasicProject.Form_Main.ListViewNF();
            this.Type = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Temp = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tbTempAvg = new System.Windows.Forms.TextBox();
            this.tbTempMinNo = new System.Windows.Forms.TextBox();
            this.tbTempMax = new System.Windows.Forms.TextBox();
            this.tbTempMaxNo = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.tbTempMin = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.lvｗCellVoltage = new PCANBasicProject.Form_Main.ListViewNF();
            this.CellNo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Volt = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Balacing = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tbCellVoltMin = new System.Windows.Forms.TextBox();
            this.tbCellNoMin = new System.Windows.Forms.TextBox();
            this.tbCellNoMax = new System.Windows.Forms.TextBox();
            this.tbCellVoltMax = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.tbCellVoltDiff = new System.Windows.Forms.TextBox();
            this.tbCellVoltAvg = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.tbIdH = new System.Windows.Forms.TextBox();
            this.tbH7 = new System.Windows.Forms.TextBox();
            this.btnSendTestMsg = new System.Windows.Forms.Button();
            this.tbRC = new System.Windows.Forms.TextBox();
            this.tbH6 = new System.Windows.Forms.TextBox();
            this.tbFCC = new System.Windows.Forms.TextBox();
            this.tbCycleCount = new System.Windows.Forms.TextBox();
            this.tbH5 = new System.Windows.Forms.TextBox();
            this.tbSOP = new System.Windows.Forms.TextBox();
            this.tbSOC = new System.Windows.Forms.TextBox();
            this.tbH4 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.tbH3 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbH2 = new System.Windows.Forms.TextBox();
            this.tbPackVoltOut = new System.Windows.Forms.TextBox();
            this.tbSOH = new System.Windows.Forms.TextBox();
            this.tbH1 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.tbH0 = new System.Windows.Forms.TextBox();
            this.tbPackVoltIn = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.lblBmsRcvStateProject = new System.Windows.Forms.Label();
            this.lvlVoltage = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.tbStateIdle = new System.Windows.Forms.TextBox();
            this.tbStateFault = new System.Windows.Forms.TextBox();
            this.tbStateGood = new System.Windows.Forms.TextBox();
            this.tbStateDisChg = new System.Windows.Forms.TextBox();
            this.tbStateChg = new System.Windows.Forms.TextBox();
            this.lvlCurrent = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.lblDateTime = new System.Windows.Forms.Label();
            this.tbVersion = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tbManufacture = new System.Windows.Forms.TextBox();
            this.tbSerialNo = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPcanWrite = new System.Windows.Forms.TabPage();
            this.btnClearPF = new System.Windows.Forms.Button();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.btnMonitorON = new System.Windows.Forms.Button();
            this.btnMonitorOFF = new System.Windows.Forms.Button();
            this.label60 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.lbxBmsSetLog = new System.Windows.Forms.ListBox();
            this.btnSaveDefaultToBMS = new System.Windows.Forms.Button();
            this.btnSaveToBMS = new System.Windows.Forms.Button();
            this.btnReadFromBMS = new System.Windows.Forms.Button();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.txtDUTP = new System.Windows.Forms.TextBox();
            this.txtCUTP = new System.Windows.Forms.TextBox();
            this.txtDOTP = new System.Windows.Forms.TextBox();
            this.nudDUTP = new System.Windows.Forms.NumericUpDown();
            this.txtCOTP = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.nudCUTP = new System.Windows.Forms.NumericUpDown();
            this.nudDOTP = new System.Windows.Forms.NumericUpDown();
            this.label52 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.nudCOTP = new System.Windows.Forms.NumericUpDown();
            this.label53 = new System.Windows.Forms.Label();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.label58 = new System.Windows.Forms.Label();
            this.txtDPFdV = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.txtDPFV = new System.Windows.Forms.TextBox();
            this.txtCPFdV = new System.Windows.Forms.TextBox();
            this.nudDPFdV = new System.Windows.Forms.NumericUpDown();
            this.txtCPFV = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.nudCPFdV = new System.Windows.Forms.NumericUpDown();
            this.nudDPFV = new System.Windows.Forms.NumericUpDown();
            this.label46 = new System.Windows.Forms.Label();
            this.nudCPFV = new System.Windows.Forms.NumericUpDown();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.txtDOCP = new System.Windows.Forms.TextBox();
            this.txtCOCP = new System.Windows.Forms.TextBox();
            this.nudDOCP = new System.Windows.Forms.NumericUpDown();
            this.label50 = new System.Windows.Forms.Label();
            this.nudCOCP = new System.Windows.Forms.NumericUpDown();
            this.label51 = new System.Windows.Forms.Label();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.txtCapacity = new System.Windows.Forms.TextBox();
            this.nudCapacity = new System.Windows.Forms.NumericUpDown();
            this.label57 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.txtUVP = new System.Windows.Forms.TextBox();
            this.txtOVP = new System.Windows.Forms.TextBox();
            this.nudUVP = new System.Windows.Forms.NumericUpDown();
            this.label48 = new System.Windows.Forms.Label();
            this.nudOVP = new System.Windows.Forms.NumericUpDown();
            this.label47 = new System.Windows.Forms.Label();
            this.tabEvent = new System.Windows.Forms.TabPage();
            this.btnEventReqStop = new System.Windows.Forms.Button();
            this.lblBmsRcvStateEvent = new System.Windows.Forms.Label();
            this.rtbEventLog = new System.Windows.Forms.RichTextBox();
            this.ckbDisplayMessageEvent = new System.Windows.Forms.CheckBox();
            this.label41 = new System.Windows.Forms.Label();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.txtRunTimeInEvent = new System.Windows.Forms.TextBox();
            this.txtLastEvent = new System.Windows.Forms.TextBox();
            this.btnEventSave = new System.Windows.Forms.Button();
            this.btnClearEventLog = new System.Windows.Forms.Button();
            this.btnEventRequest = new System.Windows.Forms.Button();
            this.lblEventNameCode = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.lvwEventDetail = new PCANBasicProject.Form_Main.ListViewNF();
            this.dtNo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dtTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dtEventCode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dtVoltPack = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dtVoltMax = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dtVoltMin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dtCurrent = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dtTempMax = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.dtTempMin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lvwEventMain = new PCANBasicProject.Form_Main.ListViewNF();
            this.No = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Time = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.EventName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.EventCode = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.VoltPack = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.VoltMax = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.VoltMin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Current = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TempMax = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.TempMin = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabPcanRcvId = new System.Windows.Forms.TabPage();
            this.tabPcanRcvMsg = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.laLength = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox69 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox68 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.txtData7 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.txtData6 = new System.Windows.Forms.TextBox();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.txtData3 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.txtData5 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.txtData2 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.txtData4 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.txtData1 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.txtData0 = new System.Windows.Forms.TextBox();
            this.chbBRS = new System.Windows.Forms.CheckBox();
            this.chbFD = new System.Windows.Forms.CheckBox();
            this.chbRemote = new System.Windows.Forms.CheckBox();
            this.chbExtended = new System.Windows.Forms.CheckBox();
            this.btnWrite = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtID = new System.Windows.Forms.TextBox();
            this.nudLength = new System.Windows.Forms.NumericUpDown();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.tbLogSavePeriod = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.rtbPathSave = new System.Windows.Forms.RichTextBox();
            this.rtbSaveLogFilename = new System.Windows.Forms.RichTextBox();
            this.btnLogStart = new System.Windows.Forms.Button();
            this.btnLogStop = new System.Windows.Forms.Button();
            this.label29 = new System.Windows.Forms.Label();
            this.timerRequestEvent = new System.Windows.Forms.Timer(this.components);
            this.EventlogFileDlg = new System.Windows.Forms.SaveFileDialog();
            this.groupBox1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudIdTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudIdFrom)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDelay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDeviceId)).BeginInit();
            this.groupBox4.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.tabCntProject.SuspendLayout();
            this.tabPcanConfig.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.tabProject.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.tabPcanWrite.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBox22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDUTP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCUTP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDOTP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCOTP)).BeginInit();
            this.groupBox23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDPFdV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCPFdV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDPFV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCPFV)).BeginInit();
            this.groupBox21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDOCP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCOCP)).BeginInit();
            this.groupBox24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCapacity)).BeginInit();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudUVP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOVP)).BeginInit();
            this.tabEvent.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.tabPcanRcvId.SuspendLayout();
            this.tabPcanRcvMsg.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudLength)).BeginInit();
            this.groupBox14.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chbCanFD);
            this.groupBox1.Controls.Add(this.cbbHwType);
            this.groupBox1.Controls.Add(this.cbbInterrupt);
            this.groupBox1.Controls.Add(this.laInterrupt);
            this.groupBox1.Controls.Add(this.cbbIO);
            this.groupBox1.Controls.Add(this.laIOPort);
            this.groupBox1.Controls.Add(this.laHwType);
            this.groupBox1.Controls.Add(this.cbbBaudrates);
            this.groupBox1.Controls.Add(this.laBaudrate);
            this.groupBox1.Controls.Add(this.btnHwRefresh);
            this.groupBox1.Controls.Add(this.cbbChannel);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtBitrate);
            this.groupBox1.Controls.Add(this.btnInit);
            this.groupBox1.Controls.Add(this.btnRelease);
            this.groupBox1.Controls.Add(this.laBitrate);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox1.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(7, 6);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Size = new System.Drawing.Size(749, 87);
            this.groupBox1.TabIndex = 42;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " Connection ";
            // 
            // chbCanFD
            // 
            this.chbCanFD.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.chbCanFD.AutoSize = true;
            this.chbCanFD.Location = new System.Drawing.Point(596, 42);
            this.chbCanFD.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chbCanFD.Name = "chbCanFD";
            this.chbCanFD.Size = new System.Drawing.Size(74, 21);
            this.chbCanFD.TabIndex = 59;
            this.chbCanFD.Text = "CAN-FD";
            this.chbCanFD.UseVisualStyleBackColor = true;
            this.chbCanFD.CheckedChanged += new System.EventHandler(this.chbCanFD_CheckedChanged);
            // 
            // cbbHwType
            // 
            this.cbbHwType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbHwType.Items.AddRange(new object[] {
            "ISA-82C200",
            "ISA-SJA1000",
            "ISA-PHYTEC",
            "DNG-82C200",
            "DNG-82C200 EPP",
            "DNG-SJA1000",
            "DNG-SJA1000 EPP"});
            this.cbbHwType.Location = new System.Drawing.Point(324, 38);
            this.cbbHwType.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbbHwType.Name = "cbbHwType";
            this.cbbHwType.Size = new System.Drawing.Size(108, 25);
            this.cbbHwType.TabIndex = 50;
            this.cbbHwType.SelectedIndexChanged += new System.EventHandler(this.cbbHwType_SelectedIndexChanged);
            // 
            // cbbInterrupt
            // 
            this.cbbInterrupt.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbInterrupt.Items.AddRange(new object[] {
            "3",
            "4",
            "5",
            "7",
            "9",
            "10",
            "11",
            "12",
            "15"});
            this.cbbInterrupt.Location = new System.Drawing.Point(519, 37);
            this.cbbInterrupt.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbbInterrupt.Name = "cbbInterrupt";
            this.cbbInterrupt.Size = new System.Drawing.Size(64, 25);
            this.cbbInterrupt.TabIndex = 52;
            // 
            // laInterrupt
            // 
            this.laInterrupt.Location = new System.Drawing.Point(516, 21);
            this.laInterrupt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.laInterrupt.Name = "laInterrupt";
            this.laInterrupt.Size = new System.Drawing.Size(62, 21);
            this.laInterrupt.TabIndex = 56;
            this.laInterrupt.Text = "Interrupt:";
            // 
            // cbbIO
            // 
            this.cbbIO.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbIO.Items.AddRange(new object[] {
            "0100",
            "0120",
            "0140",
            "0200",
            "0220",
            "0240",
            "0260",
            "0278",
            "0280",
            "02A0",
            "02C0",
            "02E0",
            "02E8",
            "02F8",
            "0300",
            "0320",
            "0340",
            "0360",
            "0378",
            "0380",
            "03BC",
            "03E0",
            "03E8",
            "03F8"});
            this.cbbIO.Location = new System.Drawing.Point(444, 38);
            this.cbbIO.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbbIO.Name = "cbbIO";
            this.cbbIO.Size = new System.Drawing.Size(64, 25);
            this.cbbIO.TabIndex = 51;
            // 
            // laIOPort
            // 
            this.laIOPort.Location = new System.Drawing.Point(441, 21);
            this.laIOPort.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.laIOPort.Name = "laIOPort";
            this.laIOPort.Size = new System.Drawing.Size(64, 21);
            this.laIOPort.TabIndex = 55;
            this.laIOPort.Text = "I/O Port:";
            // 
            // laHwType
            // 
            this.laHwType.Location = new System.Drawing.Point(321, 21);
            this.laHwType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.laHwType.Name = "laHwType";
            this.laHwType.Size = new System.Drawing.Size(105, 21);
            this.laHwType.TabIndex = 54;
            this.laHwType.Text = "Hardware Type:";
            // 
            // cbbBaudrates
            // 
            this.cbbBaudrates.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbBaudrates.Items.AddRange(new object[] {
            "1 MBit/sec",
            "800 kBit/s",
            "500 kBit/sec",
            "250 kBit/sec",
            "125 kBit/sec",
            "100 kBit/sec",
            "95,238 kBit/s",
            "83,333 kBit/s",
            "50 kBit/sec",
            "47,619 kBit/s",
            "33,333 kBit/s",
            "20 kBit/sec",
            "10 kBit/sec",
            "5 kBit/sec"});
            this.cbbBaudrates.Location = new System.Drawing.Point(214, 38);
            this.cbbBaudrates.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbbBaudrates.Name = "cbbBaudrates";
            this.cbbBaudrates.Size = new System.Drawing.Size(98, 25);
            this.cbbBaudrates.TabIndex = 49;
            this.cbbBaudrates.SelectedIndexChanged += new System.EventHandler(this.cbbBaudrates_SelectedIndexChanged);
            // 
            // laBaudrate
            // 
            this.laBaudrate.Location = new System.Drawing.Point(212, 23);
            this.laBaudrate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.laBaudrate.Name = "laBaudrate";
            this.laBaudrate.Size = new System.Drawing.Size(66, 21);
            this.laBaudrate.TabIndex = 53;
            this.laBaudrate.Text = "Baudrate:";
            // 
            // btnHwRefresh
            // 
            this.btnHwRefresh.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnHwRefresh.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnHwRefresh.Location = new System.Drawing.Point(136, 35);
            this.btnHwRefresh.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnHwRefresh.Name = "btnHwRefresh";
            this.btnHwRefresh.Size = new System.Drawing.Size(60, 21);
            this.btnHwRefresh.TabIndex = 45;
            this.btnHwRefresh.Text = "Refresh";
            this.btnHwRefresh.Click += new System.EventHandler(this.btnHwRefresh_Click);
            // 
            // cbbChannel
            // 
            this.cbbChannel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbChannel.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbbChannel.Items.AddRange(new object[] {
            "None",
            "DNG-Channel 1",
            "ISA-Channel 1",
            "ISA-Channel 2",
            "ISA-Channel 3",
            "ISA-Channel 4",
            "ISA-Channel 5",
            "ISA-Channel 6",
            "ISA-Channel 7",
            "ISA-Channel 8",
            "PCC-Channel 1",
            "PCC-Channel 2",
            "PCI-Channel 1",
            "PCI-Channel 2",
            "PCI-Channel 3",
            "PCI-Channel 4",
            "PCI-Channel 5",
            "PCI-Channel 6",
            "PCI-Channel 7",
            "PCI-Channel 8",
            "USB-Channel 1",
            "USB-Channel 2",
            "USB-Channel 3",
            "USB-Channel 4",
            "USB-Channel 5",
            "USB-Channel 6",
            "USB-Channel 7",
            "USB-Channel 8"});
            this.cbbChannel.Location = new System.Drawing.Point(10, 35);
            this.cbbChannel.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbbChannel.Name = "cbbChannel";
            this.cbbChannel.Size = new System.Drawing.Size(120, 21);
            this.cbbChannel.TabIndex = 32;
            this.cbbChannel.SelectedIndexChanged += new System.EventHandler(this.cbbChannel_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 21);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 21);
            this.label1.TabIndex = 40;
            this.label1.Text = "Hardware:";
            // 
            // txtBitrate
            // 
            this.txtBitrate.Location = new System.Drawing.Point(267, 7);
            this.txtBitrate.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtBitrate.Multiline = true;
            this.txtBitrate.Name = "txtBitrate";
            this.txtBitrate.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtBitrate.Size = new System.Drawing.Size(326, 32);
            this.txtBitrate.TabIndex = 48;
            this.txtBitrate.Visible = false;
            // 
            // btnInit
            // 
            this.btnInit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInit.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnInit.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnInit.Location = new System.Drawing.Point(666, 10);
            this.btnInit.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnInit.Name = "btnInit";
            this.btnInit.Size = new System.Drawing.Size(76, 26);
            this.btnInit.TabIndex = 34;
            this.btnInit.Text = "Initialize";
            this.btnInit.Click += new System.EventHandler(this.btnInit_Click);
            // 
            // btnRelease
            // 
            this.btnRelease.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRelease.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnRelease.Enabled = false;
            this.btnRelease.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRelease.Location = new System.Drawing.Point(666, 41);
            this.btnRelease.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnRelease.Name = "btnRelease";
            this.btnRelease.Size = new System.Drawing.Size(76, 26);
            this.btnRelease.TabIndex = 35;
            this.btnRelease.Text = "Release";
            this.btnRelease.Click += new System.EventHandler(this.btnRelease_Click);
            // 
            // laBitrate
            // 
            this.laBitrate.AutoSize = true;
            this.laBitrate.Location = new System.Drawing.Point(212, 10);
            this.laBitrate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.laBitrate.Name = "laBitrate";
            this.laBitrate.Size = new System.Drawing.Size(54, 17);
            this.laBitrate.TabIndex = 46;
            this.laBitrate.Text = "Bit rate:";
            this.laBitrate.Visible = false;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox3.Controls.Add(this.btnFilterQuery);
            this.groupBox3.Controls.Add(this.chbFilterExt);
            this.groupBox3.Controls.Add(this.nudIdTo);
            this.groupBox3.Controls.Add(this.nudIdFrom);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label7);
            this.groupBox3.Controls.Add(this.rdbFilterOpen);
            this.groupBox3.Controls.Add(this.rdbFilterCustom);
            this.groupBox3.Controls.Add(this.rdbFilterClose);
            this.groupBox3.Controls.Add(this.btnFilterApply);
            this.groupBox3.Enabled = false;
            this.groupBox3.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox3.Location = new System.Drawing.Point(12, 101);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox3.Size = new System.Drawing.Size(749, 83);
            this.groupBox3.TabIndex = 44;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = " Message Filtering ";
            // 
            // btnFilterQuery
            // 
            this.btnFilterQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFilterQuery.Enabled = false;
            this.btnFilterQuery.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnFilterQuery.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnFilterQuery.Location = new System.Drawing.Point(683, 34);
            this.btnFilterQuery.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnFilterQuery.Name = "btnFilterQuery";
            this.btnFilterQuery.Size = new System.Drawing.Size(58, 21);
            this.btnFilterQuery.TabIndex = 55;
            this.btnFilterQuery.Text = "Query";
            this.btnFilterQuery.UseVisualStyleBackColor = true;
            this.btnFilterQuery.Click += new System.EventHandler(this.btnFilterQuery_Click);
            // 
            // chbFilterExt
            // 
            this.chbFilterExt.AutoSize = true;
            this.chbFilterExt.Location = new System.Drawing.Point(136, 20);
            this.chbFilterExt.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chbFilterExt.Name = "chbFilterExt";
            this.chbFilterExt.Size = new System.Drawing.Size(123, 21);
            this.chbFilterExt.TabIndex = 44;
            this.chbFilterExt.Text = "Extended Frame";
            this.chbFilterExt.UseVisualStyleBackColor = true;
            this.chbFilterExt.CheckedChanged += new System.EventHandler(this.chbFilterExt_CheckedChanged);
            // 
            // nudIdTo
            // 
            this.nudIdTo.Font = new System.Drawing.Font("Consolas", 10.18868F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudIdTo.Hexadecimal = true;
            this.nudIdTo.Location = new System.Drawing.Point(501, 48);
            this.nudIdTo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.nudIdTo.Maximum = new decimal(new int[] {
            2047,
            0,
            0,
            0});
            this.nudIdTo.Name = "nudIdTo";
            this.nudIdTo.Size = new System.Drawing.Size(80, 23);
            this.nudIdTo.TabIndex = 6;
            this.nudIdTo.Value = new decimal(new int[] {
            2047,
            0,
            0,
            0});
            // 
            // nudIdFrom
            // 
            this.nudIdFrom.Font = new System.Drawing.Font("Consolas", 10.18868F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudIdFrom.Hexadecimal = true;
            this.nudIdFrom.Location = new System.Drawing.Point(408, 48);
            this.nudIdFrom.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.nudIdFrom.Maximum = new decimal(new int[] {
            2047,
            0,
            0,
            0});
            this.nudIdFrom.Name = "nudIdFrom";
            this.nudIdFrom.Size = new System.Drawing.Size(80, 23);
            this.nudIdFrom.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(498, 24);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 21);
            this.label8.TabIndex = 43;
            this.label8.Text = "To (Hex):";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(408, 24);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(80, 21);
            this.label7.TabIndex = 42;
            this.label7.Text = "From (Hex):";
            // 
            // rdbFilterOpen
            // 
            this.rdbFilterOpen.Location = new System.Drawing.Point(136, 48);
            this.rdbFilterOpen.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdbFilterOpen.Name = "rdbFilterOpen";
            this.rdbFilterOpen.Size = new System.Drawing.Size(62, 23);
            this.rdbFilterOpen.TabIndex = 2;
            this.rdbFilterOpen.Text = "Open";
            this.rdbFilterOpen.UseVisualStyleBackColor = true;
            // 
            // rdbFilterCustom
            // 
            this.rdbFilterCustom.Location = new System.Drawing.Point(290, 50);
            this.rdbFilterCustom.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdbFilterCustom.Name = "rdbFilterCustom";
            this.rdbFilterCustom.Size = new System.Drawing.Size(92, 21);
            this.rdbFilterCustom.TabIndex = 1;
            this.rdbFilterCustom.Text = "Custom (expand)";
            this.rdbFilterCustom.UseVisualStyleBackColor = true;
            // 
            // rdbFilterClose
            // 
            this.rdbFilterClose.Checked = true;
            this.rdbFilterClose.Location = new System.Drawing.Point(214, 48);
            this.rdbFilterClose.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdbFilterClose.Name = "rdbFilterClose";
            this.rdbFilterClose.Size = new System.Drawing.Size(67, 26);
            this.rdbFilterClose.TabIndex = 0;
            this.rdbFilterClose.TabStop = true;
            this.rdbFilterClose.Text = "Close";
            this.rdbFilterClose.UseVisualStyleBackColor = true;
            // 
            // btnFilterApply
            // 
            this.btnFilterApply.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnFilterApply.Enabled = false;
            this.btnFilterApply.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnFilterApply.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnFilterApply.Location = new System.Drawing.Point(609, 34);
            this.btnFilterApply.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnFilterApply.Name = "btnFilterApply";
            this.btnFilterApply.Size = new System.Drawing.Size(57, 21);
            this.btnFilterApply.TabIndex = 44;
            this.btnFilterApply.Text = "Apply";
            this.btnFilterApply.UseVisualStyleBackColor = true;
            this.btnFilterApply.Click += new System.EventHandler(this.btnFilterApply_Click);
            // 
            // btnParameterSet
            // 
            this.btnParameterSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnParameterSet.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnParameterSet.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnParameterSet.Location = new System.Drawing.Point(608, 48);
            this.btnParameterSet.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnParameterSet.Name = "btnParameterSet";
            this.btnParameterSet.Size = new System.Drawing.Size(57, 21);
            this.btnParameterSet.TabIndex = 46;
            this.btnParameterSet.Text = "Set";
            this.btnParameterSet.UseVisualStyleBackColor = true;
            this.btnParameterSet.Click += new System.EventHandler(this.btnParameterSet_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox2.Controls.Add(this.nudDelay);
            this.groupBox2.Controls.Add(this.btnParameterGet);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.nudDeviceId);
            this.groupBox2.Controls.Add(this.laDeviceOrDelay);
            this.groupBox2.Controls.Add(this.cbbParameter);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.rdbParamActive);
            this.groupBox2.Controls.Add(this.rdbParamInactive);
            this.groupBox2.Controls.Add(this.btnParameterSet);
            this.groupBox2.Enabled = false;
            this.groupBox2.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox2.Location = new System.Drawing.Point(12, 190);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox2.Size = new System.Drawing.Size(749, 102);
            this.groupBox2.TabIndex = 45;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = " Configuration Parameters ";
            // 
            // nudDelay
            // 
            this.nudDelay.Font = new System.Drawing.Font("Consolas", 10.18868F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudDelay.Location = new System.Drawing.Point(464, 65);
            this.nudDelay.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.nudDelay.Maximum = new decimal(new int[] {
            -1,
            0,
            0,
            0});
            this.nudDelay.Name = "nudDelay";
            this.nudDelay.Size = new System.Drawing.Size(116, 23);
            this.nudDelay.TabIndex = 55;
            // 
            // btnParameterGet
            // 
            this.btnParameterGet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnParameterGet.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnParameterGet.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnParameterGet.Location = new System.Drawing.Point(682, 48);
            this.btnParameterGet.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnParameterGet.Name = "btnParameterGet";
            this.btnParameterGet.Size = new System.Drawing.Size(58, 21);
            this.btnParameterGet.TabIndex = 54;
            this.btnParameterGet.Text = "Get";
            this.btnParameterGet.UseVisualStyleBackColor = true;
            this.btnParameterGet.Click += new System.EventHandler(this.btnParameterGet_Click);
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(269, 24);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 21);
            this.label10.TabIndex = 46;
            this.label10.Text = "Activation:";
            // 
            // nudDeviceId
            // 
            this.nudDeviceId.Enabled = false;
            this.nudDeviceId.Font = new System.Drawing.Font("Consolas", 10.18868F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudDeviceId.Hexadecimal = true;
            this.nudDeviceId.Location = new System.Drawing.Point(464, 39);
            this.nudDeviceId.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.nudDeviceId.Maximum = new decimal(new int[] {
            -1,
            0,
            0,
            0});
            this.nudDeviceId.Name = "nudDeviceId";
            this.nudDeviceId.Size = new System.Drawing.Size(116, 23);
            this.nudDeviceId.TabIndex = 6;
            // 
            // laDeviceOrDelay
            // 
            this.laDeviceOrDelay.Location = new System.Drawing.Point(462, 24);
            this.laDeviceOrDelay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.laDeviceOrDelay.Name = "laDeviceOrDelay";
            this.laDeviceOrDelay.Size = new System.Drawing.Size(119, 21);
            this.laDeviceOrDelay.TabIndex = 45;
            this.laDeviceOrDelay.Text = "Device ID (Hex):";
            // 
            // cbbParameter
            // 
            this.cbbParameter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbbParameter.FormattingEnabled = true;
            this.cbbParameter.Items.AddRange(new object[] {
            "Device ID",
            "5V Power",
            "Auto-reset on BUS-OFF",
            "CAN Listen-Only",
            "Debug\'s Log",
            "Receive Status",
            "CAN Controller Number",
            "Trace File",
            "Channel Identification (USB)",
            "Channel Capabilities",
            "Bit rate Adaptation",
            "Get Bit rate Information",
            "Get Bit rate FD Information",
            "Get CAN Nominal Speed Bit/s",
            "Get CAN Data Speed Bit/s",
            "Get IP Address",
            "Get LAN Service Status",
            "Reception of Status Frames",
            "Reception of RTR Frames",
            "Reception of Error Frames",
            "Interframe Transmit Delay",
            "Reception of Echo Frames"});
            this.cbbParameter.Location = new System.Drawing.Point(41, 48);
            this.cbbParameter.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.cbbParameter.Name = "cbbParameter";
            this.cbbParameter.Size = new System.Drawing.Size(186, 25);
            this.cbbParameter.TabIndex = 44;
            this.cbbParameter.SelectedIndexChanged += new System.EventHandler(this.cbbParameter_SelectedIndexChanged);
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(38, 24);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 21);
            this.label6.TabIndex = 43;
            this.label6.Text = "Parameter:";
            // 
            // rdbParamActive
            // 
            this.rdbParamActive.Checked = true;
            this.rdbParamActive.Location = new System.Drawing.Point(298, 44);
            this.rdbParamActive.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdbParamActive.Name = "rdbParamActive";
            this.rdbParamActive.Size = new System.Drawing.Size(66, 25);
            this.rdbParamActive.TabIndex = 2;
            this.rdbParamActive.TabStop = true;
            this.rdbParamActive.Text = "Active";
            this.rdbParamActive.UseVisualStyleBackColor = true;
            // 
            // rdbParamInactive
            // 
            this.rdbParamInactive.Location = new System.Drawing.Point(298, 67);
            this.rdbParamInactive.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdbParamInactive.Name = "rdbParamInactive";
            this.rdbParamInactive.Size = new System.Drawing.Size(83, 21);
            this.rdbParamInactive.TabIndex = 0;
            this.rdbParamInactive.Text = "Inactive";
            this.rdbParamInactive.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btnReset);
            this.groupBox4.Controls.Add(this.btnStatus);
            this.groupBox4.Controls.Add(this.btnGetVersions);
            this.groupBox4.Controls.Add(this.lbxInfo);
            this.groupBox4.Controls.Add(this.btnInfoClear);
            this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox4.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(10, 30);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox4.Size = new System.Drawing.Size(734, 80);
            this.groupBox4.TabIndex = 47;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Information";
            // 
            // btnReset
            // 
            this.btnReset.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReset.Enabled = false;
            this.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnReset.Location = new System.Drawing.Point(669, 46);
            this.btnReset.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(62, 30);
            this.btnReset.TabIndex = 58;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnStatus
            // 
            this.btnStatus.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStatus.Enabled = false;
            this.btnStatus.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnStatus.Location = new System.Drawing.Point(667, 13);
            this.btnStatus.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnStatus.Name = "btnStatus";
            this.btnStatus.Size = new System.Drawing.Size(65, 30);
            this.btnStatus.TabIndex = 57;
            this.btnStatus.Text = "Status";
            this.btnStatus.UseVisualStyleBackColor = true;
            this.btnStatus.Click += new System.EventHandler(this.btnStatus_Click);
            // 
            // btnGetVersions
            // 
            this.btnGetVersions.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnGetVersions.Enabled = false;
            this.btnGetVersions.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnGetVersions.Location = new System.Drawing.Point(595, 13);
            this.btnGetVersions.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnGetVersions.Name = "btnGetVersions";
            this.btnGetVersions.Size = new System.Drawing.Size(66, 30);
            this.btnGetVersions.TabIndex = 53;
            this.btnGetVersions.Text = "Versions";
            this.btnGetVersions.UseVisualStyleBackColor = true;
            this.btnGetVersions.Click += new System.EventHandler(this.btnGetVersions_Click);
            // 
            // lbxInfo
            // 
            this.lbxInfo.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxInfo.FormattingEnabled = true;
            this.lbxInfo.ItemHeight = 18;
            this.lbxInfo.Items.AddRange(new object[] {
            "1. Select a Hardware and a configuration for it. Then click \"Initialize\" button",
            "2. 모티터링이 안되거나 중단하려면 \"BMS제어\" 탭에서 Monitoring ON/OFF 버튼 사용"});
            this.lbxInfo.Location = new System.Drawing.Point(11, 16);
            this.lbxInfo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.lbxInfo.Name = "lbxInfo";
            this.lbxInfo.ScrollAlwaysVisible = true;
            this.lbxInfo.Size = new System.Drawing.Size(578, 58);
            this.lbxInfo.TabIndex = 56;
            this.lbxInfo.DoubleClick += new System.EventHandler(this.lbxInfo_DoubleClick);
            // 
            // btnInfoClear
            // 
            this.btnInfoClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInfoClear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnInfoClear.Location = new System.Drawing.Point(595, 46);
            this.btnInfoClear.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnInfoClear.Name = "btnInfoClear";
            this.btnInfoClear.Size = new System.Drawing.Size(66, 30);
            this.btnInfoClear.TabIndex = 52;
            this.btnInfoClear.Text = "Clear";
            this.btnInfoClear.UseVisualStyleBackColor = true;
            this.btnInfoClear.Click += new System.EventHandler(this.btnInfoClear_Click);
            // 
            // lblInfoMonitor
            // 
            this.lblInfoMonitor.AutoSize = true;
            this.lblInfoMonitor.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInfoMonitor.ForeColor = System.Drawing.SystemColors.Highlight;
            this.lblInfoMonitor.Location = new System.Drawing.Point(129, 15);
            this.lblInfoMonitor.Name = "lblInfoMonitor";
            this.lblInfoMonitor.Size = new System.Drawing.Size(139, 20);
            this.lblInfoMonitor.TabIndex = 59;
            this.lblInfoMonitor.Text = "데이터 송수신 중지";
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox5.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox5.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.Location = new System.Drawing.Point(25, 63);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox5.Size = new System.Drawing.Size(749, 508);
            this.groupBox5.TabIndex = 48;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = " Messages Reading ";
            // 
            // lstMessages
            // 
            this.lstMessages.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clhType,
            this.clhID,
            this.clhData,
            this.clhLength,
            this.clhCount,
            this.cihPeriod,
            this.clhRcvTime});
            this.lstMessages.Font = new System.Drawing.Font("Consolas", 8.830189F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstMessages.FullRowSelect = true;
            this.lstMessages.GridLines = true;
            this.lstMessages.HideSelection = false;
            this.lstMessages.Location = new System.Drawing.Point(17, 34);
            this.lstMessages.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.lstMessages.MultiSelect = false;
            this.lstMessages.Name = "lstMessages";
            this.lstMessages.Size = new System.Drawing.Size(659, 468);
            this.lstMessages.TabIndex = 28;
            this.lstMessages.UseCompatibleStateImageBehavior = false;
            this.lstMessages.View = System.Windows.Forms.View.Details;
            this.lstMessages.DoubleClick += new System.EventHandler(this.lstMessages_DoubleClick);
            // 
            // clhType
            // 
            this.clhType.Text = "Type";
            this.clhType.Width = 50;
            // 
            // clhID
            // 
            this.clhID.Text = "ID(hex)";
            this.clhID.Width = 70;
            // 
            // clhData
            // 
            this.clhData.Text = "Data";
            this.clhData.Width = 180;
            // 
            // clhLength
            // 
            this.clhLength.Text = "Length";
            this.clhLength.Width = 55;
            // 
            // clhCount
            // 
            this.clhCount.Text = "Count";
            this.clhCount.Width = 66;
            // 
            // cihPeriod
            // 
            this.cihPeriod.Text = "Period";
            this.cihPeriod.Width = 90;
            // 
            // clhRcvTime
            // 
            this.clhRcvTime.Text = "Rcv Time (msec)";
            this.clhRcvTime.Width = 130;
            // 
            // tmrRead
            // 
            this.tmrRead.Tick += new System.EventHandler(this.tmrRead_Tick);
            // 
            // tmrDisplay
            // 
            this.tmrDisplay.Enabled = true;
            this.tmrDisplay.Interval = 1000;
            this.tmrDisplay.Tick += new System.EventHandler(this.tmrDisplay_Tick);
            // 
            // rtbCanMsg
            // 
            this.rtbCanMsg.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbCanMsg.Location = new System.Drawing.Point(49, 75);
            this.rtbCanMsg.Name = "rtbCanMsg";
            this.rtbCanMsg.Size = new System.Drawing.Size(655, 452);
            this.rtbCanMsg.TabIndex = 160;
            this.rtbCanMsg.Text = "";
            // 
            // on_sec
            // 
            this.on_sec.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.on_sec.Location = new System.Drawing.Point(29, 440);
            this.on_sec.Name = "on_sec";
            this.on_sec.Size = new System.Drawing.Size(91, 41);
            this.on_sec.TabIndex = 161;
            this.on_sec.Text = "1초 ON";
            this.on_sec.UseVisualStyleBackColor = true;
            this.on_sec.Visible = false;
            this.on_sec.Click += new System.EventHandler(this.on_sec_Click);
            // 
            // off_1sec
            // 
            this.off_1sec.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.off_1sec.Location = new System.Drawing.Point(143, 440);
            this.off_1sec.Name = "off_1sec";
            this.off_1sec.Size = new System.Drawing.Size(92, 41);
            this.off_1sec.TabIndex = 161;
            this.off_1sec.Text = "1초 OFF";
            this.off_1sec.UseVisualStyleBackColor = true;
            this.off_1sec.Visible = false;
            this.off_1sec.Click += new System.EventHandler(this.off_1sec_Click);
            // 
            // btRtbSave
            // 
            this.btRtbSave.Location = new System.Drawing.Point(710, 16);
            this.btRtbSave.Name = "btRtbSave";
            this.btRtbSave.Size = new System.Drawing.Size(71, 69);
            this.btRtbSave.TabIndex = 162;
            this.btRtbSave.Text = "저장";
            this.btRtbSave.UseVisualStyleBackColor = true;
            this.btRtbSave.Click += new System.EventHandler(this.btRtbSave_Click);
            // 
            // btRtbInit
            // 
            this.btRtbInit.Location = new System.Drawing.Point(710, 109);
            this.btRtbInit.Name = "btRtbInit";
            this.btRtbInit.Size = new System.Drawing.Size(66, 56);
            this.btRtbInit.TabIndex = 163;
            this.btRtbInit.Text = "초기화";
            this.btRtbInit.UseVisualStyleBackColor = true;
            this.btRtbInit.Click += new System.EventHandler(this.btRtbInit_Click);
            // 
            // textBox1
            // 
            this.textBox1.Enabled = false;
            this.textBox1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(49, 43);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(655, 21);
            this.textBox1.TabIndex = 164;
            this.textBox1.Text = "Date                            Type    ID     Data                              " +
    "       Size  Count   Period     RcvTime[msec ]";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(18, 18);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.파일ToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.waccoToolStripMenuItem,
            this.도움말ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1232, 24);
            this.menuStrip1.TabIndex = 165;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // 파일ToolStripMenuItem
            // 
            this.파일ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pCAN설정ToolStripMenuItem,
            this.저장ToolStripMenuItem,
            this.toolStripSeparator1,
            this.종료ToolStripMenuItem});
            this.파일ToolStripMenuItem.Name = "파일ToolStripMenuItem";
            this.파일ToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.파일ToolStripMenuItem.Text = "파일";
            // 
            // pCAN설정ToolStripMenuItem
            // 
            this.pCAN설정ToolStripMenuItem.Name = "pCAN설정ToolStripMenuItem";
            this.pCAN설정ToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.pCAN설정ToolStripMenuItem.Text = "PCAN설정";
            this.pCAN설정ToolStripMenuItem.Click += new System.EventHandler(this.pCAN설정ToolStripMenuItem_Click);
            // 
            // 저장ToolStripMenuItem
            // 
            this.저장ToolStripMenuItem.Name = "저장ToolStripMenuItem";
            this.저장ToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.저장ToolStripMenuItem.Text = "Log 저장";
            this.저장ToolStripMenuItem.Click += new System.EventHandler(this.저장ToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(127, 6);
            // 
            // 종료ToolStripMenuItem
            // 
            this.종료ToolStripMenuItem.Name = "종료ToolStripMenuItem";
            this.종료ToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.종료ToolStripMenuItem.Text = "종료";
            this.종료ToolStripMenuItem.Click += new System.EventHandler(this.종료ToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.receiveIDToolStripMenuItem,
            this.receiveLogToolStripMenuItem,
            this.transmitToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // receiveIDToolStripMenuItem
            // 
            this.receiveIDToolStripMenuItem.Name = "receiveIDToolStripMenuItem";
            this.receiveIDToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.receiveIDToolStripMenuItem.Text = "Receive - ID ";
            this.receiveIDToolStripMenuItem.Click += new System.EventHandler(this.receiveIDToolStripMenuItem_Click);
            // 
            // receiveLogToolStripMenuItem
            // 
            this.receiveLogToolStripMenuItem.Name = "receiveLogToolStripMenuItem";
            this.receiveLogToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.receiveLogToolStripMenuItem.Text = "Receive - Log";
            this.receiveLogToolStripMenuItem.Click += new System.EventHandler(this.receiveLogToolStripMenuItem_Click);
            // 
            // transmitToolStripMenuItem
            // 
            this.transmitToolStripMenuItem.Name = "transmitToolStripMenuItem";
            this.transmitToolStripMenuItem.Size = new System.Drawing.Size(147, 22);
            this.transmitToolStripMenuItem.Text = "Transmit";
            this.transmitToolStripMenuItem.Click += new System.EventHandler(this.transmitToolStripMenuItem_Click);
            // 
            // waccoToolStripMenuItem
            // 
            this.waccoToolStripMenuItem.Name = "waccoToolStripMenuItem";
            this.waccoToolStripMenuItem.Size = new System.Drawing.Size(32, 20);
            this.waccoToolStripMenuItem.Text = "LB";
            this.waccoToolStripMenuItem.Click += new System.EventHandler(this.waccoToolStripMenuItem_Click);
            // 
            // 도움말ToolStripMenuItem
            // 
            this.도움말ToolStripMenuItem.Name = "도움말ToolStripMenuItem";
            this.도움말ToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.도움말ToolStripMenuItem.Text = "도움말";
            // 
            // tabCntProject
            // 
            this.tabCntProject.Controls.Add(this.tabPcanConfig);
            this.tabCntProject.Controls.Add(this.tabProject);
            this.tabCntProject.Controls.Add(this.tabPcanWrite);
            this.tabCntProject.Controls.Add(this.tabEvent);
            this.tabCntProject.Controls.Add(this.tabPcanRcvId);
            this.tabCntProject.Controls.Add(this.tabPcanRcvMsg);
            this.tabCntProject.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tabCntProject.ItemSize = new System.Drawing.Size(130, 40);
            this.tabCntProject.Location = new System.Drawing.Point(10, 112);
            this.tabCntProject.Name = "tabCntProject";
            this.tabCntProject.SelectedIndex = 0;
            this.tabCntProject.Size = new System.Drawing.Size(1206, 787);
            this.tabCntProject.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabCntProject.TabIndex = 166;
            // 
            // tabPcanConfig
            // 
            this.tabPcanConfig.BackColor = System.Drawing.SystemColors.Control;
            this.tabPcanConfig.Controls.Add(this.groupBox1);
            this.tabPcanConfig.Controls.Add(this.groupBox3);
            this.tabPcanConfig.Controls.Add(this.groupBox19);
            this.tabPcanConfig.Controls.Add(this.groupBox2);
            this.tabPcanConfig.Controls.Add(this.on_sec);
            this.tabPcanConfig.Controls.Add(this.off_1sec);
            this.tabPcanConfig.Location = new System.Drawing.Point(4, 44);
            this.tabPcanConfig.Name = "tabPcanConfig";
            this.tabPcanConfig.Padding = new System.Windows.Forms.Padding(3);
            this.tabPcanConfig.Size = new System.Drawing.Size(1198, 739);
            this.tabPcanConfig.TabIndex = 0;
            this.tabPcanConfig.Text = "PCAN 설정";
            // 
            // groupBox19
            // 
            this.groupBox19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox19.Controls.Add(this.chbShowPeriod);
            this.groupBox19.Controls.Add(this.btnMsgClear);
            this.groupBox19.Controls.Add(this.rdbManual);
            this.groupBox19.Controls.Add(this.btnRead);
            this.groupBox19.Controls.Add(this.rdbEvent);
            this.groupBox19.Controls.Add(this.rdbTimer);
            this.groupBox19.Enabled = false;
            this.groupBox19.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox19.Location = new System.Drawing.Point(12, 298);
            this.groupBox19.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox19.Size = new System.Drawing.Size(749, 92);
            this.groupBox19.TabIndex = 45;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Receive Type";
            // 
            // chbShowPeriod
            // 
            this.chbShowPeriod.AutoSize = true;
            this.chbShowPeriod.Checked = true;
            this.chbShowPeriod.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chbShowPeriod.Location = new System.Drawing.Point(52, 59);
            this.chbShowPeriod.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chbShowPeriod.Name = "chbShowPeriod";
            this.chbShowPeriod.Size = new System.Drawing.Size(153, 21);
            this.chbShowPeriod.TabIndex = 165;
            this.chbShowPeriod.Text = "Timestamp as period";
            this.chbShowPeriod.UseVisualStyleBackColor = true;
            this.chbShowPeriod.Visible = false;
            // 
            // btnMsgClear
            // 
            this.btnMsgClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMsgClear.Enabled = false;
            this.btnMsgClear.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnMsgClear.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnMsgClear.Location = new System.Drawing.Point(683, 32);
            this.btnMsgClear.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnMsgClear.Name = "btnMsgClear";
            this.btnMsgClear.Size = new System.Drawing.Size(58, 30);
            this.btnMsgClear.TabIndex = 163;
            this.btnMsgClear.Text = "Clear";
            this.btnMsgClear.UseVisualStyleBackColor = true;
            // 
            // rdbManual
            // 
            this.rdbManual.AutoSize = true;
            this.rdbManual.Enabled = false;
            this.rdbManual.Location = new System.Drawing.Point(408, 32);
            this.rdbManual.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdbManual.Name = "rdbManual";
            this.rdbManual.Size = new System.Drawing.Size(106, 21);
            this.rdbManual.TabIndex = 164;
            this.rdbManual.Text = "Manual Read";
            this.rdbManual.UseVisualStyleBackColor = true;
            // 
            // btnRead
            // 
            this.btnRead.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRead.Enabled = false;
            this.btnRead.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnRead.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnRead.Location = new System.Drawing.Point(609, 32);
            this.btnRead.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(58, 30);
            this.btnRead.TabIndex = 162;
            this.btnRead.Text = "Read";
            this.btnRead.UseVisualStyleBackColor = true;
            // 
            // rdbEvent
            // 
            this.rdbEvent.AutoSize = true;
            this.rdbEvent.Checked = true;
            this.rdbEvent.Location = new System.Drawing.Point(225, 32);
            this.rdbEvent.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdbEvent.Name = "rdbEvent";
            this.rdbEvent.Size = new System.Drawing.Size(170, 21);
            this.rdbEvent.TabIndex = 163;
            this.rdbEvent.TabStop = true;
            this.rdbEvent.Text = "Reading using an Event";
            this.rdbEvent.UseVisualStyleBackColor = true;
            // 
            // rdbTimer
            // 
            this.rdbTimer.AutoSize = true;
            this.rdbTimer.Enabled = false;
            this.rdbTimer.Location = new System.Drawing.Point(52, 32);
            this.rdbTimer.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.rdbTimer.Name = "rdbTimer";
            this.rdbTimer.Size = new System.Drawing.Size(144, 21);
            this.rdbTimer.TabIndex = 162;
            this.rdbTimer.Text = "Read using a Timer";
            this.rdbTimer.UseVisualStyleBackColor = true;
            // 
            // tabProject
            // 
            this.tabProject.BackColor = System.Drawing.SystemColors.Window;
            this.tabProject.Controls.Add(this.label38);
            this.tabProject.Controls.Add(this.label39);
            this.tabProject.Controls.Add(this.label37);
            this.tabProject.Controls.Add(this.txtLastEventIndex);
            this.tabProject.Controls.Add(this.txtBmsRunTime);
            this.tabProject.Controls.Add(this.groupBox13);
            this.tabProject.Controls.Add(this.groupBox18);
            this.tabProject.Controls.Add(this.lvlTestIdHex);
            this.tabProject.Controls.Add(this.groupBox12);
            this.tabProject.Controls.Add(this.groupBox9);
            this.tabProject.Controls.Add(this.groupBox10);
            this.tabProject.Controls.Add(this.groupBox11);
            this.tabProject.Controls.Add(this.groupBox8);
            this.tabProject.Controls.Add(this.groupBox7);
            this.tabProject.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabProject.ForeColor = System.Drawing.SystemColors.Desktop;
            this.tabProject.Location = new System.Drawing.Point(4, 44);
            this.tabProject.Name = "tabProject";
            this.tabProject.Padding = new System.Windows.Forms.Padding(3);
            this.tabProject.Size = new System.Drawing.Size(1198, 739);
            this.tabProject.TabIndex = 3;
            this.tabProject.Text = "엘비 - LB";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(510, 613);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(0, 19);
            this.label38.TabIndex = 12;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(906, 625);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(155, 19);
            this.label39.TabIndex = 12;
            this.label39.Text = "마지막 EVNET 저장 위치";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(917, 650);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(124, 19);
            this.label37.TabIndex = 12;
            this.label37.Text = "BMS 실행 시간 (초)";
            // 
            // txtLastEventIndex
            // 
            this.txtLastEventIndex.BackColor = System.Drawing.SystemColors.Window;
            this.txtLastEventIndex.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLastEventIndex.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastEventIndex.Location = new System.Drawing.Point(1067, 619);
            this.txtLastEventIndex.Name = "txtLastEventIndex";
            this.txtLastEventIndex.ReadOnly = true;
            this.txtLastEventIndex.Size = new System.Drawing.Size(80, 25);
            this.txtLastEventIndex.TabIndex = 7;
            this.txtLastEventIndex.Text = "IndexEvent";
            this.txtLastEventIndex.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtBmsRunTime
            // 
            this.txtBmsRunTime.BackColor = System.Drawing.SystemColors.Window;
            this.txtBmsRunTime.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBmsRunTime.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBmsRunTime.Location = new System.Drawing.Point(1067, 650);
            this.txtBmsRunTime.Name = "txtBmsRunTime";
            this.txtBmsRunTime.ReadOnly = true;
            this.txtBmsRunTime.Size = new System.Drawing.Size(80, 25);
            this.txtBmsRunTime.TabIndex = 7;
            this.txtBmsRunTime.Text = "RunTime";
            this.txtBmsRunTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.tbBmsStChgChgFet);
            this.groupBox13.Controls.Add(this.tbBmsStChgDisFet);
            this.groupBox13.Controls.Add(this.tbBmsStPfet);
            this.groupBox13.Controls.Add(this.tbBmsStCfet);
            this.groupBox13.Controls.Add(this.tbBmsIchg);
            this.groupBox13.Controls.Add(this.tbBmsDFET);
            this.groupBox13.Controls.Add(this.tbBmsStIdch);
            this.groupBox13.Controls.Add(this.tbBmsStSocDisplay);
            this.groupBox13.Controls.Add(this.tbBmsStChgKeyOn);
            this.groupBox13.Controls.Add(this.tbBmsStSwon);
            this.groupBox13.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox13.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox13.Location = new System.Drawing.Point(963, 155);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(211, 378);
            this.groupBox13.TabIndex = 10;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "BMS Status";
            // 
            // tbBmsStChgChgFet
            // 
            this.tbBmsStChgChgFet.BackColor = System.Drawing.SystemColors.Window;
            this.tbBmsStChgChgFet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbBmsStChgChgFet.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBmsStChgChgFet.Location = new System.Drawing.Point(17, 339);
            this.tbBmsStChgChgFet.Name = "tbBmsStChgChgFet";
            this.tbBmsStChgChgFet.ReadOnly = true;
            this.tbBmsStChgChgFet.Size = new System.Drawing.Size(167, 25);
            this.tbBmsStChgChgFet.TabIndex = 8;
            this.tbBmsStChgChgFet.Text = "CHGCharge_FET";
            this.tbBmsStChgChgFet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbBmsStChgDisFet
            // 
            this.tbBmsStChgDisFet.BackColor = System.Drawing.SystemColors.Window;
            this.tbBmsStChgDisFet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbBmsStChgDisFet.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBmsStChgDisFet.Location = new System.Drawing.Point(17, 304);
            this.tbBmsStChgDisFet.Name = "tbBmsStChgDisFet";
            this.tbBmsStChgDisFet.ReadOnly = true;
            this.tbBmsStChgDisFet.Size = new System.Drawing.Size(167, 25);
            this.tbBmsStChgDisFet.TabIndex = 8;
            this.tbBmsStChgDisFet.Text = "CHGDischarge_FET";
            this.tbBmsStChgDisFet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbBmsStPfet
            // 
            this.tbBmsStPfet.BackColor = System.Drawing.SystemColors.Window;
            this.tbBmsStPfet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbBmsStPfet.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBmsStPfet.Location = new System.Drawing.Point(17, 269);
            this.tbBmsStPfet.Name = "tbBmsStPfet";
            this.tbBmsStPfet.ReadOnly = true;
            this.tbBmsStPfet.Size = new System.Drawing.Size(167, 25);
            this.tbBmsStPfet.TabIndex = 7;
            this.tbBmsStPfet.Text = "PFET (PreDischarge FET)";
            this.tbBmsStPfet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbBmsStCfet
            // 
            this.tbBmsStCfet.BackColor = System.Drawing.SystemColors.Window;
            this.tbBmsStCfet.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbBmsStCfet.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBmsStCfet.Location = new System.Drawing.Point(17, 234);
            this.tbBmsStCfet.Name = "tbBmsStCfet";
            this.tbBmsStCfet.ReadOnly = true;
            this.tbBmsStCfet.Size = new System.Drawing.Size(167, 25);
            this.tbBmsStCfet.TabIndex = 6;
            this.tbBmsStCfet.Text = "CFET (Charge FET)";
            this.tbBmsStCfet.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbBmsIchg
            // 
            this.tbBmsIchg.BackColor = System.Drawing.SystemColors.Window;
            this.tbBmsIchg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbBmsIchg.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBmsIchg.Location = new System.Drawing.Point(17, 164);
            this.tbBmsIchg.Name = "tbBmsIchg";
            this.tbBmsIchg.ReadOnly = true;
            this.tbBmsIchg.Size = new System.Drawing.Size(167, 25);
            this.tbBmsIchg.TabIndex = 5;
            this.tbBmsIchg.Text = "ICHG (Charging)";
            this.tbBmsIchg.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbBmsIchg.TextChanged += new System.EventHandler(this.tbBmsIchg_TextChanged);
            // 
            // tbBmsDFET
            // 
            this.tbBmsDFET.BackColor = System.Drawing.SystemColors.Window;
            this.tbBmsDFET.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbBmsDFET.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBmsDFET.Location = new System.Drawing.Point(17, 199);
            this.tbBmsDFET.Name = "tbBmsDFET";
            this.tbBmsDFET.ReadOnly = true;
            this.tbBmsDFET.Size = new System.Drawing.Size(167, 25);
            this.tbBmsDFET.TabIndex = 5;
            this.tbBmsDFET.Text = "DFET (Discharge FET)";
            this.tbBmsDFET.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbBmsStIdch
            // 
            this.tbBmsStIdch.BackColor = System.Drawing.SystemColors.Window;
            this.tbBmsStIdch.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbBmsStIdch.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBmsStIdch.Location = new System.Drawing.Point(17, 129);
            this.tbBmsStIdch.Name = "tbBmsStIdch";
            this.tbBmsStIdch.ReadOnly = true;
            this.tbBmsStIdch.Size = new System.Drawing.Size(167, 25);
            this.tbBmsStIdch.TabIndex = 4;
            this.tbBmsStIdch.Text = "IDCH (Discharging)";
            this.tbBmsStIdch.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbBmsStSocDisplay
            // 
            this.tbBmsStSocDisplay.BackColor = System.Drawing.SystemColors.Window;
            this.tbBmsStSocDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbBmsStSocDisplay.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBmsStSocDisplay.Location = new System.Drawing.Point(17, 94);
            this.tbBmsStSocDisplay.Name = "tbBmsStSocDisplay";
            this.tbBmsStSocDisplay.ReadOnly = true;
            this.tbBmsStSocDisplay.Size = new System.Drawing.Size(167, 25);
            this.tbBmsStSocDisplay.TabIndex = 3;
            this.tbBmsStSocDisplay.Text = "SOC Display";
            this.tbBmsStSocDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbBmsStChgKeyOn
            // 
            this.tbBmsStChgKeyOn.BackColor = System.Drawing.SystemColors.Window;
            this.tbBmsStChgKeyOn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbBmsStChgKeyOn.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBmsStChgKeyOn.Location = new System.Drawing.Point(17, 59);
            this.tbBmsStChgKeyOn.Name = "tbBmsStChgKeyOn";
            this.tbBmsStChgKeyOn.ReadOnly = true;
            this.tbBmsStChgKeyOn.Size = new System.Drawing.Size(167, 25);
            this.tbBmsStChgKeyOn.TabIndex = 2;
            this.tbBmsStChgKeyOn.Text = "Charge Key ON";
            this.tbBmsStChgKeyOn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbBmsStSwon
            // 
            this.tbBmsStSwon.BackColor = System.Drawing.SystemColors.Window;
            this.tbBmsStSwon.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbBmsStSwon.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbBmsStSwon.Location = new System.Drawing.Point(17, 24);
            this.tbBmsStSwon.Name = "tbBmsStSwon";
            this.tbBmsStSwon.ReadOnly = true;
            this.tbBmsStSwon.Size = new System.Drawing.Size(167, 25);
            this.tbBmsStSwon.TabIndex = 1;
            this.tbBmsStSwon.Text = "SW ON";
            this.tbBmsStSwon.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.tbAlarmDuta);
            this.groupBox18.Controls.Add(this.tbAlarmCuta);
            this.groupBox18.Controls.Add(this.tbAlarmDota);
            this.groupBox18.Controls.Add(this.tbAlarmCota);
            this.groupBox18.Controls.Add(this.tbAlarmDoca);
            this.groupBox18.Controls.Add(this.tbAlarmCoca);
            this.groupBox18.Controls.Add(this.tbAlarmCuva);
            this.groupBox18.Controls.Add(this.tbAlarmCova);
            this.groupBox18.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox18.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox18.Location = new System.Drawing.Point(677, 377);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(272, 155);
            this.groupBox18.TabIndex = 10;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = " Alarm";
            this.groupBox18.Visible = false;
            // 
            // tbAlarmDuta
            // 
            this.tbAlarmDuta.BackColor = System.Drawing.SystemColors.Window;
            this.tbAlarmDuta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbAlarmDuta.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAlarmDuta.Location = new System.Drawing.Point(160, 119);
            this.tbAlarmDuta.Name = "tbAlarmDuta";
            this.tbAlarmDuta.ReadOnly = true;
            this.tbAlarmDuta.Size = new System.Drawing.Size(80, 25);
            this.tbAlarmDuta.TabIndex = 7;
            this.tbAlarmDuta.Text = "DUTA";
            this.tbAlarmDuta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbAlarmCuta
            // 
            this.tbAlarmCuta.BackColor = System.Drawing.SystemColors.Window;
            this.tbAlarmCuta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbAlarmCuta.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAlarmCuta.Location = new System.Drawing.Point(55, 119);
            this.tbAlarmCuta.Name = "tbAlarmCuta";
            this.tbAlarmCuta.ReadOnly = true;
            this.tbAlarmCuta.Size = new System.Drawing.Size(80, 25);
            this.tbAlarmCuta.TabIndex = 7;
            this.tbAlarmCuta.Text = "CUTA";
            this.tbAlarmCuta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbAlarmDota
            // 
            this.tbAlarmDota.BackColor = System.Drawing.SystemColors.Window;
            this.tbAlarmDota.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbAlarmDota.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAlarmDota.Location = new System.Drawing.Point(160, 85);
            this.tbAlarmDota.Name = "tbAlarmDota";
            this.tbAlarmDota.ReadOnly = true;
            this.tbAlarmDota.Size = new System.Drawing.Size(80, 25);
            this.tbAlarmDota.TabIndex = 6;
            this.tbAlarmDota.Text = "DOTA";
            this.tbAlarmDota.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbAlarmCota
            // 
            this.tbAlarmCota.BackColor = System.Drawing.SystemColors.Window;
            this.tbAlarmCota.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbAlarmCota.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAlarmCota.Location = new System.Drawing.Point(55, 85);
            this.tbAlarmCota.Name = "tbAlarmCota";
            this.tbAlarmCota.ReadOnly = true;
            this.tbAlarmCota.Size = new System.Drawing.Size(80, 25);
            this.tbAlarmCota.TabIndex = 5;
            this.tbAlarmCota.Text = "COTA";
            this.tbAlarmCota.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbAlarmDoca
            // 
            this.tbAlarmDoca.BackColor = System.Drawing.SystemColors.Window;
            this.tbAlarmDoca.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbAlarmDoca.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAlarmDoca.Location = new System.Drawing.Point(160, 53);
            this.tbAlarmDoca.Name = "tbAlarmDoca";
            this.tbAlarmDoca.ReadOnly = true;
            this.tbAlarmDoca.Size = new System.Drawing.Size(80, 25);
            this.tbAlarmDoca.TabIndex = 4;
            this.tbAlarmDoca.Text = "DOCA";
            this.tbAlarmDoca.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbAlarmCoca
            // 
            this.tbAlarmCoca.BackColor = System.Drawing.SystemColors.Window;
            this.tbAlarmCoca.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbAlarmCoca.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAlarmCoca.Location = new System.Drawing.Point(55, 53);
            this.tbAlarmCoca.Name = "tbAlarmCoca";
            this.tbAlarmCoca.ReadOnly = true;
            this.tbAlarmCoca.Size = new System.Drawing.Size(80, 25);
            this.tbAlarmCoca.TabIndex = 3;
            this.tbAlarmCoca.Text = "COCA";
            this.tbAlarmCoca.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbAlarmCoca.TextChanged += new System.EventHandler(this.textBox63_TextChanged);
            // 
            // tbAlarmCuva
            // 
            this.tbAlarmCuva.BackColor = System.Drawing.SystemColors.Window;
            this.tbAlarmCuva.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbAlarmCuva.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAlarmCuva.Location = new System.Drawing.Point(160, 19);
            this.tbAlarmCuva.Name = "tbAlarmCuva";
            this.tbAlarmCuva.ReadOnly = true;
            this.tbAlarmCuva.Size = new System.Drawing.Size(80, 25);
            this.tbAlarmCuva.TabIndex = 2;
            this.tbAlarmCuva.Text = "CUVA";
            this.tbAlarmCuva.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbAlarmCova
            // 
            this.tbAlarmCova.BackColor = System.Drawing.SystemColors.Window;
            this.tbAlarmCova.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbAlarmCova.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbAlarmCova.Location = new System.Drawing.Point(55, 20);
            this.tbAlarmCova.Name = "tbAlarmCova";
            this.tbAlarmCova.ReadOnly = true;
            this.tbAlarmCova.Size = new System.Drawing.Size(80, 25);
            this.tbAlarmCova.TabIndex = 1;
            this.tbAlarmCova.Text = "COVA";
            this.tbAlarmCova.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lvlTestIdHex
            // 
            this.lvlTestIdHex.AutoSize = true;
            this.lvlTestIdHex.ForeColor = System.Drawing.Color.Blue;
            this.lvlTestIdHex.Location = new System.Drawing.Point(161, 70);
            this.lvlTestIdHex.Name = "lvlTestIdHex";
            this.lvlTestIdHex.Size = new System.Drawing.Size(60, 19);
            this.lvlTestIdHex.TabIndex = 6;
            this.lvlTestIdHex.Text = "ID(Hex)";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.tbFaultPwdn);
            this.groupBox12.Controls.Add(this.tbFaultShtp);
            this.groupBox12.Controls.Add(this.tbFaultDutp);
            this.groupBox12.Controls.Add(this.tbFaultCutp);
            this.groupBox12.Controls.Add(this.tbFaultCotp);
            this.groupBox12.Controls.Add(this.tbFaultDotp);
            this.groupBox12.Controls.Add(this.tbFaultDocp);
            this.groupBox12.Controls.Add(this.tbFaultCocp);
            this.groupBox12.Controls.Add(this.tbFaultDuvp);
            this.groupBox12.Controls.Add(this.tbFaultCovp);
            this.groupBox12.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox12.Location = new System.Drawing.Point(677, 155);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(272, 216);
            this.groupBox12.TabIndex = 10;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Fault ";
            // 
            // tbFaultPwdn
            // 
            this.tbFaultPwdn.BackColor = System.Drawing.SystemColors.Window;
            this.tbFaultPwdn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFaultPwdn.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFaultPwdn.Location = new System.Drawing.Point(157, 148);
            this.tbFaultPwdn.Name = "tbFaultPwdn";
            this.tbFaultPwdn.ReadOnly = true;
            this.tbFaultPwdn.Size = new System.Drawing.Size(80, 25);
            this.tbFaultPwdn.TabIndex = 8;
            this.tbFaultPwdn.Text = "DPF";
            this.tbFaultPwdn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbFaultShtp
            // 
            this.tbFaultShtp.BackColor = System.Drawing.SystemColors.Window;
            this.tbFaultShtp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFaultShtp.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFaultShtp.Location = new System.Drawing.Point(55, 148);
            this.tbFaultShtp.Name = "tbFaultShtp";
            this.tbFaultShtp.ReadOnly = true;
            this.tbFaultShtp.Size = new System.Drawing.Size(80, 25);
            this.tbFaultShtp.TabIndex = 8;
            this.tbFaultShtp.Text = "CPF";
            this.tbFaultShtp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbFaultDutp
            // 
            this.tbFaultDutp.BackColor = System.Drawing.SystemColors.Window;
            this.tbFaultDutp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFaultDutp.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFaultDutp.Location = new System.Drawing.Point(157, 116);
            this.tbFaultDutp.Name = "tbFaultDutp";
            this.tbFaultDutp.ReadOnly = true;
            this.tbFaultDutp.Size = new System.Drawing.Size(80, 25);
            this.tbFaultDutp.TabIndex = 7;
            this.tbFaultDutp.Text = "DUTP";
            this.tbFaultDutp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbFaultCutp
            // 
            this.tbFaultCutp.BackColor = System.Drawing.SystemColors.Window;
            this.tbFaultCutp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFaultCutp.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFaultCutp.Location = new System.Drawing.Point(55, 116);
            this.tbFaultCutp.Name = "tbFaultCutp";
            this.tbFaultCutp.ReadOnly = true;
            this.tbFaultCutp.Size = new System.Drawing.Size(80, 25);
            this.tbFaultCutp.TabIndex = 6;
            this.tbFaultCutp.Text = "CUTP";
            this.tbFaultCutp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbFaultCotp
            // 
            this.tbFaultCotp.BackColor = System.Drawing.SystemColors.Window;
            this.tbFaultCotp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFaultCotp.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFaultCotp.Location = new System.Drawing.Point(55, 84);
            this.tbFaultCotp.Name = "tbFaultCotp";
            this.tbFaultCotp.ReadOnly = true;
            this.tbFaultCotp.Size = new System.Drawing.Size(80, 25);
            this.tbFaultCotp.TabIndex = 5;
            this.tbFaultCotp.Text = "COTP";
            this.tbFaultCotp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbFaultDotp
            // 
            this.tbFaultDotp.BackColor = System.Drawing.SystemColors.Window;
            this.tbFaultDotp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFaultDotp.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFaultDotp.Location = new System.Drawing.Point(157, 84);
            this.tbFaultDotp.Name = "tbFaultDotp";
            this.tbFaultDotp.ReadOnly = true;
            this.tbFaultDotp.Size = new System.Drawing.Size(80, 25);
            this.tbFaultDotp.TabIndex = 5;
            this.tbFaultDotp.Text = "DOTP";
            this.tbFaultDotp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbFaultDocp
            // 
            this.tbFaultDocp.BackColor = System.Drawing.SystemColors.Window;
            this.tbFaultDocp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFaultDocp.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFaultDocp.Location = new System.Drawing.Point(157, 51);
            this.tbFaultDocp.Name = "tbFaultDocp";
            this.tbFaultDocp.ReadOnly = true;
            this.tbFaultDocp.Size = new System.Drawing.Size(80, 25);
            this.tbFaultDocp.TabIndex = 4;
            this.tbFaultDocp.Text = "DOCP";
            this.tbFaultDocp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbFaultCocp
            // 
            this.tbFaultCocp.BackColor = System.Drawing.SystemColors.Window;
            this.tbFaultCocp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFaultCocp.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFaultCocp.Location = new System.Drawing.Point(55, 51);
            this.tbFaultCocp.Name = "tbFaultCocp";
            this.tbFaultCocp.ReadOnly = true;
            this.tbFaultCocp.Size = new System.Drawing.Size(80, 25);
            this.tbFaultCocp.TabIndex = 3;
            this.tbFaultCocp.Text = "COCP";
            this.tbFaultCocp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbFaultDuvp
            // 
            this.tbFaultDuvp.BackColor = System.Drawing.SystemColors.Window;
            this.tbFaultDuvp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFaultDuvp.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFaultDuvp.Location = new System.Drawing.Point(157, 18);
            this.tbFaultDuvp.Name = "tbFaultDuvp";
            this.tbFaultDuvp.ReadOnly = true;
            this.tbFaultDuvp.Size = new System.Drawing.Size(80, 25);
            this.tbFaultDuvp.TabIndex = 2;
            this.tbFaultDuvp.Text = "DUVP";
            this.tbFaultDuvp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbFaultCovp
            // 
            this.tbFaultCovp.BackColor = System.Drawing.SystemColors.Window;
            this.tbFaultCovp.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbFaultCovp.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFaultCovp.ForeColor = System.Drawing.SystemColors.WindowText;
            this.tbFaultCovp.Location = new System.Drawing.Point(55, 18);
            this.tbFaultCovp.Name = "tbFaultCovp";
            this.tbFaultCovp.ReadOnly = true;
            this.tbFaultCovp.Size = new System.Drawing.Size(80, 25);
            this.tbFaultCovp.TabIndex = 1;
            this.tbFaultCovp.Text = "COVP";
            this.tbFaultCovp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label35);
            this.groupBox9.Controls.Add(this.label34);
            this.groupBox9.Controls.Add(this.tbTempDiff);
            this.groupBox9.Controls.Add(this.label45);
            this.groupBox9.Controls.Add(this.lvlPackTemp);
            this.groupBox9.Controls.Add(this.tbTempAvg);
            this.groupBox9.Controls.Add(this.tbTempMinNo);
            this.groupBox9.Controls.Add(this.tbTempMax);
            this.groupBox9.Controls.Add(this.tbTempMaxNo);
            this.groupBox9.Controls.Add(this.label21);
            this.groupBox9.Controls.Add(this.tbTempMin);
            this.groupBox9.Controls.Add(this.label24);
            this.groupBox9.Controls.Add(this.label28);
            this.groupBox9.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox9.Location = new System.Drawing.Point(362, 155);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(303, 378);
            this.groupBox9.TabIndex = 10;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "BMS 온도";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(208, 323);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(83, 15);
            this.label35.TabIndex = 11;
            this.label35.Text = "출력 데이터 확인";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(208, 245);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(83, 15);
            this.label34.TabIndex = 11;
            this.label34.Text = "출력 데이터 확인";
            // 
            // tbTempDiff
            // 
            this.tbTempDiff.BackColor = System.Drawing.SystemColors.Window;
            this.tbTempDiff.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTempDiff.Location = new System.Drawing.Point(197, 294);
            this.tbTempDiff.Name = "tbTempDiff";
            this.tbTempDiff.ReadOnly = true;
            this.tbTempDiff.Size = new System.Drawing.Size(80, 26);
            this.tbTempDiff.TabIndex = 31;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(193, 274);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(57, 17);
            this.label45.TabIndex = 30;
            this.label45.Text = "Diff(℃)";
            // 
            // lvlPackTemp
            // 
            this.lvlPackTemp.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Type,
            this.Temp});
            this.lvlPackTemp.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlPackTemp.FullRowSelect = true;
            this.lvlPackTemp.GridLines = true;
            this.lvlPackTemp.HideSelection = false;
            this.lvlPackTemp.Location = new System.Drawing.Point(7, 24);
            this.lvlPackTemp.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.lvlPackTemp.MultiSelect = false;
            this.lvlPackTemp.Name = "lvlPackTemp";
            this.lvlPackTemp.Size = new System.Drawing.Size(174, 290);
            this.lvlPackTemp.TabIndex = 29;
            this.lvlPackTemp.UseCompatibleStateImageBehavior = false;
            this.lvlPackTemp.View = System.Windows.Forms.View.Details;
            // 
            // Type
            // 
            this.Type.Text = "위치";
            this.Type.Width = 80;
            // 
            // Temp
            // 
            this.Temp.Text = "온도(℃)";
            this.Temp.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Temp.Width = 80;
            // 
            // tbTempAvg
            // 
            this.tbTempAvg.BackColor = System.Drawing.SystemColors.Window;
            this.tbTempAvg.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTempAvg.Location = new System.Drawing.Point(193, 218);
            this.tbTempAvg.Name = "tbTempAvg";
            this.tbTempAvg.ReadOnly = true;
            this.tbTempAvg.Size = new System.Drawing.Size(80, 26);
            this.tbTempAvg.TabIndex = 1;
            // 
            // tbTempMinNo
            // 
            this.tbTempMinNo.BackColor = System.Drawing.SystemColors.Window;
            this.tbTempMinNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTempMinNo.Location = new System.Drawing.Point(196, 163);
            this.tbTempMinNo.Name = "tbTempMinNo";
            this.tbTempMinNo.ReadOnly = true;
            this.tbTempMinNo.Size = new System.Drawing.Size(27, 25);
            this.tbTempMinNo.TabIndex = 1;
            this.tbTempMinNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbTempMax
            // 
            this.tbTempMax.BackColor = System.Drawing.SystemColors.Window;
            this.tbTempMax.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTempMax.Location = new System.Drawing.Point(194, 37);
            this.tbTempMax.Name = "tbTempMax";
            this.tbTempMax.ReadOnly = true;
            this.tbTempMax.Size = new System.Drawing.Size(80, 26);
            this.tbTempMax.TabIndex = 1;
            // 
            // tbTempMaxNo
            // 
            this.tbTempMaxNo.BackColor = System.Drawing.SystemColors.Window;
            this.tbTempMaxNo.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTempMaxNo.Location = new System.Drawing.Point(197, 66);
            this.tbTempMaxNo.Name = "tbTempMaxNo";
            this.tbTempMaxNo.ReadOnly = true;
            this.tbTempMaxNo.Size = new System.Drawing.Size(27, 25);
            this.tbTempMaxNo.TabIndex = 1;
            this.tbTempMaxNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(193, 111);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(62, 17);
            this.label21.TabIndex = 0;
            this.label21.Text = "MIN(℃)";
            // 
            // tbTempMin
            // 
            this.tbTempMin.BackColor = System.Drawing.SystemColors.Window;
            this.tbTempMin.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbTempMin.Location = new System.Drawing.Point(193, 131);
            this.tbTempMin.Name = "tbTempMin";
            this.tbTempMin.ReadOnly = true;
            this.tbTempMin.Size = new System.Drawing.Size(80, 26);
            this.tbTempMin.TabIndex = 1;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(192, 18);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(71, 17);
            this.label24.TabIndex = 0;
            this.label24.Text = "MAX (℃)";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(192, 197);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(63, 17);
            this.label28.TabIndex = 0;
            this.label28.Text = "AVG(℃)";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.lvｗCellVoltage);
            this.groupBox10.Controls.Add(this.tbCellVoltMin);
            this.groupBox10.Controls.Add(this.tbCellNoMin);
            this.groupBox10.Controls.Add(this.tbCellNoMax);
            this.groupBox10.Controls.Add(this.tbCellVoltMax);
            this.groupBox10.Controls.Add(this.label30);
            this.groupBox10.Controls.Add(this.label25);
            this.groupBox10.Controls.Add(this.tbCellVoltDiff);
            this.groupBox10.Controls.Add(this.tbCellVoltAvg);
            this.groupBox10.Controls.Add(this.label31);
            this.groupBox10.Controls.Add(this.label32);
            this.groupBox10.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox10.Location = new System.Drawing.Point(6, 155);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(343, 520);
            this.groupBox10.TabIndex = 10;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Cell 전압 (20S9P)";
            // 
            // lvｗCellVoltage
            // 
            this.lvｗCellVoltage.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.CellNo,
            this.Volt,
            this.Balacing});
            this.lvｗCellVoltage.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvｗCellVoltage.FullRowSelect = true;
            this.lvｗCellVoltage.GridLines = true;
            this.lvｗCellVoltage.HideSelection = false;
            this.lvｗCellVoltage.Location = new System.Drawing.Point(11, 24);
            this.lvｗCellVoltage.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.lvｗCellVoltage.MultiSelect = false;
            this.lvｗCellVoltage.Name = "lvｗCellVoltage";
            this.lvｗCellVoltage.Size = new System.Drawing.Size(228, 484);
            this.lvｗCellVoltage.TabIndex = 29;
            this.lvｗCellVoltage.UseCompatibleStateImageBehavior = false;
            this.lvｗCellVoltage.View = System.Windows.Forms.View.Details;
            // 
            // CellNo
            // 
            this.CellNo.Text = "Cell";
            this.CellNo.Width = 65;
            // 
            // Volt
            // 
            this.Volt.Text = "Volt(mV)";
            this.Volt.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Volt.Width = 80;
            // 
            // Balacing
            // 
            this.Balacing.Text = "셀밸런싱";
            this.Balacing.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbCellVoltMin
            // 
            this.tbCellVoltMin.BackColor = System.Drawing.SystemColors.Window;
            this.tbCellVoltMin.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCellVoltMin.Location = new System.Drawing.Point(252, 152);
            this.tbCellVoltMin.Name = "tbCellVoltMin";
            this.tbCellVoltMin.ReadOnly = true;
            this.tbCellVoltMin.Size = new System.Drawing.Size(78, 29);
            this.tbCellVoltMin.TabIndex = 1;
            // 
            // tbCellNoMin
            // 
            this.tbCellNoMin.AcceptsReturn = true;
            this.tbCellNoMin.BackColor = System.Drawing.SystemColors.Window;
            this.tbCellNoMin.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCellNoMin.Location = new System.Drawing.Point(253, 187);
            this.tbCellNoMin.Name = "tbCellNoMin";
            this.tbCellNoMin.ReadOnly = true;
            this.tbCellNoMin.Size = new System.Drawing.Size(27, 29);
            this.tbCellNoMin.TabIndex = 1;
            this.tbCellNoMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbCellNoMax
            // 
            this.tbCellNoMax.BackColor = System.Drawing.SystemColors.Window;
            this.tbCellNoMax.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCellNoMax.Location = new System.Drawing.Point(253, 78);
            this.tbCellNoMax.Name = "tbCellNoMax";
            this.tbCellNoMax.ReadOnly = true;
            this.tbCellNoMax.Size = new System.Drawing.Size(27, 29);
            this.tbCellNoMax.TabIndex = 1;
            this.tbCellNoMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbCellVoltMax
            // 
            this.tbCellVoltMax.BackColor = System.Drawing.SystemColors.Window;
            this.tbCellVoltMax.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCellVoltMax.Location = new System.Drawing.Point(253, 41);
            this.tbCellVoltMax.Name = "tbCellVoltMax";
            this.tbCellVoltMax.ReadOnly = true;
            this.tbCellVoltMax.Size = new System.Drawing.Size(78, 32);
            this.tbCellVoltMax.TabIndex = 1;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(249, 342);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(63, 19);
            this.label30.TabIndex = 0;
            this.label30.Text = "Diff(mV)";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(249, 130);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(72, 19);
            this.label25.TabIndex = 0;
            this.label25.Text = "MIN(mV)";
            // 
            // tbCellVoltDiff
            // 
            this.tbCellVoltDiff.BackColor = System.Drawing.SystemColors.Window;
            this.tbCellVoltDiff.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCellVoltDiff.Location = new System.Drawing.Point(252, 363);
            this.tbCellVoltDiff.Name = "tbCellVoltDiff";
            this.tbCellVoltDiff.ReadOnly = true;
            this.tbCellVoltDiff.Size = new System.Drawing.Size(78, 29);
            this.tbCellVoltDiff.TabIndex = 1;
            // 
            // tbCellVoltAvg
            // 
            this.tbCellVoltAvg.BackColor = System.Drawing.SystemColors.Window;
            this.tbCellVoltAvg.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCellVoltAvg.Location = new System.Drawing.Point(252, 274);
            this.tbCellVoltAvg.Name = "tbCellVoltAvg";
            this.tbCellVoltAvg.ReadOnly = true;
            this.tbCellVoltAvg.Size = new System.Drawing.Size(79, 29);
            this.tbCellVoltAvg.TabIndex = 1;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(249, 22);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(81, 19);
            this.label31.TabIndex = 0;
            this.label31.Text = "MAX (mV)";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(249, 255);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(72, 19);
            this.label32.TabIndex = 0;
            this.label32.Text = "AVG(mV)";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.tbIdH);
            this.groupBox11.Controls.Add(this.tbH7);
            this.groupBox11.Controls.Add(this.btnSendTestMsg);
            this.groupBox11.Controls.Add(this.tbRC);
            this.groupBox11.Controls.Add(this.tbH6);
            this.groupBox11.Controls.Add(this.tbFCC);
            this.groupBox11.Controls.Add(this.tbCycleCount);
            this.groupBox11.Controls.Add(this.tbH5);
            this.groupBox11.Controls.Add(this.tbSOP);
            this.groupBox11.Controls.Add(this.tbSOC);
            this.groupBox11.Controls.Add(this.tbH4);
            this.groupBox11.Controls.Add(this.label16);
            this.groupBox11.Controls.Add(this.label27);
            this.groupBox11.Controls.Add(this.tbH3);
            this.groupBox11.Controls.Add(this.label26);
            this.groupBox11.Controls.Add(this.label4);
            this.groupBox11.Controls.Add(this.tbH2);
            this.groupBox11.Controls.Add(this.tbPackVoltOut);
            this.groupBox11.Controls.Add(this.tbSOH);
            this.groupBox11.Controls.Add(this.tbH1);
            this.groupBox11.Controls.Add(this.label15);
            this.groupBox11.Controls.Add(this.label18);
            this.groupBox11.Controls.Add(this.label23);
            this.groupBox11.Controls.Add(this.tbH0);
            this.groupBox11.Controls.Add(this.tbPackVoltIn);
            this.groupBox11.Controls.Add(this.label20);
            this.groupBox11.Controls.Add(this.label22);
            this.groupBox11.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox11.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox11.Location = new System.Drawing.Point(6, 73);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(1168, 78);
            this.groupBox11.TabIndex = 10;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Battery 정보";
            // 
            // tbIdH
            // 
            this.tbIdH.ForeColor = System.Drawing.Color.Blue;
            this.tbIdH.Location = new System.Drawing.Point(215, -3);
            this.tbIdH.Name = "tbIdH";
            this.tbIdH.Size = new System.Drawing.Size(44, 22);
            this.tbIdH.TabIndex = 5;
            this.tbIdH.Text = "104";
            this.tbIdH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbH7
            // 
            this.tbH7.ForeColor = System.Drawing.Color.Blue;
            this.tbH7.Location = new System.Drawing.Point(578, 0);
            this.tbH7.Name = "tbH7";
            this.tbH7.Size = new System.Drawing.Size(29, 22);
            this.tbH7.TabIndex = 5;
            this.tbH7.Text = "0";
            this.tbH7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnSendTestMsg
            // 
            this.btnSendTestMsg.Font = new System.Drawing.Font("휴먼옛체", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnSendTestMsg.ForeColor = System.Drawing.Color.Blue;
            this.btnSendTestMsg.Location = new System.Drawing.Point(266, -3);
            this.btnSendTestMsg.Name = "btnSendTestMsg";
            this.btnSendTestMsg.Size = new System.Drawing.Size(70, 25);
            this.btnSendTestMsg.TabIndex = 3;
            this.btnSendTestMsg.Text = "SEND";
            this.btnSendTestMsg.UseVisualStyleBackColor = true;
            // 
            // tbRC
            // 
            this.tbRC.BackColor = System.Drawing.SystemColors.Window;
            this.tbRC.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbRC.Location = new System.Drawing.Point(879, 41);
            this.tbRC.Name = "tbRC";
            this.tbRC.ReadOnly = true;
            this.tbRC.Size = new System.Drawing.Size(100, 26);
            this.tbRC.TabIndex = 1;
            this.tbRC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbH6
            // 
            this.tbH6.ForeColor = System.Drawing.Color.Blue;
            this.tbH6.Location = new System.Drawing.Point(543, 0);
            this.tbH6.Name = "tbH6";
            this.tbH6.Size = new System.Drawing.Size(29, 22);
            this.tbH6.TabIndex = 5;
            this.tbH6.Text = "0";
            this.tbH6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbFCC
            // 
            this.tbFCC.BackColor = System.Drawing.SystemColors.Window;
            this.tbFCC.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbFCC.Location = new System.Drawing.Point(1027, 41);
            this.tbFCC.Name = "tbFCC";
            this.tbFCC.ReadOnly = true;
            this.tbFCC.Size = new System.Drawing.Size(100, 26);
            this.tbFCC.TabIndex = 1;
            this.tbFCC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbCycleCount
            // 
            this.tbCycleCount.BackColor = System.Drawing.SystemColors.Window;
            this.tbCycleCount.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbCycleCount.Location = new System.Drawing.Point(745, 41);
            this.tbCycleCount.Name = "tbCycleCount";
            this.tbCycleCount.ReadOnly = true;
            this.tbCycleCount.Size = new System.Drawing.Size(100, 26);
            this.tbCycleCount.TabIndex = 1;
            this.tbCycleCount.Text = "0";
            this.tbCycleCount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbH5
            // 
            this.tbH5.ForeColor = System.Drawing.Color.Blue;
            this.tbH5.Location = new System.Drawing.Point(508, -3);
            this.tbH5.Name = "tbH5";
            this.tbH5.Size = new System.Drawing.Size(29, 22);
            this.tbH5.TabIndex = 5;
            this.tbH5.Text = "0";
            this.tbH5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbSOP
            // 
            this.tbSOP.BackColor = System.Drawing.SystemColors.Window;
            this.tbSOP.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSOP.Location = new System.Drawing.Point(614, 41);
            this.tbSOP.Name = "tbSOP";
            this.tbSOP.ReadOnly = true;
            this.tbSOP.Size = new System.Drawing.Size(100, 26);
            this.tbSOP.TabIndex = 1;
            this.tbSOP.Text = "0.0";
            this.tbSOP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbSOC
            // 
            this.tbSOC.BackColor = System.Drawing.SystemColors.Window;
            this.tbSOC.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSOC.Location = new System.Drawing.Point(346, 42);
            this.tbSOC.Name = "tbSOC";
            this.tbSOC.ReadOnly = true;
            this.tbSOC.Size = new System.Drawing.Size(100, 26);
            this.tbSOC.TabIndex = 1;
            this.tbSOC.Text = "0.0";
            this.tbSOC.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbH4
            // 
            this.tbH4.ForeColor = System.Drawing.Color.Blue;
            this.tbH4.Location = new System.Drawing.Point(473, -3);
            this.tbH4.Name = "tbH4";
            this.tbH4.Size = new System.Drawing.Size(29, 22);
            this.tbH4.TabIndex = 5;
            this.tbH4.Text = "0";
            this.tbH4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(622, 20);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(83, 19);
            this.label16.TabIndex = 0;
            this.label16.Text = "SOP (0.1A)";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(898, 19);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(69, 19);
            this.label27.TabIndex = 2;
            this.label27.Text = "Cap(용량)";
            // 
            // tbH3
            // 
            this.tbH3.ForeColor = System.Drawing.Color.Blue;
            this.tbH3.Location = new System.Drawing.Point(438, -3);
            this.tbH3.Name = "tbH3";
            this.tbH3.Size = new System.Drawing.Size(29, 22);
            this.tbH3.TabIndex = 5;
            this.tbH3.Text = "0";
            this.tbH3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(1015, 20);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(126, 19);
            this.label26.TabIndex = 2;
            this.label26.Text = "FCC (완전충전용량)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(746, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 19);
            this.label4.TabIndex = 2;
            this.label4.Text = "Cycle Count";
            // 
            // tbH2
            // 
            this.tbH2.ForeColor = System.Drawing.Color.Blue;
            this.tbH2.Location = new System.Drawing.Point(403, -3);
            this.tbH2.Name = "tbH2";
            this.tbH2.Size = new System.Drawing.Size(29, 22);
            this.tbH2.TabIndex = 5;
            this.tbH2.Text = "0";
            this.tbH2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbPackVoltOut
            // 
            this.tbPackVoltOut.BackColor = System.Drawing.SystemColors.Window;
            this.tbPackVoltOut.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPackVoltOut.Location = new System.Drawing.Point(228, 45);
            this.tbPackVoltOut.Name = "tbPackVoltOut";
            this.tbPackVoltOut.ReadOnly = true;
            this.tbPackVoltOut.Size = new System.Drawing.Size(100, 26);
            this.tbPackVoltOut.TabIndex = 1;
            // 
            // tbSOH
            // 
            this.tbSOH.BackColor = System.Drawing.SystemColors.Window;
            this.tbSOH.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbSOH.Location = new System.Drawing.Point(477, 42);
            this.tbSOH.Name = "tbSOH";
            this.tbSOH.ReadOnly = true;
            this.tbSOH.Size = new System.Drawing.Size(100, 26);
            this.tbSOH.TabIndex = 1;
            this.tbSOH.Text = "0";
            this.tbSOH.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.tbSOH.TextChanged += new System.EventHandler(this.tbSOH_TextChanged);
            // 
            // tbH1
            // 
            this.tbH1.ForeColor = System.Drawing.Color.Blue;
            this.tbH1.Location = new System.Drawing.Point(368, -3);
            this.tbH1.Name = "tbH1";
            this.tbH1.Size = new System.Drawing.Size(29, 22);
            this.tbH1.TabIndex = 5;
            this.tbH1.Text = "0";
            this.tbH1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(363, 20);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(68, 19);
            this.label15.TabIndex = 0;
            this.label15.Text = "SOC (%)";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(493, 20);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(68, 19);
            this.label18.TabIndex = 0;
            this.label18.Text = "SOH (%)";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(172, 54);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(42, 19);
            this.label23.TabIndex = 0;
            this.label23.Text = "(Out)";
            // 
            // tbH0
            // 
            this.tbH0.ForeColor = System.Drawing.Color.Blue;
            this.tbH0.Location = new System.Drawing.Point(343, -6);
            this.tbH0.Name = "tbH0";
            this.tbH0.Size = new System.Drawing.Size(29, 22);
            this.tbH0.TabIndex = 5;
            this.tbH0.Text = "0";
            this.tbH0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbPackVoltIn
            // 
            this.tbPackVoltIn.BackColor = System.Drawing.SystemColors.Window;
            this.tbPackVoltIn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbPackVoltIn.Location = new System.Drawing.Point(228, 15);
            this.tbPackVoltIn.Name = "tbPackVoltIn";
            this.tbPackVoltIn.ReadOnly = true;
            this.tbPackVoltIn.Size = new System.Drawing.Size(100, 26);
            this.tbPackVoltIn.TabIndex = 1;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(172, 20);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(31, 19);
            this.label20.TabIndex = 0;
            this.label20.Text = "(In)";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(114, 15);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(58, 57);
            this.label22.TabIndex = 0;
            this.label22.Text = " Pack \r\nVoltage\r\n(0.01V)";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.lblBmsRcvStateProject);
            this.groupBox8.Controls.Add(this.lvlVoltage);
            this.groupBox8.Controls.Add(this.label17);
            this.groupBox8.Controls.Add(this.tbStateIdle);
            this.groupBox8.Controls.Add(this.tbStateFault);
            this.groupBox8.Controls.Add(this.tbStateGood);
            this.groupBox8.Controls.Add(this.tbStateDisChg);
            this.groupBox8.Controls.Add(this.tbStateChg);
            this.groupBox8.Controls.Add(this.lvlCurrent);
            this.groupBox8.Controls.Add(this.label19);
            this.groupBox8.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox8.Location = new System.Drawing.Point(6, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(1168, 66);
            this.groupBox8.TabIndex = 10;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "BMS 정보";
            // 
            // lblBmsRcvStateProject
            // 
            this.lblBmsRcvStateProject.AutoSize = true;
            this.lblBmsRcvStateProject.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBmsRcvStateProject.ForeColor = System.Drawing.Color.Red;
            this.lblBmsRcvStateProject.Location = new System.Drawing.Point(531, 15);
            this.lblBmsRcvStateProject.Name = "lblBmsRcvStateProject";
            this.lblBmsRcvStateProject.Size = new System.Drawing.Size(128, 40);
            this.lblBmsRcvStateProject.TabIndex = 9;
            this.lblBmsRcvStateProject.Text = "BMS 데이터를\r\n읽을 수 없습니다.";
            // 
            // lvlVoltage
            // 
            this.lvlVoltage.AutoSize = true;
            this.lvlVoltage.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlVoltage.ForeColor = System.Drawing.Color.DarkRed;
            this.lvlVoltage.Location = new System.Drawing.Point(188, 21);
            this.lvlVoltage.Name = "lvlVoltage";
            this.lvlVoltage.Size = new System.Drawing.Size(92, 33);
            this.lvlVoltage.TabIndex = 5;
            this.lvlVoltage.Text = "158.99";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(80, 20);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(102, 33);
            this.label17.TabIndex = 5;
            this.label17.Text = "전압(V)";
            // 
            // tbStateIdle
            // 
            this.tbStateIdle.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tbStateIdle.Font = new System.Drawing.Font("휴먼옛체", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tbStateIdle.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.tbStateIdle.Location = new System.Drawing.Point(688, 23);
            this.tbStateIdle.Name = "tbStateIdle";
            this.tbStateIdle.ReadOnly = true;
            this.tbStateIdle.Size = new System.Drawing.Size(80, 32);
            this.tbStateIdle.TabIndex = 8;
            this.tbStateIdle.Text = "IDLE";
            this.tbStateIdle.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbStateFault
            // 
            this.tbStateFault.BackColor = System.Drawing.Color.Yellow;
            this.tbStateFault.Font = new System.Drawing.Font("휴먼옛체", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tbStateFault.ForeColor = System.Drawing.Color.Red;
            this.tbStateFault.Location = new System.Drawing.Point(1073, 23);
            this.tbStateFault.Name = "tbStateFault";
            this.tbStateFault.ReadOnly = true;
            this.tbStateFault.Size = new System.Drawing.Size(80, 32);
            this.tbStateFault.TabIndex = 8;
            this.tbStateFault.Text = "FAULT";
            this.tbStateFault.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbStateGood
            // 
            this.tbStateGood.BackColor = System.Drawing.Color.Lime;
            this.tbStateGood.Font = new System.Drawing.Font("휴먼옛체", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tbStateGood.ForeColor = System.Drawing.Color.Blue;
            this.tbStateGood.Location = new System.Drawing.Point(986, 21);
            this.tbStateGood.Name = "tbStateGood";
            this.tbStateGood.ReadOnly = true;
            this.tbStateGood.Size = new System.Drawing.Size(80, 32);
            this.tbStateGood.TabIndex = 8;
            this.tbStateGood.Text = "정상";
            this.tbStateGood.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbStateDisChg
            // 
            this.tbStateDisChg.BackColor = System.Drawing.Color.Red;
            this.tbStateDisChg.Font = new System.Drawing.Font("휴먼옛체", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tbStateDisChg.ForeColor = System.Drawing.Color.GreenYellow;
            this.tbStateDisChg.Location = new System.Drawing.Point(887, 21);
            this.tbStateDisChg.Name = "tbStateDisChg";
            this.tbStateDisChg.ReadOnly = true;
            this.tbStateDisChg.Size = new System.Drawing.Size(80, 32);
            this.tbStateDisChg.TabIndex = 8;
            this.tbStateDisChg.Text = "방전";
            this.tbStateDisChg.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tbStateChg
            // 
            this.tbStateChg.BackColor = System.Drawing.Color.GreenYellow;
            this.tbStateChg.Font = new System.Drawing.Font("휴먼옛체", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tbStateChg.ForeColor = System.Drawing.Color.Red;
            this.tbStateChg.Location = new System.Drawing.Point(789, 23);
            this.tbStateChg.Name = "tbStateChg";
            this.tbStateChg.ReadOnly = true;
            this.tbStateChg.Size = new System.Drawing.Size(80, 32);
            this.tbStateChg.TabIndex = 8;
            this.tbStateChg.Text = "충전";
            this.tbStateChg.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lvlCurrent
            // 
            this.lvlCurrent.AutoSize = true;
            this.lvlCurrent.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvlCurrent.ForeColor = System.Drawing.Color.DarkRed;
            this.lvlCurrent.Location = new System.Drawing.Point(397, 18);
            this.lvlCurrent.Name = "lvlCurrent";
            this.lvlCurrent.Size = new System.Drawing.Size(101, 33);
            this.lvlCurrent.TabIndex = 3;
            this.lvlCurrent.Text = "-150.00";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(296, 19);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(101, 33);
            this.label19.TabIndex = 3;
            this.label19.Text = "전류(A)";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.lblDateTime);
            this.groupBox7.Controls.Add(this.tbVersion);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.label11);
            this.groupBox7.Controls.Add(this.tbManufacture);
            this.groupBox7.Controls.Add(this.tbSerialNo);
            this.groupBox7.Controls.Add(this.label9);
            this.groupBox7.Controls.Add(this.label2);
            this.groupBox7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox7.ForeColor = System.Drawing.SystemColors.Desktop;
            this.groupBox7.Location = new System.Drawing.Point(6, 676);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(1168, 55);
            this.groupBox7.TabIndex = 10;
            this.groupBox7.TabStop = false;
            // 
            // lblDateTime
            // 
            this.lblDateTime.AutoSize = true;
            this.lblDateTime.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateTime.Location = new System.Drawing.Point(988, 22);
            this.lblDateTime.Name = "lblDateTime";
            this.lblDateTime.Size = new System.Drawing.Size(47, 22);
            this.lblDateTime.TabIndex = 10;
            this.lblDateTime.Text = "시간 ";
            // 
            // tbVersion
            // 
            this.tbVersion.Location = new System.Drawing.Point(236, 20);
            this.tbVersion.Name = "tbVersion";
            this.tbVersion.Size = new System.Drawing.Size(100, 26);
            this.tbVersion.TabIndex = 9;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(6, 23);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(164, 21);
            this.label14.TabIndex = 5;
            this.label14.Text = "Battery Information :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(174, 24);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 19);
            this.label11.TabIndex = 5;
            this.label11.Text = "Version";
            // 
            // tbManufacture
            // 
            this.tbManufacture.Location = new System.Drawing.Point(688, 20);
            this.tbManufacture.Name = "tbManufacture";
            this.tbManufacture.Size = new System.Drawing.Size(108, 26);
            this.tbManufacture.TabIndex = 8;
            // 
            // tbSerialNo
            // 
            this.tbSerialNo.Location = new System.Drawing.Point(452, 20);
            this.tbSerialNo.Name = "tbSerialNo";
            this.tbSerialNo.Size = new System.Drawing.Size(107, 26);
            this.tbSerialNo.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(597, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(85, 19);
            this.label9.TabIndex = 4;
            this.label9.Text = "Manufacture";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(379, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "Serial No";
            // 
            // tabPcanWrite
            // 
            this.tabPcanWrite.Controls.Add(this.btnClearPF);
            this.tabPcanWrite.Controls.Add(this.groupBox25);
            this.tabPcanWrite.Controls.Add(this.label60);
            this.tabPcanWrite.Controls.Add(this.label59);
            this.tabPcanWrite.Controls.Add(this.lbxBmsSetLog);
            this.tabPcanWrite.Controls.Add(this.btnSaveDefaultToBMS);
            this.tabPcanWrite.Controls.Add(this.btnSaveToBMS);
            this.tabPcanWrite.Controls.Add(this.btnReadFromBMS);
            this.tabPcanWrite.Controls.Add(this.groupBox22);
            this.tabPcanWrite.Controls.Add(this.groupBox23);
            this.tabPcanWrite.Controls.Add(this.groupBox21);
            this.tabPcanWrite.Controls.Add(this.groupBox24);
            this.tabPcanWrite.Controls.Add(this.groupBox20);
            this.tabPcanWrite.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPcanWrite.Location = new System.Drawing.Point(4, 44);
            this.tabPcanWrite.Margin = new System.Windows.Forms.Padding(5);
            this.tabPcanWrite.Name = "tabPcanWrite";
            this.tabPcanWrite.Padding = new System.Windows.Forms.Padding(3);
            this.tabPcanWrite.Size = new System.Drawing.Size(1198, 739);
            this.tabPcanWrite.TabIndex = 4;
            this.tabPcanWrite.Text = "BMS 제어";
            this.tabPcanWrite.UseVisualStyleBackColor = true;
            // 
            // btnClearPF
            // 
            this.btnClearPF.Enabled = false;
            this.btnClearPF.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearPF.Location = new System.Drawing.Point(665, 559);
            this.btnClearPF.Name = "btnClearPF";
            this.btnClearPF.Size = new System.Drawing.Size(92, 47);
            this.btnClearPF.TabIndex = 57;
            this.btnClearPF.Text = "PF Clear";
            this.btnClearPF.UseVisualStyleBackColor = true;
            this.btnClearPF.Click += new System.EventHandler(this.btnClearPF_Click);
            // 
            // groupBox25
            // 
            this.groupBox25.Controls.Add(this.lblInfoMonitor);
            this.groupBox25.Controls.Add(this.btnMonitorON);
            this.groupBox25.Controls.Add(this.btnMonitorOFF);
            this.groupBox25.Location = new System.Drawing.Point(419, 22);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(330, 98);
            this.groupBox25.TabIndex = 59;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "모니터링 제어";
            // 
            // btnMonitorON
            // 
            this.btnMonitorON.Font = new System.Drawing.Font("휴먼옛체", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnMonitorON.Location = new System.Drawing.Point(109, 42);
            this.btnMonitorON.Name = "btnMonitorON";
            this.btnMonitorON.Size = new System.Drawing.Size(84, 49);
            this.btnMonitorON.TabIndex = 58;
            this.btnMonitorON.Text = "데이터\r\n수신하기";
            this.btnMonitorON.UseVisualStyleBackColor = true;
            this.btnMonitorON.Click += new System.EventHandler(this.btnMonitorON_Click);
            // 
            // btnMonitorOFF
            // 
            this.btnMonitorOFF.Enabled = false;
            this.btnMonitorOFF.Font = new System.Drawing.Font("휴먼옛체", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnMonitorOFF.Location = new System.Drawing.Point(213, 38);
            this.btnMonitorOFF.Name = "btnMonitorOFF";
            this.btnMonitorOFF.Size = new System.Drawing.Size(90, 51);
            this.btnMonitorOFF.TabIndex = 58;
            this.btnMonitorOFF.Text = "데이터\r\n수신 중지";
            this.btnMonitorOFF.UseVisualStyleBackColor = true;
            this.btnMonitorOFF.Click += new System.EventHandler(this.btnMonitorOFF_Click);
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label60.Location = new System.Drawing.Point(414, 632);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(339, 64);
            this.label60.TabIndex = 57;
            this.label60.Text = "[사용 방법]\r\n   . BMS에서 읽기 : BMS에 저장된 보호기능 값을 읽어서 표시.\r\n  . BMS로 저장    : 항목 우측의 설정 박스의" +
    " 값을 BMS 로 전송.\r\n  . 기본값으로 설정 : BMS의 보호 기능 설정값을 기본 값으로 설정함.";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label59.Location = new System.Drawing.Point(124, 507);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(149, 22);
            this.label59.TabIndex = 56;
            this.label59.Text = "BMS 설정 로그 표시";
            this.label59.Visible = false;
            // 
            // lbxBmsSetLog
            // 
            this.lbxBmsSetLog.FormattingEnabled = true;
            this.lbxBmsSetLog.ItemHeight = 22;
            this.lbxBmsSetLog.Location = new System.Drawing.Point(60, 450);
            this.lbxBmsSetLog.Name = "lbxBmsSetLog";
            this.lbxBmsSetLog.Size = new System.Drawing.Size(330, 246);
            this.lbxBmsSetLog.TabIndex = 55;
            // 
            // btnSaveDefaultToBMS
            // 
            this.btnSaveDefaultToBMS.Enabled = false;
            this.btnSaveDefaultToBMS.Font = new System.Drawing.Font("휴먼옛체", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnSaveDefaultToBMS.Location = new System.Drawing.Point(663, 461);
            this.btnSaveDefaultToBMS.Name = "btnSaveDefaultToBMS";
            this.btnSaveDefaultToBMS.Size = new System.Drawing.Size(90, 59);
            this.btnSaveDefaultToBMS.TabIndex = 54;
            this.btnSaveDefaultToBMS.Text = "기본값으로\r\n  설정";
            this.btnSaveDefaultToBMS.UseVisualStyleBackColor = true;
            this.btnSaveDefaultToBMS.Click += new System.EventHandler(this.btnSaveDefaultToBMS_Click);
            // 
            // btnSaveToBMS
            // 
            this.btnSaveToBMS.Enabled = false;
            this.btnSaveToBMS.Font = new System.Drawing.Font("휴먼옛체", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnSaveToBMS.Location = new System.Drawing.Point(539, 461);
            this.btnSaveToBMS.Name = "btnSaveToBMS";
            this.btnSaveToBMS.Size = new System.Drawing.Size(90, 59);
            this.btnSaveToBMS.TabIndex = 54;
            this.btnSaveToBMS.Text = "BMS로\r\n 저장";
            this.btnSaveToBMS.UseVisualStyleBackColor = true;
            this.btnSaveToBMS.Click += new System.EventHandler(this.btnSaveToBMS_Click);
            // 
            // btnReadFromBMS
            // 
            this.btnReadFromBMS.Enabled = false;
            this.btnReadFromBMS.Font = new System.Drawing.Font("휴먼옛체", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnReadFromBMS.Location = new System.Drawing.Point(417, 461);
            this.btnReadFromBMS.Name = "btnReadFromBMS";
            this.btnReadFromBMS.Size = new System.Drawing.Size(90, 59);
            this.btnReadFromBMS.TabIndex = 54;
            this.btnReadFromBMS.Text = "BMS에서\r\n  읽기";
            this.btnReadFromBMS.UseVisualStyleBackColor = true;
            this.btnReadFromBMS.Click += new System.EventHandler(this.btnReadFromBMS_Click);
            // 
            // groupBox22
            // 
            this.groupBox22.Controls.Add(this.txtDUTP);
            this.groupBox22.Controls.Add(this.txtCUTP);
            this.groupBox22.Controls.Add(this.txtDOTP);
            this.groupBox22.Controls.Add(this.nudDUTP);
            this.groupBox22.Controls.Add(this.txtCOTP);
            this.groupBox22.Controls.Add(this.label54);
            this.groupBox22.Controls.Add(this.nudCUTP);
            this.groupBox22.Controls.Add(this.nudDOTP);
            this.groupBox22.Controls.Add(this.label52);
            this.groupBox22.Controls.Add(this.label49);
            this.groupBox22.Controls.Add(this.nudCOTP);
            this.groupBox22.Controls.Add(this.label53);
            this.groupBox22.Font = new System.Drawing.Font("Trebuchet MS", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox22.Location = new System.Drawing.Point(60, 253);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(330, 176);
            this.groupBox22.TabIndex = 53;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "팩 온도";
            // 
            // txtDUTP
            // 
            this.txtDUTP.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtDUTP.Location = new System.Drawing.Point(111, 128);
            this.txtDUTP.Name = "txtDUTP";
            this.txtDUTP.ReadOnly = true;
            this.txtDUTP.Size = new System.Drawing.Size(82, 25);
            this.txtDUTP.TabIndex = 55;
            this.txtDUTP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCUTP
            // 
            this.txtCUTP.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtCUTP.Location = new System.Drawing.Point(111, 66);
            this.txtCUTP.Name = "txtCUTP";
            this.txtCUTP.ReadOnly = true;
            this.txtCUTP.Size = new System.Drawing.Size(82, 25);
            this.txtCUTP.TabIndex = 55;
            this.txtCUTP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtDOTP
            // 
            this.txtDOTP.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtDOTP.Location = new System.Drawing.Point(111, 97);
            this.txtDOTP.Name = "txtDOTP";
            this.txtDOTP.ReadOnly = true;
            this.txtDOTP.Size = new System.Drawing.Size(82, 25);
            this.txtDOTP.TabIndex = 55;
            this.txtDOTP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nudDUTP
            // 
            this.nudDUTP.Location = new System.Drawing.Point(213, 129);
            this.nudDUTP.Margin = new System.Windows.Forms.Padding(30, 3, 3, 3);
            this.nudDUTP.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.nudDUTP.Name = "nudDUTP";
            this.nudDUTP.Size = new System.Drawing.Size(82, 25);
            this.nudDUTP.TabIndex = 53;
            this.nudDUTP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudDUTP.Value = new decimal(new int[] {
            20,
            0,
            0,
            -2147483648});
            // 
            // txtCOTP
            // 
            this.txtCOTP.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtCOTP.Location = new System.Drawing.Point(111, 35);
            this.txtCOTP.Name = "txtCOTP";
            this.txtCOTP.ReadOnly = true;
            this.txtCOTP.Size = new System.Drawing.Size(82, 25);
            this.txtCOTP.TabIndex = 55;
            this.txtCOTP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(26, 130);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(77, 20);
            this.label54.TabIndex = 54;
            this.label54.Text = "DUTP (℃)";
            // 
            // nudCUTP
            // 
            this.nudCUTP.Location = new System.Drawing.Point(213, 67);
            this.nudCUTP.Margin = new System.Windows.Forms.Padding(30, 3, 3, 3);
            this.nudCUTP.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.nudCUTP.Name = "nudCUTP";
            this.nudCUTP.Size = new System.Drawing.Size(82, 25);
            this.nudCUTP.TabIndex = 53;
            this.nudCUTP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudCUTP.Value = new decimal(new int[] {
            5,
            0,
            0,
            -2147483648});
            // 
            // nudDOTP
            // 
            this.nudDOTP.Location = new System.Drawing.Point(213, 98);
            this.nudDOTP.Margin = new System.Windows.Forms.Padding(30, 3, 3, 3);
            this.nudDOTP.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.nudDOTP.Name = "nudDOTP";
            this.nudDOTP.Size = new System.Drawing.Size(82, 25);
            this.nudDOTP.TabIndex = 53;
            this.nudDOTP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudDOTP.Value = new decimal(new int[] {
            65,
            0,
            0,
            0});
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(26, 68);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(77, 20);
            this.label52.TabIndex = 54;
            this.label52.Text = "CUTP (℃)";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(26, 99);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(77, 20);
            this.label49.TabIndex = 54;
            this.label49.Text = "DOTP (℃)";
            // 
            // nudCOTP
            // 
            this.nudCOTP.Location = new System.Drawing.Point(213, 36);
            this.nudCOTP.Margin = new System.Windows.Forms.Padding(30, 3, 3, 3);
            this.nudCOTP.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.nudCOTP.Name = "nudCOTP";
            this.nudCOTP.Size = new System.Drawing.Size(82, 25);
            this.nudCOTP.TabIndex = 53;
            this.nudCOTP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudCOTP.Value = new decimal(new int[] {
            55,
            0,
            0,
            0});
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(26, 37);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(77, 20);
            this.label53.TabIndex = 54;
            this.label53.Text = "COTP (℃)";
            // 
            // groupBox23
            // 
            this.groupBox23.Controls.Add(this.label58);
            this.groupBox23.Controls.Add(this.txtDPFdV);
            this.groupBox23.Controls.Add(this.label55);
            this.groupBox23.Controls.Add(this.txtDPFV);
            this.groupBox23.Controls.Add(this.txtCPFdV);
            this.groupBox23.Controls.Add(this.nudDPFdV);
            this.groupBox23.Controls.Add(this.txtCPFV);
            this.groupBox23.Controls.Add(this.label56);
            this.groupBox23.Controls.Add(this.nudCPFdV);
            this.groupBox23.Controls.Add(this.nudDPFV);
            this.groupBox23.Controls.Add(this.label46);
            this.groupBox23.Controls.Add(this.nudCPFV);
            this.groupBox23.Font = new System.Drawing.Font("Trebuchet MS", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox23.Location = new System.Drawing.Point(419, 253);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(330, 176);
            this.groupBox23.TabIndex = 53;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "PF";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(15, 99);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(82, 20);
            this.label58.TabIndex = 56;
            this.label58.Text = "DPFV (mV)";
            // 
            // txtDPFdV
            // 
            this.txtDPFdV.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtDPFdV.Location = new System.Drawing.Point(111, 128);
            this.txtDPFdV.Name = "txtDPFdV";
            this.txtDPFdV.ReadOnly = true;
            this.txtDPFdV.Size = new System.Drawing.Size(82, 25);
            this.txtDPFdV.TabIndex = 55;
            this.txtDPFdV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(15, 37);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(82, 20);
            this.label55.TabIndex = 56;
            this.label55.Text = "CPFV (mV)";
            // 
            // txtDPFV
            // 
            this.txtDPFV.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtDPFV.Location = new System.Drawing.Point(111, 97);
            this.txtDPFV.Name = "txtDPFV";
            this.txtDPFV.ReadOnly = true;
            this.txtDPFV.Size = new System.Drawing.Size(82, 25);
            this.txtDPFV.TabIndex = 55;
            this.txtDPFV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCPFdV
            // 
            this.txtCPFdV.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtCPFdV.Location = new System.Drawing.Point(111, 66);
            this.txtCPFdV.Name = "txtCPFdV";
            this.txtCPFdV.ReadOnly = true;
            this.txtCPFdV.Size = new System.Drawing.Size(82, 25);
            this.txtCPFdV.TabIndex = 55;
            this.txtCPFdV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nudDPFdV
            // 
            this.nudDPFdV.Location = new System.Drawing.Point(213, 129);
            this.nudDPFdV.Margin = new System.Windows.Forms.Padding(30, 3, 3, 3);
            this.nudDPFdV.Maximum = new decimal(new int[] {
            400,
            0,
            0,
            0});
            this.nudDPFdV.Name = "nudDPFdV";
            this.nudDPFdV.Size = new System.Drawing.Size(82, 25);
            this.nudDPFdV.TabIndex = 53;
            this.nudDPFdV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudDPFdV.Value = new decimal(new int[] {
            250,
            0,
            0,
            0});
            // 
            // txtCPFV
            // 
            this.txtCPFV.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtCPFV.Location = new System.Drawing.Point(111, 35);
            this.txtCPFV.Name = "txtCPFV";
            this.txtCPFV.ReadOnly = true;
            this.txtCPFV.Size = new System.Drawing.Size(82, 25);
            this.txtCPFV.TabIndex = 55;
            this.txtCPFV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(15, 129);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(90, 20);
            this.label56.TabIndex = 54;
            this.label56.Text = "DPFdV (mV)";
            // 
            // nudCPFdV
            // 
            this.nudCPFdV.Location = new System.Drawing.Point(213, 67);
            this.nudCPFdV.Margin = new System.Windows.Forms.Padding(30, 3, 3, 3);
            this.nudCPFdV.Maximum = new decimal(new int[] {
            400,
            0,
            0,
            0});
            this.nudCPFdV.Name = "nudCPFdV";
            this.nudCPFdV.Size = new System.Drawing.Size(82, 25);
            this.nudCPFdV.TabIndex = 53;
            this.nudCPFdV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudCPFdV.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // nudDPFV
            // 
            this.nudDPFV.Location = new System.Drawing.Point(213, 98);
            this.nudDPFV.Margin = new System.Windows.Forms.Padding(30, 3, 3, 3);
            this.nudDPFV.Maximum = new decimal(new int[] {
            4500,
            0,
            0,
            0});
            this.nudDPFV.Minimum = new decimal(new int[] {
            2700,
            0,
            0,
            0});
            this.nudDPFV.Name = "nudDPFV";
            this.nudDPFV.Size = new System.Drawing.Size(82, 25);
            this.nudDPFV.TabIndex = 53;
            this.nudDPFV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudDPFV.Value = new decimal(new int[] {
            3200,
            0,
            0,
            0});
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(15, 67);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(90, 20);
            this.label46.TabIndex = 54;
            this.label46.Text = "CPFdV (mV)";
            // 
            // nudCPFV
            // 
            this.nudCPFV.Location = new System.Drawing.Point(213, 36);
            this.nudCPFV.Margin = new System.Windows.Forms.Padding(30, 3, 3, 3);
            this.nudCPFV.Maximum = new decimal(new int[] {
            4500,
            0,
            0,
            0});
            this.nudCPFV.Minimum = new decimal(new int[] {
            2700,
            0,
            0,
            0});
            this.nudCPFV.Name = "nudCPFV";
            this.nudCPFV.Size = new System.Drawing.Size(82, 25);
            this.nudCPFV.TabIndex = 53;
            this.nudCPFV.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudCPFV.Value = new decimal(new int[] {
            3600,
            0,
            0,
            0});
            // 
            // groupBox21
            // 
            this.groupBox21.Controls.Add(this.txtDOCP);
            this.groupBox21.Controls.Add(this.txtCOCP);
            this.groupBox21.Controls.Add(this.nudDOCP);
            this.groupBox21.Controls.Add(this.label50);
            this.groupBox21.Controls.Add(this.nudCOCP);
            this.groupBox21.Controls.Add(this.label51);
            this.groupBox21.Font = new System.Drawing.Font("Trebuchet MS", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox21.Location = new System.Drawing.Point(419, 126);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(330, 115);
            this.groupBox21.TabIndex = 53;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "팩 전류";
            // 
            // txtDOCP
            // 
            this.txtDOCP.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtDOCP.Location = new System.Drawing.Point(111, 66);
            this.txtDOCP.Name = "txtDOCP";
            this.txtDOCP.ReadOnly = true;
            this.txtDOCP.Size = new System.Drawing.Size(82, 25);
            this.txtDOCP.TabIndex = 55;
            this.txtDOCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCOCP
            // 
            this.txtCOCP.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtCOCP.Location = new System.Drawing.Point(111, 35);
            this.txtCOCP.Name = "txtCOCP";
            this.txtCOCP.ReadOnly = true;
            this.txtCOCP.Size = new System.Drawing.Size(82, 25);
            this.txtCOCP.TabIndex = 55;
            this.txtCOCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nudDOCP
            // 
            this.nudDOCP.Location = new System.Drawing.Point(213, 67);
            this.nudDOCP.Margin = new System.Windows.Forms.Padding(30, 3, 3, 3);
            this.nudDOCP.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.nudDOCP.Minimum = new decimal(new int[] {
            200,
            0,
            0,
            -2147483648});
            this.nudDOCP.Name = "nudDOCP";
            this.nudDOCP.Size = new System.Drawing.Size(82, 25);
            this.nudDOCP.TabIndex = 53;
            this.nudDOCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudDOCP.Value = new decimal(new int[] {
            90,
            0,
            0,
            -2147483648});
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(26, 68);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(71, 20);
            this.label50.TabIndex = 54;
            this.label50.Text = "DOCP (A)";
            // 
            // nudCOCP
            // 
            this.nudCOCP.Location = new System.Drawing.Point(213, 36);
            this.nudCOCP.Margin = new System.Windows.Forms.Padding(30, 3, 3, 3);
            this.nudCOCP.Maximum = new decimal(new int[] {
            200,
            0,
            0,
            0});
            this.nudCOCP.Name = "nudCOCP";
            this.nudCOCP.Size = new System.Drawing.Size(82, 25);
            this.nudCOCP.TabIndex = 53;
            this.nudCOCP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudCOCP.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(26, 37);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(71, 20);
            this.label51.TabIndex = 54;
            this.label51.Text = "COCP (A)";
            // 
            // groupBox24
            // 
            this.groupBox24.Controls.Add(this.txtCapacity);
            this.groupBox24.Controls.Add(this.nudCapacity);
            this.groupBox24.Controls.Add(this.label57);
            this.groupBox24.Font = new System.Drawing.Font("Trebuchet MS", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox24.Location = new System.Drawing.Point(60, 22);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(330, 98);
            this.groupBox24.TabIndex = 53;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "용량";
            // 
            // txtCapacity
            // 
            this.txtCapacity.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtCapacity.Location = new System.Drawing.Point(111, 35);
            this.txtCapacity.Name = "txtCapacity";
            this.txtCapacity.ReadOnly = true;
            this.txtCapacity.Size = new System.Drawing.Size(82, 25);
            this.txtCapacity.TabIndex = 55;
            this.txtCapacity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nudCapacity
            // 
            this.nudCapacity.Location = new System.Drawing.Point(213, 36);
            this.nudCapacity.Margin = new System.Windows.Forms.Padding(30, 3, 3, 3);
            this.nudCapacity.Maximum = new decimal(new int[] {
            1500,
            0,
            0,
            0});
            this.nudCapacity.Minimum = new decimal(new int[] {
            40,
            0,
            0,
            0});
            this.nudCapacity.Name = "nudCapacity";
            this.nudCapacity.Size = new System.Drawing.Size(82, 25);
            this.nudCapacity.TabIndex = 53;
            this.nudCapacity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudCapacity.Value = new decimal(new int[] {
            380,
            0,
            0,
            0});
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(14, 37);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(95, 20);
            this.label57.TabIndex = 54;
            this.label57.Text = "용량 (0.1Ah)";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.txtUVP);
            this.groupBox20.Controls.Add(this.txtOVP);
            this.groupBox20.Controls.Add(this.nudUVP);
            this.groupBox20.Controls.Add(this.label48);
            this.groupBox20.Controls.Add(this.nudOVP);
            this.groupBox20.Controls.Add(this.label47);
            this.groupBox20.Font = new System.Drawing.Font("Trebuchet MS", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox20.Location = new System.Drawing.Point(60, 126);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(330, 115);
            this.groupBox20.TabIndex = 53;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "셀 전압";
            // 
            // txtUVP
            // 
            this.txtUVP.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtUVP.Location = new System.Drawing.Point(111, 66);
            this.txtUVP.Name = "txtUVP";
            this.txtUVP.ReadOnly = true;
            this.txtUVP.Size = new System.Drawing.Size(82, 25);
            this.txtUVP.TabIndex = 55;
            this.txtUVP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtOVP
            // 
            this.txtOVP.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.txtOVP.Location = new System.Drawing.Point(111, 35);
            this.txtOVP.Name = "txtOVP";
            this.txtOVP.ReadOnly = true;
            this.txtOVP.Size = new System.Drawing.Size(82, 25);
            this.txtOVP.TabIndex = 55;
            this.txtOVP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // nudUVP
            // 
            this.nudUVP.Location = new System.Drawing.Point(213, 67);
            this.nudUVP.Margin = new System.Windows.Forms.Padding(30, 3, 3, 3);
            this.nudUVP.Maximum = new decimal(new int[] {
            4500,
            0,
            0,
            0});
            this.nudUVP.Minimum = new decimal(new int[] {
            2700,
            0,
            0,
            0});
            this.nudUVP.Name = "nudUVP";
            this.nudUVP.Size = new System.Drawing.Size(82, 25);
            this.nudUVP.TabIndex = 53;
            this.nudUVP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudUVP.Value = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(26, 68);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(75, 20);
            this.label48.TabIndex = 54;
            this.label48.Text = "UVP (mV)";
            // 
            // nudOVP
            // 
            this.nudOVP.Location = new System.Drawing.Point(213, 36);
            this.nudOVP.Margin = new System.Windows.Forms.Padding(30, 3, 3, 3);
            this.nudOVP.Maximum = new decimal(new int[] {
            4500,
            0,
            0,
            0});
            this.nudOVP.Minimum = new decimal(new int[] {
            2700,
            0,
            0,
            0});
            this.nudOVP.Name = "nudOVP";
            this.nudOVP.Size = new System.Drawing.Size(82, 25);
            this.nudOVP.TabIndex = 53;
            this.nudOVP.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.nudOVP.Value = new decimal(new int[] {
            4200,
            0,
            0,
            0});
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(26, 37);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(75, 20);
            this.label47.TabIndex = 54;
            this.label47.Text = "OVP (mV)";
            // 
            // tabEvent
            // 
            this.tabEvent.Controls.Add(this.btnEventReqStop);
            this.tabEvent.Controls.Add(this.lblBmsRcvStateEvent);
            this.tabEvent.Controls.Add(this.rtbEventLog);
            this.tabEvent.Controls.Add(this.ckbDisplayMessageEvent);
            this.tabEvent.Controls.Add(this.label41);
            this.tabEvent.Controls.Add(this.groupBox15);
            this.tabEvent.Controls.Add(this.btnEventSave);
            this.tabEvent.Controls.Add(this.btnClearEventLog);
            this.tabEvent.Controls.Add(this.btnEventRequest);
            this.tabEvent.Controls.Add(this.lblEventNameCode);
            this.tabEvent.Controls.Add(this.label63);
            this.tabEvent.Controls.Add(this.label62);
            this.tabEvent.Controls.Add(this.lvwEventDetail);
            this.tabEvent.Controls.Add(this.lvwEventMain);
            this.tabEvent.Location = new System.Drawing.Point(4, 44);
            this.tabEvent.Name = "tabEvent";
            this.tabEvent.Size = new System.Drawing.Size(1198, 739);
            this.tabEvent.TabIndex = 5;
            this.tabEvent.Text = "EVENT 읽기";
            this.tabEvent.UseVisualStyleBackColor = true;
            // 
            // btnEventReqStop
            // 
            this.btnEventReqStop.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnEventReqStop.Location = new System.Drawing.Point(922, 661);
            this.btnEventReqStop.Name = "btnEventReqStop";
            this.btnEventReqStop.Size = new System.Drawing.Size(77, 46);
            this.btnEventReqStop.TabIndex = 43;
            this.btnEventReqStop.Text = "EVENT \r\n요청 중지";
            this.btnEventReqStop.UseVisualStyleBackColor = true;
            this.btnEventReqStop.Click += new System.EventHandler(this.btnEventReqStop_Click);
            // 
            // lblBmsRcvStateEvent
            // 
            this.lblBmsRcvStateEvent.AutoSize = true;
            this.lblBmsRcvStateEvent.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblBmsRcvStateEvent.ForeColor = System.Drawing.Color.Red;
            this.lblBmsRcvStateEvent.Location = new System.Drawing.Point(421, 13);
            this.lblBmsRcvStateEvent.Name = "lblBmsRcvStateEvent";
            this.lblBmsRcvStateEvent.Size = new System.Drawing.Size(128, 40);
            this.lblBmsRcvStateEvent.TabIndex = 42;
            this.lblBmsRcvStateEvent.Text = "BMS데이터를 \r\n읽을 수 없습니다.";
            // 
            // rtbEventLog
            // 
            this.rtbEventLog.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbEventLog.Location = new System.Drawing.Point(18, 557);
            this.rtbEventLog.Name = "rtbEventLog";
            this.rtbEventLog.Size = new System.Drawing.Size(540, 166);
            this.rtbEventLog.TabIndex = 41;
            this.rtbEventLog.Text = "rtbEventLog";
            // 
            // ckbDisplayMessageEvent
            // 
            this.ckbDisplayMessageEvent.AutoSize = true;
            this.ckbDisplayMessageEvent.Location = new System.Drawing.Point(564, 626);
            this.ckbDisplayMessageEvent.Name = "ckbDisplayMessageEvent";
            this.ckbDisplayMessageEvent.Size = new System.Drawing.Size(141, 24);
            this.ckbDisplayMessageEvent.TabIndex = 40;
            this.ckbDisplayMessageEvent.Text = "Display Message";
            this.ckbDisplayMessageEvent.UseVisualStyleBackColor = true;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("휴먼옛체", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label41.Location = new System.Drawing.Point(15, 537);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(82, 17);
            this.label41.TabIndex = 37;
            this.label41.Text = "Event Log";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.label42);
            this.groupBox15.Controls.Add(this.label40);
            this.groupBox15.Controls.Add(this.txtRunTimeInEvent);
            this.groupBox15.Controls.Add(this.txtLastEvent);
            this.groupBox15.Location = new System.Drawing.Point(815, 549);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(354, 99);
            this.groupBox15.TabIndex = 35;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Debugging 정보";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(72, 68);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(140, 20);
            this.label42.TabIndex = 40;
            this.label42.Text = "BMS 실행 시간 (초)";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(38, 33);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(174, 20);
            this.label40.TabIndex = 34;
            this.label40.Text = "마지막 EVNET 저장 위치";
            // 
            // txtRunTimeInEvent
            // 
            this.txtRunTimeInEvent.BackColor = System.Drawing.SystemColors.Window;
            this.txtRunTimeInEvent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRunTimeInEvent.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRunTimeInEvent.Location = new System.Drawing.Point(248, 68);
            this.txtRunTimeInEvent.Name = "txtRunTimeInEvent";
            this.txtRunTimeInEvent.ReadOnly = true;
            this.txtRunTimeInEvent.Size = new System.Drawing.Size(80, 25);
            this.txtRunTimeInEvent.TabIndex = 39;
            this.txtRunTimeInEvent.Text = "RunTime";
            this.txtRunTimeInEvent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtLastEvent
            // 
            this.txtLastEvent.BackColor = System.Drawing.SystemColors.Window;
            this.txtLastEvent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtLastEvent.Font = new System.Drawing.Font("Consolas", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLastEvent.Location = new System.Drawing.Point(248, 33);
            this.txtLastEvent.Name = "txtLastEvent";
            this.txtLastEvent.ReadOnly = true;
            this.txtLastEvent.Size = new System.Drawing.Size(80, 25);
            this.txtLastEvent.TabIndex = 33;
            this.txtLastEvent.Text = "LastView";
            this.txtLastEvent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btnEventSave
            // 
            this.btnEventSave.Location = new System.Drawing.Point(564, 661);
            this.btnEventSave.Name = "btnEventSave";
            this.btnEventSave.Size = new System.Drawing.Size(96, 61);
            this.btnEventSave.TabIndex = 32;
            this.btnEventSave.Text = "Event 저장";
            this.btnEventSave.UseVisualStyleBackColor = true;
            this.btnEventSave.Click += new System.EventHandler(this.btnEventSave_Click);
            // 
            // btnClearEventLog
            // 
            this.btnClearEventLog.Font = new System.Drawing.Font("맑은 고딕", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnClearEventLog.Location = new System.Drawing.Point(820, 661);
            this.btnClearEventLog.Name = "btnClearEventLog";
            this.btnClearEventLog.Size = new System.Drawing.Size(80, 49);
            this.btnClearEventLog.TabIndex = 32;
            this.btnClearEventLog.Text = "Event Log\r\n삭제\r\n";
            this.btnClearEventLog.UseVisualStyleBackColor = true;
            this.btnClearEventLog.Click += new System.EventHandler(this.btnClearEventLog_Click);
            // 
            // btnEventRequest
            // 
            this.btnEventRequest.Location = new System.Drawing.Point(564, 556);
            this.btnEventRequest.Name = "btnEventRequest";
            this.btnEventRequest.Size = new System.Drawing.Size(93, 61);
            this.btnEventRequest.TabIndex = 32;
            this.btnEventRequest.Text = "Event 요청";
            this.btnEventRequest.UseVisualStyleBackColor = true;
            this.btnEventRequest.Click += new System.EventHandler(this.btnEventRequest_Click);
            // 
            // lblEventNameCode
            // 
            this.lblEventNameCode.AutoSize = true;
            this.lblEventNameCode.Font = new System.Drawing.Font("맑은 고딕", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblEventNameCode.ForeColor = System.Drawing.Color.Blue;
            this.lblEventNameCode.Location = new System.Drawing.Point(825, 22);
            this.lblEventNameCode.Name = "lblEventNameCode";
            this.lblEventNameCode.Size = new System.Drawing.Size(302, 25);
            this.lblEventNameCode.TabIndex = 31;
            this.lblEventNameCode.Text = "( Event No, EventName , Code )";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label63.Location = new System.Drawing.Point(643, 20);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(187, 30);
            this.label63.TabIndex = 31;
            this.label63.Text = "Event별 발생 정보";
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label62.Location = new System.Drawing.Point(13, 21);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(110, 30);
            this.label62.TabIndex = 31;
            this.label62.Text = "Event List";
            // 
            // lvwEventDetail
            // 
            this.lvwEventDetail.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.dtNo,
            this.dtTime,
            this.dtEventCode,
            this.dtVoltPack,
            this.dtVoltMax,
            this.dtVoltMin,
            this.dtCurrent,
            this.dtTempMax,
            this.dtTempMin});
            this.lvwEventDetail.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvwEventDetail.FullRowSelect = true;
            this.lvwEventDetail.GridLines = true;
            this.lvwEventDetail.HideSelection = false;
            this.lvwEventDetail.Location = new System.Drawing.Point(641, 58);
            this.lvwEventDetail.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.lvwEventDetail.MultiSelect = false;
            this.lvwEventDetail.Name = "lvwEventDetail";
            this.lvwEventDetail.Size = new System.Drawing.Size(553, 466);
            this.lvwEventDetail.TabIndex = 30;
            this.lvwEventDetail.UseCompatibleStateImageBehavior = false;
            this.lvwEventDetail.View = System.Windows.Forms.View.Details;
            this.lvwEventDetail.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lvwEventDetail_KeyDown);
            this.lvwEventDetail.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lvwEventDetail_KeyUp);
            this.lvwEventDetail.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lvwEventDetail_MouseClick);
            // 
            // dtNo
            // 
            this.dtNo.Text = "No";
            this.dtNo.Width = 40;
            // 
            // dtTime
            // 
            this.dtTime.Text = "시간(초)";
            this.dtTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.dtTime.Width = 80;
            // 
            // dtEventCode
            // 
            this.dtEventCode.Text = "Code";
            // 
            // dtVoltPack
            // 
            this.dtVoltPack.Text = "팩전압(V)";
            this.dtVoltPack.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.dtVoltPack.Width = 70;
            // 
            // dtVoltMax
            // 
            this.dtVoltMax.Text = "Max(mV)";
            this.dtVoltMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dtVoltMin
            // 
            this.dtVoltMin.Text = "Min(mV)";
            this.dtVoltMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dtCurrent
            // 
            this.dtCurrent.Text = "전류(A)";
            this.dtCurrent.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dtTempMax
            // 
            this.dtTempMax.Text = "최대온도";
            this.dtTempMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // dtTempMin
            // 
            this.dtTempMin.Text = "최소온도";
            this.dtTempMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lvwEventMain
            // 
            this.lvwEventMain.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.No,
            this.Time,
            this.EventName,
            this.EventCode,
            this.VoltPack,
            this.VoltMax,
            this.VoltMin,
            this.Current,
            this.TempMax,
            this.TempMin});
            this.lvwEventMain.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lvwEventMain.FullRowSelect = true;
            this.lvwEventMain.GridLines = true;
            this.lvwEventMain.HideSelection = false;
            this.lvwEventMain.Location = new System.Drawing.Point(6, 58);
            this.lvwEventMain.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.lvwEventMain.MultiSelect = false;
            this.lvwEventMain.Name = "lvwEventMain";
            this.lvwEventMain.Size = new System.Drawing.Size(625, 466);
            this.lvwEventMain.TabIndex = 30;
            this.lvwEventMain.UseCompatibleStateImageBehavior = false;
            this.lvwEventMain.View = System.Windows.Forms.View.Details;
            this.lvwEventMain.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lvwEventMain_KeyDown);
            this.lvwEventMain.KeyUp += new System.Windows.Forms.KeyEventHandler(this.lvwEventMain_KeyUp);
            this.lvwEventMain.MouseClick += new System.Windows.Forms.MouseEventHandler(this.lvwEventMain_MouseClick);
            // 
            // No
            // 
            this.No.Text = "No";
            this.No.Width = 40;
            // 
            // Time
            // 
            this.Time.Text = "시간(초)";
            this.Time.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Time.Width = 80;
            // 
            // EventName
            // 
            this.EventName.Text = "EVENT ";
            this.EventName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.EventName.Width = 80;
            // 
            // EventCode
            // 
            this.EventCode.Text = "Code";
            this.EventCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.EventCode.Width = 50;
            // 
            // VoltPack
            // 
            this.VoltPack.Text = "팩전압(V)";
            this.VoltPack.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.VoltPack.Width = 70;
            // 
            // VoltMax
            // 
            this.VoltMax.Text = "Max(mV)";
            this.VoltMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // VoltMin
            // 
            this.VoltMin.Text = "Min(mV)";
            this.VoltMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Current
            // 
            this.Current.Text = "전류(A)";
            this.Current.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TempMax
            // 
            this.TempMax.Text = "최대온도";
            this.TempMax.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // TempMin
            // 
            this.TempMin.Text = "최소온도";
            this.TempMin.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tabPcanRcvId
            // 
            this.tabPcanRcvId.Controls.Add(this.groupBox5);
            this.tabPcanRcvId.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPcanRcvId.Location = new System.Drawing.Point(4, 44);
            this.tabPcanRcvId.Name = "tabPcanRcvId";
            this.tabPcanRcvId.Padding = new System.Windows.Forms.Padding(3);
            this.tabPcanRcvId.Size = new System.Drawing.Size(1198, 739);
            this.tabPcanRcvId.TabIndex = 1;
            this.tabPcanRcvId.Text = "PCAN 수신 (ID)";
            // 
            // tabPcanRcvMsg
            // 
            this.tabPcanRcvMsg.Controls.Add(this.groupBox6);
            this.tabPcanRcvMsg.Controls.Add(this.textBox1);
            this.tabPcanRcvMsg.Controls.Add(this.btRtbInit);
            this.tabPcanRcvMsg.Controls.Add(this.rtbCanMsg);
            this.tabPcanRcvMsg.Controls.Add(this.btRtbSave);
            this.tabPcanRcvMsg.Font = new System.Drawing.Font("Palatino Linotype", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPcanRcvMsg.Location = new System.Drawing.Point(4, 44);
            this.tabPcanRcvMsg.Name = "tabPcanRcvMsg";
            this.tabPcanRcvMsg.Padding = new System.Windows.Forms.Padding(3);
            this.tabPcanRcvMsg.Size = new System.Drawing.Size(1198, 739);
            this.tabPcanRcvMsg.TabIndex = 2;
            this.tabPcanRcvMsg.Text = "PCAN 송수신 (메세지)";
            this.tabPcanRcvMsg.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Controls.Add(this.laLength);
            this.groupBox6.Controls.Add(this.label3);
            this.groupBox6.Controls.Add(this.textBox69);
            this.groupBox6.Controls.Add(this.textBox37);
            this.groupBox6.Controls.Add(this.textBox68);
            this.groupBox6.Controls.Add(this.textBox21);
            this.groupBox6.Controls.Add(this.textBox67);
            this.groupBox6.Controls.Add(this.textBox36);
            this.groupBox6.Controls.Add(this.textBox66);
            this.groupBox6.Controls.Add(this.txtData7);
            this.groupBox6.Controls.Add(this.textBox65);
            this.groupBox6.Controls.Add(this.textBox35);
            this.groupBox6.Controls.Add(this.textBox64);
            this.groupBox6.Controls.Add(this.textBox20);
            this.groupBox6.Controls.Add(this.textBox63);
            this.groupBox6.Controls.Add(this.textBox34);
            this.groupBox6.Controls.Add(this.textBox62);
            this.groupBox6.Controls.Add(this.txtData6);
            this.groupBox6.Controls.Add(this.textBox61);
            this.groupBox6.Controls.Add(this.textBox33);
            this.groupBox6.Controls.Add(this.textBox60);
            this.groupBox6.Controls.Add(this.textBox19);
            this.groupBox6.Controls.Add(this.textBox59);
            this.groupBox6.Controls.Add(this.textBox32);
            this.groupBox6.Controls.Add(this.textBox58);
            this.groupBox6.Controls.Add(this.txtData3);
            this.groupBox6.Controls.Add(this.textBox57);
            this.groupBox6.Controls.Add(this.textBox31);
            this.groupBox6.Controls.Add(this.textBox56);
            this.groupBox6.Controls.Add(this.textBox18);
            this.groupBox6.Controls.Add(this.textBox55);
            this.groupBox6.Controls.Add(this.textBox30);
            this.groupBox6.Controls.Add(this.textBox54);
            this.groupBox6.Controls.Add(this.txtData5);
            this.groupBox6.Controls.Add(this.textBox53);
            this.groupBox6.Controls.Add(this.textBox29);
            this.groupBox6.Controls.Add(this.textBox52);
            this.groupBox6.Controls.Add(this.textBox17);
            this.groupBox6.Controls.Add(this.textBox51);
            this.groupBox6.Controls.Add(this.textBox28);
            this.groupBox6.Controls.Add(this.textBox50);
            this.groupBox6.Controls.Add(this.txtData2);
            this.groupBox6.Controls.Add(this.textBox49);
            this.groupBox6.Controls.Add(this.textBox27);
            this.groupBox6.Controls.Add(this.textBox48);
            this.groupBox6.Controls.Add(this.textBox16);
            this.groupBox6.Controls.Add(this.textBox47);
            this.groupBox6.Controls.Add(this.textBox26);
            this.groupBox6.Controls.Add(this.textBox46);
            this.groupBox6.Controls.Add(this.txtData4);
            this.groupBox6.Controls.Add(this.textBox45);
            this.groupBox6.Controls.Add(this.textBox25);
            this.groupBox6.Controls.Add(this.textBox44);
            this.groupBox6.Controls.Add(this.textBox15);
            this.groupBox6.Controls.Add(this.textBox43);
            this.groupBox6.Controls.Add(this.textBox24);
            this.groupBox6.Controls.Add(this.textBox42);
            this.groupBox6.Controls.Add(this.txtData1);
            this.groupBox6.Controls.Add(this.textBox41);
            this.groupBox6.Controls.Add(this.textBox23);
            this.groupBox6.Controls.Add(this.textBox40);
            this.groupBox6.Controls.Add(this.textBox14);
            this.groupBox6.Controls.Add(this.textBox39);
            this.groupBox6.Controls.Add(this.textBox22);
            this.groupBox6.Controls.Add(this.textBox38);
            this.groupBox6.Controls.Add(this.txtData0);
            this.groupBox6.Controls.Add(this.chbBRS);
            this.groupBox6.Controls.Add(this.chbFD);
            this.groupBox6.Controls.Add(this.chbRemote);
            this.groupBox6.Controls.Add(this.chbExtended);
            this.groupBox6.Controls.Add(this.btnWrite);
            this.groupBox6.Controls.Add(this.label12);
            this.groupBox6.Controls.Add(this.label13);
            this.groupBox6.Controls.Add(this.txtID);
            this.groupBox6.Controls.Add(this.nudLength);
            this.groupBox6.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.groupBox6.Font = new System.Drawing.Font("Book Antiqua", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.Location = new System.Drawing.Point(813, 48);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox6.Size = new System.Drawing.Size(337, 479);
            this.groupBox6.TabIndex = 165;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Write Messages";
            this.groupBox6.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(224, 323);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 17);
            this.label5.TabIndex = 113;
            this.label5.Text = "Length:";
            // 
            // laLength
            // 
            this.laLength.AutoSize = true;
            this.laLength.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laLength.Location = new System.Drawing.Point(233, 351);
            this.laLength.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.laLength.Name = "laLength";
            this.laLength.Size = new System.Drawing.Size(26, 17);
            this.laLength.TabIndex = 112;
            this.laLength.Text = "8 B";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(28, 45);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 20);
            this.label3.TabIndex = 111;
            this.label3.Text = "Data (Hex):";
            // 
            // textBox69
            // 
            this.textBox69.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox69.Enabled = false;
            this.textBox69.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox69.Location = new System.Drawing.Point(259, 249);
            this.textBox69.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox69.MaxLength = 2;
            this.textBox69.Name = "textBox69";
            this.textBox69.Size = new System.Drawing.Size(28, 24);
            this.textBox69.TabIndex = 17;
            this.textBox69.Text = "00";
            this.textBox69.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox37
            // 
            this.textBox37.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox37.Enabled = false;
            this.textBox37.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox37.Location = new System.Drawing.Point(259, 147);
            this.textBox37.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox37.MaxLength = 2;
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(28, 24);
            this.textBox37.TabIndex = 17;
            this.textBox37.Text = "00";
            this.textBox37.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox68
            // 
            this.textBox68.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox68.Enabled = false;
            this.textBox68.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox68.Location = new System.Drawing.Point(259, 199);
            this.textBox68.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox68.MaxLength = 2;
            this.textBox68.Name = "textBox68";
            this.textBox68.Size = new System.Drawing.Size(28, 24);
            this.textBox68.TabIndex = 17;
            this.textBox68.Text = "00";
            this.textBox68.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox21
            // 
            this.textBox21.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox21.Enabled = false;
            this.textBox21.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox21.Location = new System.Drawing.Point(259, 97);
            this.textBox21.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox21.MaxLength = 2;
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(28, 24);
            this.textBox21.TabIndex = 17;
            this.textBox21.Text = "00";
            this.textBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox67
            // 
            this.textBox67.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox67.Enabled = false;
            this.textBox67.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox67.Location = new System.Drawing.Point(259, 224);
            this.textBox67.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox67.MaxLength = 2;
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(28, 24);
            this.textBox67.TabIndex = 17;
            this.textBox67.Text = "00";
            this.textBox67.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox36
            // 
            this.textBox36.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox36.Enabled = false;
            this.textBox36.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox36.Location = new System.Drawing.Point(259, 122);
            this.textBox36.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox36.MaxLength = 2;
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(28, 24);
            this.textBox36.TabIndex = 17;
            this.textBox36.Text = "00";
            this.textBox36.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox66
            // 
            this.textBox66.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox66.Enabled = false;
            this.textBox66.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox66.Location = new System.Drawing.Point(259, 174);
            this.textBox66.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox66.MaxLength = 2;
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(28, 24);
            this.textBox66.TabIndex = 17;
            this.textBox66.Text = "00";
            this.textBox66.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtData7
            // 
            this.txtData7.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtData7.Enabled = false;
            this.txtData7.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData7.Location = new System.Drawing.Point(259, 72);
            this.txtData7.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtData7.MaxLength = 2;
            this.txtData7.Name = "txtData7";
            this.txtData7.Size = new System.Drawing.Size(28, 24);
            this.txtData7.TabIndex = 17;
            this.txtData7.Text = "00";
            this.txtData7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox65
            // 
            this.textBox65.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox65.Enabled = false;
            this.textBox65.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox65.Location = new System.Drawing.Point(229, 249);
            this.textBox65.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox65.MaxLength = 2;
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(28, 24);
            this.textBox65.TabIndex = 16;
            this.textBox65.Text = "00";
            this.textBox65.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox35
            // 
            this.textBox35.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox35.Enabled = false;
            this.textBox35.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox35.Location = new System.Drawing.Point(229, 147);
            this.textBox35.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox35.MaxLength = 2;
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(28, 24);
            this.textBox35.TabIndex = 16;
            this.textBox35.Text = "00";
            this.textBox35.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox64
            // 
            this.textBox64.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox64.Enabled = false;
            this.textBox64.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox64.Location = new System.Drawing.Point(229, 199);
            this.textBox64.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox64.MaxLength = 2;
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(28, 24);
            this.textBox64.TabIndex = 16;
            this.textBox64.Text = "00";
            this.textBox64.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox20
            // 
            this.textBox20.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox20.Enabled = false;
            this.textBox20.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox20.Location = new System.Drawing.Point(229, 97);
            this.textBox20.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox20.MaxLength = 2;
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(28, 24);
            this.textBox20.TabIndex = 16;
            this.textBox20.Text = "00";
            this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox63
            // 
            this.textBox63.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox63.Enabled = false;
            this.textBox63.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox63.Location = new System.Drawing.Point(229, 224);
            this.textBox63.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox63.MaxLength = 2;
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(28, 24);
            this.textBox63.TabIndex = 16;
            this.textBox63.Text = "00";
            this.textBox63.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox34
            // 
            this.textBox34.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox34.Enabled = false;
            this.textBox34.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox34.Location = new System.Drawing.Point(229, 122);
            this.textBox34.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox34.MaxLength = 2;
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(28, 24);
            this.textBox34.TabIndex = 16;
            this.textBox34.Text = "00";
            this.textBox34.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox62
            // 
            this.textBox62.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox62.Enabled = false;
            this.textBox62.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox62.Location = new System.Drawing.Point(229, 174);
            this.textBox62.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox62.MaxLength = 2;
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(28, 24);
            this.textBox62.TabIndex = 16;
            this.textBox62.Text = "00";
            this.textBox62.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtData6
            // 
            this.txtData6.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtData6.Enabled = false;
            this.txtData6.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData6.Location = new System.Drawing.Point(229, 72);
            this.txtData6.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtData6.MaxLength = 2;
            this.txtData6.Name = "txtData6";
            this.txtData6.Size = new System.Drawing.Size(28, 24);
            this.txtData6.TabIndex = 16;
            this.txtData6.Text = "00";
            this.txtData6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox61
            // 
            this.textBox61.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox61.Enabled = false;
            this.textBox61.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox61.Location = new System.Drawing.Point(130, 249);
            this.textBox61.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox61.MaxLength = 2;
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(28, 24);
            this.textBox61.TabIndex = 17;
            this.textBox61.Text = "00";
            this.textBox61.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox33
            // 
            this.textBox33.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox33.Enabled = false;
            this.textBox33.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox33.Location = new System.Drawing.Point(130, 147);
            this.textBox33.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox33.MaxLength = 2;
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(28, 24);
            this.textBox33.TabIndex = 17;
            this.textBox33.Text = "00";
            this.textBox33.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox60
            // 
            this.textBox60.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox60.Enabled = false;
            this.textBox60.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox60.Location = new System.Drawing.Point(130, 199);
            this.textBox60.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox60.MaxLength = 2;
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(28, 24);
            this.textBox60.TabIndex = 17;
            this.textBox60.Text = "00";
            this.textBox60.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox19
            // 
            this.textBox19.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox19.Enabled = false;
            this.textBox19.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(130, 97);
            this.textBox19.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox19.MaxLength = 2;
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(28, 24);
            this.textBox19.TabIndex = 17;
            this.textBox19.Text = "00";
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox59
            // 
            this.textBox59.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox59.Enabled = false;
            this.textBox59.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox59.Location = new System.Drawing.Point(130, 224);
            this.textBox59.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox59.MaxLength = 2;
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(28, 24);
            this.textBox59.TabIndex = 17;
            this.textBox59.Text = "00";
            this.textBox59.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox32
            // 
            this.textBox32.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox32.Enabled = false;
            this.textBox32.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox32.Location = new System.Drawing.Point(130, 122);
            this.textBox32.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox32.MaxLength = 2;
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(28, 24);
            this.textBox32.TabIndex = 17;
            this.textBox32.Text = "00";
            this.textBox32.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox58
            // 
            this.textBox58.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox58.Enabled = false;
            this.textBox58.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox58.Location = new System.Drawing.Point(130, 174);
            this.textBox58.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox58.MaxLength = 2;
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(28, 24);
            this.textBox58.TabIndex = 17;
            this.textBox58.Text = "00";
            this.textBox58.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtData3
            // 
            this.txtData3.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtData3.Enabled = false;
            this.txtData3.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData3.Location = new System.Drawing.Point(130, 72);
            this.txtData3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtData3.MaxLength = 2;
            this.txtData3.Name = "txtData3";
            this.txtData3.Size = new System.Drawing.Size(28, 24);
            this.txtData3.TabIndex = 17;
            this.txtData3.Text = "00";
            this.txtData3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox57
            // 
            this.textBox57.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox57.Enabled = false;
            this.textBox57.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox57.Location = new System.Drawing.Point(199, 249);
            this.textBox57.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox57.MaxLength = 2;
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(28, 24);
            this.textBox57.TabIndex = 15;
            this.textBox57.Text = "00";
            this.textBox57.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox31
            // 
            this.textBox31.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox31.Enabled = false;
            this.textBox31.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox31.Location = new System.Drawing.Point(199, 147);
            this.textBox31.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox31.MaxLength = 2;
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(28, 24);
            this.textBox31.TabIndex = 15;
            this.textBox31.Text = "00";
            this.textBox31.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox56
            // 
            this.textBox56.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox56.Enabled = false;
            this.textBox56.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox56.Location = new System.Drawing.Point(199, 199);
            this.textBox56.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox56.MaxLength = 2;
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(28, 24);
            this.textBox56.TabIndex = 15;
            this.textBox56.Text = "00";
            this.textBox56.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox18
            // 
            this.textBox18.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox18.Enabled = false;
            this.textBox18.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(199, 97);
            this.textBox18.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox18.MaxLength = 2;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(28, 24);
            this.textBox18.TabIndex = 15;
            this.textBox18.Text = "00";
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox55
            // 
            this.textBox55.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox55.Enabled = false;
            this.textBox55.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox55.Location = new System.Drawing.Point(199, 224);
            this.textBox55.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox55.MaxLength = 2;
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(28, 24);
            this.textBox55.TabIndex = 15;
            this.textBox55.Text = "00";
            this.textBox55.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox30
            // 
            this.textBox30.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox30.Enabled = false;
            this.textBox30.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox30.Location = new System.Drawing.Point(199, 122);
            this.textBox30.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox30.MaxLength = 2;
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(28, 24);
            this.textBox30.TabIndex = 15;
            this.textBox30.Text = "00";
            this.textBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox54
            // 
            this.textBox54.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox54.Enabled = false;
            this.textBox54.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox54.Location = new System.Drawing.Point(199, 174);
            this.textBox54.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox54.MaxLength = 2;
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(28, 24);
            this.textBox54.TabIndex = 15;
            this.textBox54.Text = "00";
            this.textBox54.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtData5
            // 
            this.txtData5.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtData5.Enabled = false;
            this.txtData5.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData5.Location = new System.Drawing.Point(199, 72);
            this.txtData5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtData5.MaxLength = 2;
            this.txtData5.Name = "txtData5";
            this.txtData5.Size = new System.Drawing.Size(28, 24);
            this.txtData5.TabIndex = 15;
            this.txtData5.Text = "00";
            this.txtData5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox53
            // 
            this.textBox53.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox53.Enabled = false;
            this.textBox53.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox53.Location = new System.Drawing.Point(100, 249);
            this.textBox53.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox53.MaxLength = 2;
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(28, 24);
            this.textBox53.TabIndex = 16;
            this.textBox53.Text = "00";
            this.textBox53.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox29
            // 
            this.textBox29.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox29.Enabled = false;
            this.textBox29.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox29.Location = new System.Drawing.Point(100, 147);
            this.textBox29.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox29.MaxLength = 2;
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(28, 24);
            this.textBox29.TabIndex = 16;
            this.textBox29.Text = "00";
            this.textBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox52
            // 
            this.textBox52.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox52.Enabled = false;
            this.textBox52.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox52.Location = new System.Drawing.Point(100, 199);
            this.textBox52.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox52.MaxLength = 2;
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(28, 24);
            this.textBox52.TabIndex = 16;
            this.textBox52.Text = "00";
            this.textBox52.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox17
            // 
            this.textBox17.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox17.Enabled = false;
            this.textBox17.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(100, 97);
            this.textBox17.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox17.MaxLength = 2;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(28, 24);
            this.textBox17.TabIndex = 16;
            this.textBox17.Text = "00";
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox51
            // 
            this.textBox51.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox51.Enabled = false;
            this.textBox51.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox51.Location = new System.Drawing.Point(100, 224);
            this.textBox51.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox51.MaxLength = 2;
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(28, 24);
            this.textBox51.TabIndex = 16;
            this.textBox51.Text = "00";
            this.textBox51.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox28
            // 
            this.textBox28.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox28.Enabled = false;
            this.textBox28.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox28.Location = new System.Drawing.Point(100, 122);
            this.textBox28.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox28.MaxLength = 2;
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(28, 24);
            this.textBox28.TabIndex = 16;
            this.textBox28.Text = "00";
            this.textBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox50
            // 
            this.textBox50.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox50.Enabled = false;
            this.textBox50.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox50.Location = new System.Drawing.Point(100, 174);
            this.textBox50.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox50.MaxLength = 2;
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(28, 24);
            this.textBox50.TabIndex = 16;
            this.textBox50.Text = "00";
            this.textBox50.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtData2
            // 
            this.txtData2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtData2.Enabled = false;
            this.txtData2.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData2.Location = new System.Drawing.Point(100, 72);
            this.txtData2.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtData2.MaxLength = 2;
            this.txtData2.Name = "txtData2";
            this.txtData2.Size = new System.Drawing.Size(28, 24);
            this.txtData2.TabIndex = 16;
            this.txtData2.Text = "00";
            this.txtData2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox49
            // 
            this.textBox49.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox49.Enabled = false;
            this.textBox49.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox49.Location = new System.Drawing.Point(169, 249);
            this.textBox49.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox49.MaxLength = 2;
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(28, 24);
            this.textBox49.TabIndex = 14;
            this.textBox49.Text = "00";
            this.textBox49.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox27
            // 
            this.textBox27.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox27.Enabled = false;
            this.textBox27.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox27.Location = new System.Drawing.Point(169, 147);
            this.textBox27.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox27.MaxLength = 2;
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(28, 24);
            this.textBox27.TabIndex = 14;
            this.textBox27.Text = "00";
            this.textBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox48
            // 
            this.textBox48.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox48.Enabled = false;
            this.textBox48.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox48.Location = new System.Drawing.Point(169, 199);
            this.textBox48.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox48.MaxLength = 2;
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(28, 24);
            this.textBox48.TabIndex = 14;
            this.textBox48.Text = "00";
            this.textBox48.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox16
            // 
            this.textBox16.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox16.Enabled = false;
            this.textBox16.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(169, 97);
            this.textBox16.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox16.MaxLength = 2;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(28, 24);
            this.textBox16.TabIndex = 14;
            this.textBox16.Text = "00";
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox47
            // 
            this.textBox47.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox47.Enabled = false;
            this.textBox47.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox47.Location = new System.Drawing.Point(169, 224);
            this.textBox47.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox47.MaxLength = 2;
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(28, 24);
            this.textBox47.TabIndex = 14;
            this.textBox47.Text = "00";
            this.textBox47.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox26
            // 
            this.textBox26.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox26.Enabled = false;
            this.textBox26.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox26.Location = new System.Drawing.Point(169, 122);
            this.textBox26.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox26.MaxLength = 2;
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(28, 24);
            this.textBox26.TabIndex = 14;
            this.textBox26.Text = "00";
            this.textBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox46
            // 
            this.textBox46.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox46.Enabled = false;
            this.textBox46.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox46.Location = new System.Drawing.Point(169, 174);
            this.textBox46.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox46.MaxLength = 2;
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(28, 24);
            this.textBox46.TabIndex = 14;
            this.textBox46.Text = "00";
            this.textBox46.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtData4
            // 
            this.txtData4.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtData4.Enabled = false;
            this.txtData4.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData4.Location = new System.Drawing.Point(169, 72);
            this.txtData4.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtData4.MaxLength = 2;
            this.txtData4.Name = "txtData4";
            this.txtData4.Size = new System.Drawing.Size(28, 24);
            this.txtData4.TabIndex = 14;
            this.txtData4.Text = "00";
            this.txtData4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox45
            // 
            this.textBox45.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox45.Enabled = false;
            this.textBox45.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox45.Location = new System.Drawing.Point(70, 249);
            this.textBox45.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox45.MaxLength = 2;
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(28, 24);
            this.textBox45.TabIndex = 15;
            this.textBox45.Text = "00";
            this.textBox45.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox25
            // 
            this.textBox25.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox25.Enabled = false;
            this.textBox25.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox25.Location = new System.Drawing.Point(70, 147);
            this.textBox25.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox25.MaxLength = 2;
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(28, 24);
            this.textBox25.TabIndex = 15;
            this.textBox25.Text = "00";
            this.textBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox44
            // 
            this.textBox44.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox44.Enabled = false;
            this.textBox44.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox44.Location = new System.Drawing.Point(70, 199);
            this.textBox44.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox44.MaxLength = 2;
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(28, 24);
            this.textBox44.TabIndex = 15;
            this.textBox44.Text = "00";
            this.textBox44.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox15
            // 
            this.textBox15.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox15.Enabled = false;
            this.textBox15.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(70, 97);
            this.textBox15.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox15.MaxLength = 2;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(28, 24);
            this.textBox15.TabIndex = 15;
            this.textBox15.Text = "00";
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox43
            // 
            this.textBox43.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox43.Enabled = false;
            this.textBox43.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox43.Location = new System.Drawing.Point(70, 224);
            this.textBox43.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox43.MaxLength = 2;
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(28, 24);
            this.textBox43.TabIndex = 15;
            this.textBox43.Text = "00";
            this.textBox43.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox24
            // 
            this.textBox24.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox24.Enabled = false;
            this.textBox24.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox24.Location = new System.Drawing.Point(70, 122);
            this.textBox24.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox24.MaxLength = 2;
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(28, 24);
            this.textBox24.TabIndex = 15;
            this.textBox24.Text = "00";
            this.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox42
            // 
            this.textBox42.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox42.Enabled = false;
            this.textBox42.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox42.Location = new System.Drawing.Point(70, 174);
            this.textBox42.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox42.MaxLength = 2;
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(28, 24);
            this.textBox42.TabIndex = 15;
            this.textBox42.Text = "00";
            this.textBox42.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtData1
            // 
            this.txtData1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtData1.Enabled = false;
            this.txtData1.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData1.Location = new System.Drawing.Point(70, 72);
            this.txtData1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtData1.MaxLength = 2;
            this.txtData1.Name = "txtData1";
            this.txtData1.Size = new System.Drawing.Size(28, 24);
            this.txtData1.TabIndex = 15;
            this.txtData1.Text = "00";
            this.txtData1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox41
            // 
            this.textBox41.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox41.Enabled = false;
            this.textBox41.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox41.Location = new System.Drawing.Point(40, 249);
            this.textBox41.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox41.MaxLength = 2;
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(28, 24);
            this.textBox41.TabIndex = 14;
            this.textBox41.Text = "00";
            this.textBox41.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox23
            // 
            this.textBox23.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox23.Enabled = false;
            this.textBox23.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox23.Location = new System.Drawing.Point(40, 147);
            this.textBox23.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox23.MaxLength = 2;
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(28, 24);
            this.textBox23.TabIndex = 14;
            this.textBox23.Text = "00";
            this.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox40
            // 
            this.textBox40.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox40.Enabled = false;
            this.textBox40.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox40.Location = new System.Drawing.Point(40, 199);
            this.textBox40.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox40.MaxLength = 2;
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(28, 24);
            this.textBox40.TabIndex = 14;
            this.textBox40.Text = "00";
            this.textBox40.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox14
            // 
            this.textBox14.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox14.Enabled = false;
            this.textBox14.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(40, 97);
            this.textBox14.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox14.MaxLength = 2;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(28, 24);
            this.textBox14.TabIndex = 14;
            this.textBox14.Text = "00";
            this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox39
            // 
            this.textBox39.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox39.Enabled = false;
            this.textBox39.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox39.Location = new System.Drawing.Point(40, 224);
            this.textBox39.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox39.MaxLength = 2;
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(28, 24);
            this.textBox39.TabIndex = 14;
            this.textBox39.Text = "00";
            this.textBox39.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox22
            // 
            this.textBox22.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox22.Enabled = false;
            this.textBox22.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox22.Location = new System.Drawing.Point(40, 122);
            this.textBox22.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox22.MaxLength = 2;
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(28, 24);
            this.textBox22.TabIndex = 14;
            this.textBox22.Text = "00";
            this.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox38
            // 
            this.textBox38.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox38.Enabled = false;
            this.textBox38.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox38.Location = new System.Drawing.Point(40, 174);
            this.textBox38.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBox38.MaxLength = 2;
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(28, 24);
            this.textBox38.TabIndex = 14;
            this.textBox38.Text = "00";
            this.textBox38.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtData0
            // 
            this.txtData0.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtData0.Enabled = false;
            this.txtData0.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData0.Location = new System.Drawing.Point(40, 72);
            this.txtData0.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtData0.MaxLength = 2;
            this.txtData0.Name = "txtData0";
            this.txtData0.Size = new System.Drawing.Size(28, 24);
            this.txtData0.TabIndex = 14;
            this.txtData0.Text = "00";
            this.txtData0.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // chbBRS
            // 
            this.chbBRS.Cursor = System.Windows.Forms.Cursors.Default;
            this.chbBRS.Enabled = false;
            this.chbBRS.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.chbBRS.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbBRS.Location = new System.Drawing.Point(236, 287);
            this.chbBRS.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chbBRS.Name = "chbBRS";
            this.chbBRS.Size = new System.Drawing.Size(46, 22);
            this.chbBRS.TabIndex = 5;
            this.chbBRS.Text = "BRS";
            this.chbBRS.Visible = false;
            // 
            // chbFD
            // 
            this.chbFD.Cursor = System.Windows.Forms.Cursors.Default;
            this.chbFD.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.chbFD.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbFD.Location = new System.Drawing.Point(190, 287);
            this.chbFD.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chbFD.Name = "chbFD";
            this.chbFD.Size = new System.Drawing.Size(43, 22);
            this.chbFD.TabIndex = 4;
            this.chbFD.Text = "FD";
            this.chbFD.Visible = false;
            // 
            // chbRemote
            // 
            this.chbRemote.Cursor = System.Windows.Forms.Cursors.Default;
            this.chbRemote.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.chbRemote.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbRemote.Location = new System.Drawing.Point(135, 287);
            this.chbRemote.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chbRemote.Name = "chbRemote";
            this.chbRemote.Size = new System.Drawing.Size(52, 22);
            this.chbRemote.TabIndex = 3;
            this.chbRemote.Text = "RTR";
            // 
            // chbExtended
            // 
            this.chbExtended.Cursor = System.Windows.Forms.Cursors.Default;
            this.chbExtended.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.chbExtended.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chbExtended.Location = new System.Drawing.Point(38, 287);
            this.chbExtended.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.chbExtended.Name = "chbExtended";
            this.chbExtended.Size = new System.Drawing.Size(94, 22);
            this.chbExtended.TabIndex = 2;
            this.chbExtended.Text = "Extended";
            // 
            // btnWrite
            // 
            this.btnWrite.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnWrite.Cursor = System.Windows.Forms.Cursors.Default;
            this.btnWrite.Enabled = false;
            this.btnWrite.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.btnWrite.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWrite.Location = new System.Drawing.Point(36, 406);
            this.btnWrite.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnWrite.Name = "btnWrite";
            this.btnWrite.Size = new System.Drawing.Size(246, 29);
            this.btnWrite.TabIndex = 6;
            this.btnWrite.Text = "Write";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(157, 323);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(38, 17);
            this.label12.TabIndex = 31;
            this.label12.Text = "DLC:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(35, 323);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(60, 17);
            this.label13.TabIndex = 30;
            this.label13.Text = "ID (Hex):";
            // 
            // txtID
            // 
            this.txtID.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtID.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtID.Location = new System.Drawing.Point(39, 343);
            this.txtID.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txtID.MaxLength = 3;
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(93, 24);
            this.txtID.TabIndex = 0;
            this.txtID.Text = "0";
            // 
            // nudLength
            // 
            this.nudLength.BackColor = System.Drawing.Color.White;
            this.nudLength.Font = new System.Drawing.Font("Book Antiqua", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nudLength.Location = new System.Drawing.Point(160, 344);
            this.nudLength.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.nudLength.Maximum = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.nudLength.Name = "nudLength";
            this.nudLength.ReadOnly = true;
            this.nudLength.Size = new System.Drawing.Size(48, 24);
            this.nudLength.TabIndex = 1;
            this.nudLength.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.tbLogSavePeriod);
            this.groupBox14.Controls.Add(this.label44);
            this.groupBox14.Controls.Add(this.rtbPathSave);
            this.groupBox14.Controls.Add(this.rtbSaveLogFilename);
            this.groupBox14.Controls.Add(this.btnLogStart);
            this.groupBox14.Controls.Add(this.btnLogStop);
            this.groupBox14.Controls.Add(this.label29);
            this.groupBox14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox14.Location = new System.Drawing.Point(760, 30);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(456, 121);
            this.groupBox14.TabIndex = 167;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "BMS 데이터 저장";
            // 
            // tbLogSavePeriod
            // 
            this.tbLogSavePeriod.Font = new System.Drawing.Font("맑은 고딕", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbLogSavePeriod.Location = new System.Drawing.Point(307, 13);
            this.tbLogSavePeriod.Name = "tbLogSavePeriod";
            this.tbLogSavePeriod.Size = new System.Drawing.Size(70, 27);
            this.tbLogSavePeriod.TabIndex = 6;
            this.tbLogSavePeriod.Text = "1000";
            this.tbLogSavePeriod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(191, 20);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(102, 19);
            this.label44.TabIndex = 5;
            this.label44.Text = "저장 주기(msec)";
            // 
            // rtbPathSave
            // 
            this.rtbPathSave.Font = new System.Drawing.Font("Courier New", 11.26957F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbPathSave.Location = new System.Drawing.Point(6, 45);
            this.rtbPathSave.Multiline = false;
            this.rtbPathSave.Name = "rtbPathSave";
            this.rtbPathSave.ReadOnly = true;
            this.rtbPathSave.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.ForcedHorizontal;
            this.rtbPathSave.Size = new System.Drawing.Size(371, 31);
            this.rtbPathSave.TabIndex = 4;
            this.rtbPathSave.Text = "";
            // 
            // rtbSaveLogFilename
            // 
            this.rtbSaveLogFilename.Font = new System.Drawing.Font("Courier New", 11.26957F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbSaveLogFilename.Location = new System.Drawing.Point(6, 82);
            this.rtbSaveLogFilename.Multiline = false;
            this.rtbSaveLogFilename.Name = "rtbSaveLogFilename";
            this.rtbSaveLogFilename.ReadOnly = true;
            this.rtbSaveLogFilename.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Horizontal;
            this.rtbSaveLogFilename.Size = new System.Drawing.Size(371, 35);
            this.rtbSaveLogFilename.TabIndex = 4;
            this.rtbSaveLogFilename.Text = "";
            // 
            // btnLogStart
            // 
            this.btnLogStart.BackColor = System.Drawing.Color.White;
            this.btnLogStart.Font = new System.Drawing.Font("휴먼옛체", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLogStart.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnLogStart.Location = new System.Drawing.Point(386, 19);
            this.btnLogStart.Name = "btnLogStart";
            this.btnLogStart.Size = new System.Drawing.Size(65, 45);
            this.btnLogStart.TabIndex = 3;
            this.btnLogStart.Text = "저장";
            this.btnLogStart.UseVisualStyleBackColor = false;
            this.btnLogStart.Click += new System.EventHandler(this.btnLogStart_Click);
            // 
            // btnLogStop
            // 
            this.btnLogStop.Font = new System.Drawing.Font("휴먼옛체", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnLogStop.Location = new System.Drawing.Point(386, 70);
            this.btnLogStop.Name = "btnLogStop";
            this.btnLogStop.Size = new System.Drawing.Size(65, 45);
            this.btnLogStop.TabIndex = 2;
            this.btnLogStop.Text = "종료";
            this.btnLogStop.UseVisualStyleBackColor = true;
            this.btnLogStop.Click += new System.EventHandler(this.btnLogStop_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Times New Roman", 11.89565F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(3, 25);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(97, 19);
            this.label29.TabIndex = 1;
            this.label29.Text = "파일 경로 / 이름";
            // 
            // timerRequestEvent
            // 
            this.timerRequestEvent.Interval = 200;
            this.timerRequestEvent.Tick += new System.EventHandler(this.timerRequestEvent_Tick);
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1232, 901);
            this.Controls.Add(this.groupBox14);
            this.Controls.Add(this.tabCntProject);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.Name = "Form_Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PCAN :  LB (250Kbps, Extend)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudIdTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudIdFrom)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.nudDelay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDeviceId)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.tabCntProject.ResumeLayout(false);
            this.tabPcanConfig.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.tabProject.ResumeLayout(false);
            this.tabProject.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.tabPcanWrite.ResumeLayout(false);
            this.tabPcanWrite.PerformLayout();
            this.groupBox25.ResumeLayout(false);
            this.groupBox25.PerformLayout();
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDUTP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCUTP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDOTP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCOTP)).EndInit();
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDPFdV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCPFdV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudDPFV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCPFV)).EndInit();
            this.groupBox21.ResumeLayout(false);
            this.groupBox21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudDOCP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCOCP)).EndInit();
            this.groupBox24.ResumeLayout(false);
            this.groupBox24.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudCapacity)).EndInit();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudUVP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudOVP)).EndInit();
            this.tabEvent.ResumeLayout(false);
            this.tabEvent.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.tabPcanRcvId.ResumeLayout(false);
            this.tabPcanRcvMsg.ResumeLayout(false);
            this.tabPcanRcvMsg.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudLength)).EndInit();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cbbChannel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnRelease;
        private System.Windows.Forms.Button btnInit;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown nudIdFrom;
        private System.Windows.Forms.RadioButton rdbFilterOpen;
        private System.Windows.Forms.RadioButton rdbFilterCustom;
        private System.Windows.Forms.RadioButton rdbFilterClose;
        private System.Windows.Forms.Button btnFilterApply;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nudIdTo;
        private System.Windows.Forms.CheckBox chbFilterExt;
        private System.Windows.Forms.Button btnParameterSet;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton rdbParamActive;
        private System.Windows.Forms.RadioButton rdbParamInactive;
        private System.Windows.Forms.ComboBox cbbParameter;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown nudDeviceId;
        private System.Windows.Forms.Label laDeviceOrDelay;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ColumnHeader clhType;
        private System.Windows.Forms.ColumnHeader clhID;
        private System.Windows.Forms.ColumnHeader clhLength;
        private System.Windows.Forms.ColumnHeader clhData;
        private System.Windows.Forms.ColumnHeader clhCount;
        private System.Windows.Forms.ColumnHeader clhRcvTime;
        private System.Windows.Forms.Button btnInfoClear;
        private System.Windows.Forms.Button btnGetVersions;
        private System.Windows.Forms.Button btnParameterGet;
        private System.Windows.Forms.Button btnFilterQuery;
        private System.Windows.Forms.ListBox lbxInfo;
        private System.Windows.Forms.Timer tmrRead;
        private System.Windows.Forms.Button btnHwRefresh;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnStatus;
        private System.Windows.Forms.Timer tmrDisplay;
        private System.Windows.Forms.Label laBitrate;
        private System.Windows.Forms.TextBox txtBitrate;
        private System.Windows.Forms.ComboBox cbbHwType;
        private System.Windows.Forms.ComboBox cbbInterrupt;
        private System.Windows.Forms.Label laInterrupt;
        private System.Windows.Forms.ComboBox cbbIO;
        private System.Windows.Forms.Label laIOPort;
        private System.Windows.Forms.Label laHwType;
        private System.Windows.Forms.ComboBox cbbBaudrates;
        private System.Windows.Forms.Label laBaudrate;
        private System.Windows.Forms.CheckBox chbCanFD;
        private System.Windows.Forms.NumericUpDown nudDelay;
        private System.Windows.Forms.ColumnHeader cihPeriod;
        private System.Windows.Forms.RichTextBox rtbCanMsg;
        private System.Windows.Forms.Button on_sec;
        private System.Windows.Forms.Button off_1sec;
        private System.Windows.Forms.Button btRtbSave;
        private System.Windows.Forms.Button btRtbInit;
        private ListViewNF lstMessages;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.SaveFileDialog logFileDlg;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 파일ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pCAN설정ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 저장ToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem 종료ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 도움말ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem receiveIDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem receiveLogToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transmitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem waccoToolStripMenuItem;
        private System.Windows.Forms.TabControl tabCntProject;
        private System.Windows.Forms.TabPage tabPcanConfig;
        private System.Windows.Forms.TabPage tabPcanRcvId;
        private System.Windows.Forms.TabPage tabPcanRcvMsg;
        private System.Windows.Forms.TabPage tabProject;
        private System.Windows.Forms.TabPage tabPcanWrite;
        private System.Windows.Forms.TextBox tbSerialNo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbManufacture;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox tbVersion;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblDateTime;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label lvlVoltage;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox tbStateIdle;
        private System.Windows.Forms.TextBox tbStateFault;
        private System.Windows.Forms.TextBox tbStateGood;
        private System.Windows.Forms.TextBox tbStateDisChg;
        private System.Windows.Forms.TextBox tbStateChg;
        private System.Windows.Forms.Label lvlCurrent;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox tbSOC;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox tbSOP;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox tbSOH;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox tbPackVoltIn;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.TextBox tbPackVoltOut;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox tbCycleCount;
        private ListViewNF lvｗCellVoltage;
        private System.Windows.Forms.ColumnHeader CellNo;
        private System.Windows.Forms.ColumnHeader Volt;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.ColumnHeader Balacing;
        private System.Windows.Forms.TextBox tbCellVoltMin;
        private System.Windows.Forms.TextBox tbCellVoltMax;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox tbCellVoltAvg;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.GroupBox groupBox9;
        private ListViewNF lvlPackTemp;
        private System.Windows.Forms.ColumnHeader Type;
        private System.Windows.Forms.ColumnHeader Temp;
        private System.Windows.Forms.TextBox tbTempAvg;
        private System.Windows.Forms.TextBox tbTempMax;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox tbTempMin;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox tbFaultPwdn;
        private System.Windows.Forms.TextBox tbFaultShtp;
        private System.Windows.Forms.TextBox tbFaultDutp;
        private System.Windows.Forms.TextBox tbFaultCutp;
        private System.Windows.Forms.TextBox tbFaultDotp;
        private System.Windows.Forms.TextBox tbFaultDocp;
        private System.Windows.Forms.TextBox tbFaultCocp;
        private System.Windows.Forms.TextBox tbFaultDuvp;
        private System.Windows.Forms.TextBox tbFaultCovp;
        private System.Windows.Forms.TextBox tbFaultCotp;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox tbBmsStChgChgFet;
        private System.Windows.Forms.TextBox tbBmsStChgDisFet;
        private System.Windows.Forms.TextBox tbBmsStPfet;
        private System.Windows.Forms.TextBox tbBmsStCfet;
        private System.Windows.Forms.TextBox tbBmsIchg;
        private System.Windows.Forms.TextBox tbBmsDFET;
        private System.Windows.Forms.TextBox tbBmsStIdch;
        private System.Windows.Forms.TextBox tbBmsStSocDisplay;
        private System.Windows.Forms.TextBox tbBmsStChgKeyOn;
        private System.Windows.Forms.TextBox tbBmsStSwon;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Button btnLogStop;
        private System.Windows.Forms.RichTextBox rtbSaveLogFilename;
        private System.Windows.Forms.Button btnLogStart;
        private System.Windows.Forms.TextBox tbCellNoMin;
        private System.Windows.Forms.TextBox tbCellNoMax;
        private System.Windows.Forms.TextBox tbCellVoltDiff;
        private System.Windows.Forms.TextBox tbTempMinNo;
        private System.Windows.Forms.TextBox tbTempMaxNo;
        private System.Windows.Forms.TextBox tbTempDiff;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.TextBox tbAlarmDuta;
        private System.Windows.Forms.TextBox tbAlarmCuta;
        private System.Windows.Forms.TextBox tbAlarmDota;
        private System.Windows.Forms.TextBox tbAlarmCota;
        private System.Windows.Forms.TextBox tbAlarmDoca;
        private System.Windows.Forms.TextBox tbAlarmCoca;
        private System.Windows.Forms.TextBox tbAlarmCuva;
        private System.Windows.Forms.TextBox tbAlarmCova;
        private System.Windows.Forms.TextBox tbLogSavePeriod;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.RichTextBox rtbPathSave;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.CheckBox chbShowPeriod;
        private System.Windows.Forms.Button btnMsgClear;
        private System.Windows.Forms.RadioButton rdbManual;
        private System.Windows.Forms.Button btnRead;
        private System.Windows.Forms.RadioButton rdbEvent;
        private System.Windows.Forms.RadioButton rdbTimer;
        private System.Windows.Forms.NumericUpDown nudOVP;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Button btnReadFromBMS;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.TextBox txtDUTP;
        private System.Windows.Forms.TextBox txtCUTP;
        private System.Windows.Forms.TextBox txtDOTP;
        private System.Windows.Forms.NumericUpDown nudDUTP;
        private System.Windows.Forms.TextBox txtCOTP;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.NumericUpDown nudCUTP;
        private System.Windows.Forms.NumericUpDown nudDOTP;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.NumericUpDown nudCOTP;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.TextBox txtDOCP;
        private System.Windows.Forms.TextBox txtCOCP;
        private System.Windows.Forms.NumericUpDown nudDOCP;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.NumericUpDown nudCOCP;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.TextBox txtUVP;
        private System.Windows.Forms.TextBox txtOVP;
        private System.Windows.Forms.NumericUpDown nudUVP;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Button btnSaveDefaultToBMS;
        private System.Windows.Forms.Button btnSaveToBMS;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.TextBox txtCPFdV;
        private System.Windows.Forms.TextBox txtCPFV;
        private System.Windows.Forms.NumericUpDown nudCPFdV;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.NumericUpDown nudCPFV;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox txtDPFdV;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox txtDPFV;
        private System.Windows.Forms.NumericUpDown nudDPFdV;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.NumericUpDown nudDPFV;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.TextBox txtCapacity;
        private System.Windows.Forms.NumericUpDown nudCapacity;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.ListBox lbxBmsSetLog;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.Button btnMonitorON;
        private System.Windows.Forms.Button btnMonitorOFF;
        private System.Windows.Forms.Label lvlTestIdHex;
        private System.Windows.Forms.TextBox tbIdH;
        private System.Windows.Forms.TextBox tbH7;
        private System.Windows.Forms.Button btnSendTestMsg;
        private System.Windows.Forms.TextBox tbH6;
        private System.Windows.Forms.TextBox tbH5;
        private System.Windows.Forms.TextBox tbH4;
        private System.Windows.Forms.TextBox tbH3;
        private System.Windows.Forms.TextBox tbH2;
        private System.Windows.Forms.TextBox tbH1;
        private System.Windows.Forms.TextBox tbH0;
        private System.Windows.Forms.Button btnClearPF;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label laLength;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox69;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox68;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox txtData7;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox txtData6;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox txtData3;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox txtData5;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox txtData2;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox txtData4;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox txtData1;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox txtData0;
        private System.Windows.Forms.CheckBox chbBRS;
        private System.Windows.Forms.CheckBox chbFD;
        private System.Windows.Forms.CheckBox chbRemote;
        private System.Windows.Forms.CheckBox chbExtended;
        private System.Windows.Forms.Button btnWrite;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.NumericUpDown nudLength;
        private System.Windows.Forms.TabPage tabEvent;
        private ListViewNF lvwEventMain;
        private System.Windows.Forms.ColumnHeader No;
        private System.Windows.Forms.ColumnHeader Time;
        private System.Windows.Forms.ColumnHeader EventName;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label62;
        private ListViewNF lvwEventDetail;
        private System.Windows.Forms.ColumnHeader dtNo;
        private System.Windows.Forms.ColumnHeader dtTime;
        private System.Windows.Forms.ColumnHeader dtVoltPack;
        private System.Windows.Forms.ColumnHeader dtVoltMax;
        private System.Windows.Forms.ColumnHeader dtVoltMin;
        private System.Windows.Forms.ColumnHeader dtCurrent;
        private System.Windows.Forms.ColumnHeader dtTempMax;
        private System.Windows.Forms.ColumnHeader dtTempMin;
        private System.Windows.Forms.ColumnHeader EventCode;
        private System.Windows.Forms.ColumnHeader VoltPack;
        private System.Windows.Forms.ColumnHeader VoltMax;
        private System.Windows.Forms.ColumnHeader VoltMin;
        private System.Windows.Forms.ColumnHeader Current;
        private System.Windows.Forms.ColumnHeader TempMax;
        private System.Windows.Forms.ColumnHeader TempMin;
        private System.Windows.Forms.Button btnEventSave;
        private System.Windows.Forms.Button btnEventRequest;
        private System.Windows.Forms.Label lblEventNameCode;
        private System.Windows.Forms.Timer timerRequestEvent;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtLastEventIndex;
        private System.Windows.Forms.TextBox txtBmsRunTime;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox tbRC;
        private System.Windows.Forms.TextBox tbFCC;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox txtLastEvent;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtRunTimeInEvent;
        private System.Windows.Forms.Label lblInfoMonitor;
        private System.Windows.Forms.Button btnClearEventLog;
        private System.Windows.Forms.CheckBox ckbDisplayMessageEvent;
        private System.Windows.Forms.RichTextBox rtbEventLog;
        private System.Windows.Forms.Label lblBmsRcvStateProject;
        private System.Windows.Forms.Button btnEventReqStop;
        private System.Windows.Forms.Label lblBmsRcvStateEvent;
        private System.Windows.Forms.SaveFileDialog EventlogFileDlg;
        private System.Windows.Forms.ColumnHeader dtEventCode;
    }
}

